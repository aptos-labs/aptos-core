# MoveFlow

Move smart contract development plugin for Claude Code.

## Overview

MoveFlow provides skills, agents, hooks, and an MCP server for developing, testing, and formally verifying [Move](https://aptos.dev/en/build/smart-contracts) smart contracts on [Aptos](https://aptos.dev). Version 2.0.0.

## Skills

| Skill | Description |
|-------|-------------|
| `/move` | Develop, review, and debug Aptos Move code. Use for general Move work; use move-test, move-prove, or move-inf for their specialized workflows. |
| `/move-check` | Diagnose and fix Move compilation errors. Use when a Move package does not compile; not for prover or unit-test failures. |
| `/move-inf` | Infer and verify complete Move specifications and loop invariants. Use when contracts are missing; not merely to check existing specs. |
| `/move-init` | Add idempotent MoveFlow workflow routing to a Move package's CLAUDE.md. Use when configuring a package for future Claude Code sessions. |
| `/move-prove` | Verify and diagnose existing Move specifications with the Move Prover. Use for proof failures or timeouts; use move-inf when contracts are missing. |
| `/move-test` | Write and improve Move unit tests. Use for test generation, behavioral cases, and coverage; not for proving specifications. |

## Agents

| Agent | Description |
|-------|-------------|
| `move-check` | Diagnose and fix Move compiler errors; not prover or unit-test failures |
| `move-inf` | Infer and verify missing Move specifications and loop invariants |
| `move-test` | Generate focused Move unit tests and improve useful behavioral coverage |
| `move-verify` | Verify and diagnose existing Move specifications with the Move Prover |

## MCP Tools

Provided by the `move-flow` MCP server (configured in `.mcp.json`).

| Tool | Description |
|------|-------------|
| `move_package_coverage` | Get uncovered source lines for a package |
| `move_package_manifest` | Get information about the current Move package |
| `move_package_query` | Query structural information about a Move package. |
| `move_package_status` | Check a Move package for compilation errors and warnings |
| `move_package_test` | Run Move unit tests for a package |
| `move_package_verify` | Verify Move specifications using the Move Prover |
| `move_spec_check` | Run every acceptance check for the current specification task: compilation, complete target verification, contract-category coverage and forbidden weakening |

## Hooks

- **PostToolUse** — After every `Edit` or `Write` that touches a `.move` file, runs syntax checks and auto-formatting.
- **UserPromptSubmit** — Detects Move package paths in the working directory.
- **SessionStart** — Verifies that the `move-flow` binary is installed.

## Requirements

- `move-flow` binary on `$PATH` (or set `$MOVE_FLOW` to the binary path)

## Author

Aptos Labs — version 2.0.0
