#!/usr/bin/env bash
set -euo pipefail
EVAL_ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$EVAL_ROOT"
export PATH="$EVAL_ROOT/../../../../target/ci:$PATH"
export BOOGIE_EXE="${BOOGIE_EXE:-/home/wrw/.local/bin/boogie}"
export Z3_EXE="${Z3_EXE:-/home/wrw/.local/bin/z3}"
export MOVE_INFERENCE_CLAUDE_TOKEN_FILE="${MOVE_INFERENCE_CLAUDE_TOKEN_FILE:-/home/wrw/shared/config/ant-apt.key}"
ROUND_DIR="$EVAL_ROOT/evaluation-artifacts/round-v1.2-005-opus-xhigh"
exec .venv/bin/python -m harness.model_profile exec --config "$ROUND_DIR/config.json" -- \
  .venv/bin/python -m harness.pilot_run --config "$ROUND_DIR/config.json" \
  --schedule-dir "$ROUND_DIR/schedule" --artifacts-dir "$ROUND_DIR/runs" \
  --sandbox-wrapper scripts/pilot-sandbox --concurrency 4 \
  --report "$ROUND_DIR/launch-report.json"
