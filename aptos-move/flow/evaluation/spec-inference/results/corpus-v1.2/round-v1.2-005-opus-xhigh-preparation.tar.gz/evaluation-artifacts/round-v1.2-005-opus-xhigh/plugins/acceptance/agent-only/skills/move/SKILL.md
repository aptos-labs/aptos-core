---
name: move
description: Develop, review, and debug Aptos Move code. Use for general Move work; use move-test, move-prove, or move-inf for their specialized workflows.
---

## Working on a Move package

Find the package root (`Move.toml`) and preserve the user's requested scope.
Inspect the manifest, package structure, and compiler diagnostics only as needed.
For implementation changes, make the smallest behaviorally appropriate edit and
recheck the package. Do not change named-address bindings, dependencies, or
unrelated modules merely to make an error disappear.

## Move Language

Move is resource-oriented: abilities (`key`, `store`, `copy`, `drop`) determine
how values may be stored, duplicated, and discarded. Modules are published at
addresses; resources with `key` live in global storage.

- `entry fun` declares a transaction entry point; `#[view]` marks a read-only
  query.
- Use the package's established Move syntax and style. In Move 2 code, prefer
  `&T[addr]`, `&mut T[addr]`, and direct field access over legacy
  `borrow_global*`; do not add obsolete `acquires` annotations.
- Use named, documented abort constants rather than unexplained numeric codes.
- `///` is a declaration doc comment. Use `//` for comments inside functions.
- The edit hook checks and formats changed `.move` files. Treat its diagnostics
  as feedback, then confirm package status after completing the edit.

### Links

- [The Move Book](https://aptos-labs.github.io/move-book/)
- [Aptos Framework Book](https://aptos-labs.github.io/framework-book/)

## Move Packages

A Move package is rooted at `Move.toml`, which defines its package name,
dependencies, and named addresses. Work from that directory unless the user
selects another package explicitly.

### Named Addresses

Named addresses must resolve for compilation:

- `[addresses]` contains package bindings and may use `_` for a publish-time
  assignment.
- `[dev-addresses]` supplies development and test bindings.

For an unresolved address, first inspect the package and its dependencies for
the intended binding. For local-only code, add a unique non-framework value to
`[dev-addresses]`. Do not invent or replace a production binding merely to make
the compiler pass.

```toml
[dev-addresses]
my_package = "0x100"
```

## Inspecting a Move package

- Use `move_package_status` for current compiler errors and
  warnings. Re-run it after edits; cached results make unchanged checks cheap.
- Use `move_package_manifest` to distinguish target sources
  (`source_paths`) from dependency sources (`dep_paths`).
- Use `move_package_query` instead of reading an entire
  package when a structural query answers the question:
  - `module_summary` for signatures and declarations;
  - `facts` for detailed declarations, attributes, and source locations;
  - `dep_graph` for module dependencies;
  - `call_graph` for package-wide calls;
  - `function_usage` with `function: "module::function"` for the direct and
    transitive calls and closure captures relevant to one function.

All tools take `package_path`, which must name the directory containing
`Move.toml`.

