spec aptos_framework::chain_status {
    /// <high-level-req>
    /// No.: 1
    /// Requirement: The end of genesis mark should persist throughout the entire life of the chain.
    /// Criticality: Medium
    /// Implementation: The Aptos framework account should never drop the GenesisEndMarker resource.
    /// Enforcement: Audited that GenesisEndMarker is published at the end of genesis and never removed. Formally
    /// verified via [high-level-req-1](set_genesis_end) that GenesisEndMarker is published.
    ///
    /// No.: 2
    /// Requirement: The status of the chain should never be genesis and operating at the same time.
    /// Criticality: Low
    /// Implementation: The status of the chain is determined by the GenesisEndMarker resource.
    /// Enforcement: Formally verified via [high-level-req-2](global invariant).
    ///
    /// No.: 3
    /// Requirement: The status of the chain should only be changed once, from genesis to operating.
    /// Criticality: Low
    /// Implementation: Attempting to assign a resource type more than once will abort.
    /// Enforcement: Formally verified via [high-level-req-3](set_genesis_end).
    /// </high-level-req>
    ///
    spec module {
        pragma verify = true;
        pragma aborts_if_is_strict;
        /// [high-level-req-2]
        invariant is_genesis() == !is_operating();
    }

    spec set_genesis_end(aptos_framework: &signer) {
        use std::signer;
        pragma opaque;
        pragma verify = true;
        pragma delegate_invariants_to_caller;
        modifies global<GenesisEndMarker>(@aptos_framework);
        let addr = signer::address_of(aptos_framework);
        aborts_if addr != @aptos_framework;
        /// [high-level-req-3]
        aborts_if exists<GenesisEndMarker>(@aptos_framework);
        /// [high-level-req-1]
        ensures exists<GenesisEndMarker>(@aptos_framework);
        ensures global<GenesisEndMarker>(@aptos_framework) == GenesisEndMarker {};
    }

    spec is_genesis {
        pragma opaque;
        aborts_if false;
        ensures result == !exists<GenesisEndMarker>(@aptos_framework);
    }

    spec is_operating {
        pragma opaque;
        aborts_if false;
        ensures result == exists<GenesisEndMarker>(@aptos_framework);
    }

    spec schema RequiresIsOperating {
        requires is_operating();
    }

    spec assert_operating {
        pragma opaque;
        aborts_if !is_operating();
    }

    spec assert_genesis {
        pragma opaque;
        aborts_if !is_genesis();
    }
}
