---
name: move-test
description: Generate focused Move unit tests and improve useful behavioral coverage
---

Write focused Move unit tests for the requested behavior and validate that they
pass and add useful coverage.

## Test-generation workflow

1. **Establish a clean baseline.** Run the existing tests with baseline
   coverage enabled. Do not edit production code or existing tests to hide a
   pre-existing failure; report it unless the user also asked for a fix.
2. **Choose behavioral cases.** Read the requested function or module and cover
   meaningful success paths, distinct aborts, branches, and boundary values.
   Use uncovered lines as evidence, not as the sole definition of quality.
3. **Write isolated generated tests.** Put new tests in
   `tests/move_flow/<module>_tests.move`. Do not modify user-authored tests.
4. **Validate and diagnose.** Run the tests. Repair generated test setup or
   expectations when they are wrong. If a correct test exposes a production
   bug, preserve the reproducer under `bugs/` and report it rather than changing
   the intended assertion to pass.
5. **Review coverage and redundancy.** Keep behaviorally distinct cases even
   when they cover the same line. Remove only generated tests that duplicate
   both behavior and coverage.
6. **Report the outcome.** Name the cases added, whether all tests pass, the
   useful coverage gained, and any suspected product defect.

Use the reference material below when writing or diagnosing tests.

## Move Packages

A Move package is rooted at `Move.toml`, which defines its package name,
dependencies, and named addresses. Work from that directory unless the user
selects another package explicitly.

### Named Addresses

Named addresses must resolve for compilation:

- `[addresses]` contains package bindings and may use `_` for a publish-time
  assignment.
- `[dev-addresses]` supplies development and test bindings.

For an unresolved address, first inspect the package and its dependencies for
the intended binding. For local-only code, add a unique non-framework value to
`[dev-addresses]`. Do not invent or replace a production binding merely to make
the compiler pass.

```toml
[dev-addresses]
my_package = "0x100"
```

## Inspecting a Move package

- Use `move_package_status` for current compiler errors and
  warnings. Re-run it after edits; cached results make unchanged checks cheap.
- Use `move_package_manifest` to distinguish target sources
  (`source_paths`) from dependency sources (`dep_paths`).
- Use `move_package_query` instead of reading an entire
  package when a structural query answers the question:
  - `module_summary` for signatures and declarations;
  - `facts` for detailed declarations, attributes, and source locations;
  - `dep_graph` for module dependencies;
  - `call_graph` for package-wide calls;
  - `function_usage` with `function: "module::function"` for the direct and
    transitive calls and closure captures relevant to one function.

All tools take `package_path`, which must name the directory containing
`Move.toml`.

## Unit-test reference

## Move unit-test syntax

### Test Attributes

| Attribute | Usage |
|-----------|-------|
| `#[test]` | Marks a function as a test |
| `#[test(name = @addr)]` | Test with signer parameters bound to addresses |
| `#[test_only]` | Code only compiled for testing (modules, functions, structs, constants) |
| `#[expected_failure]` | Test expected to abort (any code) |
| `#[expected_failure(abort_code = N)]` | Expects abort with specific code |
| `#[expected_failure(abort_code = N, location = mod)]` | Expects abort at specific location |

### Signer parameters

Signers are bound via the test attribute, not passed as arguments:

```move
// Single signer
#[test(account = @0x1)]
fun test_single(account: &signer) { }

// Multiple signers
#[test(admin = @admin_addr, user = @0x42)]
fun test_multi(admin: &signer, user: &signer) { }

// Framework signer for timestamp, account creation, etc.
#[test(aptos_framework = @aptos_framework)]
fun test_framework(aptos_framework: &signer) { }
```

### Expected failures

Use `#[expected_failure]` to test that code correctly aborts under certain conditions.

Prefer an exact code and location. Use an unconstrained expected failure only
when the failure kind genuinely is the behavior under test.

**Any abort:**
```move
#[test]
#[expected_failure]
fun test_will_abort() { abort 1 }
```

**With abort code** (must match exactly):
```move
#[test]
#[expected_failure(abort_code = E_NOT_AUTHORIZED, location = Self)]
fun test_unauthorized() { /* should abort with E_NOT_AUTHORIZED */ }
```

**With location** (when error originates in another module):
```move
#[test]
#[expected_failure(abort_code = 26113, location = extensions::table)]
fun test_table_error() { /* should abort in table module */ }
```

**Execution errors** (not abort, but runtime failures):
```move
// Arithmetic error (overflow, divide by zero)
#[test]
#[expected_failure(arithmetic_error, location = Self)]
fun test_overflow() { let _ = 255u8 + 1; }

// Vector out of bounds
#[test]
#[expected_failure(vector_error, minor_status = 1, location = Self)]
fun test_out_of_bounds() { vector::borrow(&vector::empty<u8>(), 0); }
```

### Test-only code

```move
// Test-only module (entire module only compiled for tests)
#[test_only]
module my_addr::test_helpers {
    public fun setup(): u64 { 100 }
}

// Test-only function in regular module
module my_addr::my_module {
    #[test_only]
    public fun init_for_testing(account: &signer, value: u64) {
        move_to(account, MyResource { value });
    }
}
```

### Common test utilities

```move
// Get address from signer
use std::signer;
let addr = signer::address_of(account);

// Create account (registers on-chain)
use aptos_framework::account;
account::create_account_for_test(addr);

// Create signer without registering (lightweight)
let signer = account::create_signer_for_test(@0x123);

// Check resource exists
assert!(exists<MyResource>(addr), E_NOT_FOUND);

// Initialize timestamp (required before time functions)
use aptos_framework::timestamp;
timestamp::set_time_has_started_for_testing(aptos_framework);

// Advance time
timestamp::update_global_time_for_test(1000000); // microseconds
timestamp::update_global_time_for_test_secs(100); // seconds
```

## Test design

- Test one behavior per case with the minimum setup needed to reach it.
- Call the requested function directly when its visibility permits. For an
  inaccessible private function, test it through observable public behavior or
  use an existing module-local test pattern; do not change production
  visibility merely for a test.
- Explain the behavior being checked, especially for abort and boundary cases.
- Assert semantic outcomes, not incidental implementation details.

**Naming:** `test_<function>_<scenario>` (e.g., `test_transfer_insufficient_balance`), module: `<module>_tests`

**Common mistakes:**
- `RESOURCE_ALREADY_EXISTS`: Don't initialize the same resource twice
- `MISSING_DATA`: Ensure required resources exist before calling
- Signer mismatch: Operations checking `signer::address_of()` require the correct signer. Match signers to expected addresses in test attributes.

### Tools

- Start with `move_package_test` and
  `establish_baseline: true`. A failed baseline is pre-existing evidence, not
  permission to edit unrelated code.
- Use `move_package_coverage` with
  `function: "module::function"` for a focused target, or omit `function` for
  package-wide uncovered lines.
- After adding tests, call `move_package_test` without
  baseline mode. Its `newly_covered` result measures coverage added since the
  baseline.

### Generated test location

Create or extend only `tests/move_flow/<module>_tests.move`:

```move
#[test_only]
module <package_address>::<module>_tests {
    use <package_address>::<module>;

    #[test(account = @0x1)]
    /// @ai-generated
    /// Verifies that <function> <behavior>.
    fun test_<function>_<scenario>(account: &signer) { ... }
}
```

For module-wide work, proceed one module at a time. A suspected-bug test should
assert the intended behavior and therefore remain a faithful failing reproducer
against buggy code.

### Diagnosing a generated test failure

- **Compilation error**: Fix the test
- **Wrong setup or assertion**: Correct the generated test.
- **Likely production defect**: Move the generated reproducer to `bugs/` at
  the package root and document expected versus actual behavior. Do not alter
  production code unless requested.

Only edit generated files under `tests/move_flow/` and `bugs/` during this
workflow.

