# v1.2 round 005 Opus xhigh: prepared, not launched

This supersedes the max-effort preparation before any sessions ran.

- Opus 5 (`claude-opus-5`), effort **xhigh**, 180,000 output tokens per cell.
- 20 tasks × 3 arms × 4 replicates = 240 cells in 80 randomized blocks.
- Concurrency 4, fixed by `launch.sh`.
- `--no-package-cache`: no timestamp checks or cached package results.
- `--no-wp-simplification`: omit hybrid WP-simplification guidance; it does
  not disable internal WP simplification.
- Intermediate verification guidance 5/10 seconds; agent overrides allowed.
  Operational/eventual judging remains 40 seconds. MBQI remains disabled.
- All 20 tasks screened; all 117 mutants rejected (60 scoring, 57 withheld).
- All 10 final preflight checks pass. Harness tests: 386 run, one skipped.
- No model calls made: preflight checks local credentials and apparatus, not
  provider quota or model availability through a paid request.

Apparatus commit: `ef12d18d63c0f08278b61cb07a4f7d9d228b9def`. The effort fix
changes the harness only; Flow/prover binaries and corpus identities are
unchanged. Screening was resumed with matching binary/package hashes to
refresh the configuration evidence. GLM remains at max effort.

Retain `origin/snapshots/corpus-v1.2-005-opus` in
`https://github.com/wrwg/aptos-core.git`, outside Graphite. Do not restack,
force-push, or delete it. Its preparation commit retains the apparatus commit
as an ancestor. The user approved this alternative to waiting for landing.
The scheduler's mainline-only durability flag remains false; this snapshot is
the separate retention mechanism. Record any later landed commit separately.

From the evaluation directory, launch only when requested:

```sh
bash evaluation-artifacts/round-v1.2-005-opus-xhigh/launch.sh
```

The launcher refers to the user's local OAuth token file, overridable with
`MOVE_INFERENCE_CLAUDE_TOKEN_FILE`. No credential values are archived.
