---
name: move-prove
description: Verify and diagnose existing Move specifications with the Move Prover. Use for proof failures or timeouts; use move-inf when contracts are missing.
---

## Verification workflow

1. **Check and scope.** Confirm that the package compiles and identify the exact
   function/module scope. If the request is diagnostic only, do not edit specs.
2. **Run an initial full-scope proof.** Call the prover at timeout
   5 to collect logical failures and
   timeouts without exclusions.
3. **Resolve logical failures first.** When repair is authorized, use
   counterexamples and diagnostics to fix the implementation/specification
   mismatch. Timed-out functions may be temporarily excluded while resolving
   independent logical failures.
4. **Resolve timeouts individually.** Use a function filter, timeout up to
   10, and the simplification/proof strategies
   below. `split_vcs_by_assert` is diagnostic help, not proof success by itself.

   After 2 focused attempts, retain and
   report an unresolved failure. Never disable or skip verification or weaken
   an obligation because the budget ended.

5. **Close over the full scope.** With no temporary exclusions, use timeout
   10.

   Every requested obligation must be present and verified for success.

   When specifications were written or changed, close with
   `move_spec_check`; it performs the full-scope proof and
   also rejects a contract that weakened itself or left an obligation
   uncovered. For a diagnostic run that changed no specification, close with
   `move_package_verify`.

### The candidate check

`move_spec_check` is how a specification is
tested, whether it was inferred or written by hand. It compiles the package,
verifies the target, rejects a contract that weakens itself -- verification
disabled or skipped, a vacuous condition, a partial-abort pragma no callee
justifies -- and
reports an obligation category the contract leaves uncovered. Give it
`package_path` and optionally `filter` to work on one module or function. If a
candidate needs a larger per-condition solver budget, the usual guidance is
5 seconds initially and
10 seconds on retry. These are suggestions;
override `timeout` when the proof warrants it.

It verifies as part of accepting, so it replaces a closing call to
`move_package_verify`: immediately beforehand that repeats
work the check is about to do, and afterwards it re-proves what the check
already proved. Use the prover for initial diagnosis or to localize a reported
failure over a narrower `filter`.

- Accepted: the requested scope is done. Stop and report.
- Rejected: the headline names which check failed, and the diagnostic lines that
  follow are `path:line: code: message`. Localize a verification failure with a
  focused `move_package_verify` call, repair it, and rerun the
  candidate check. A weakening code points at the clause that introduced it. A
  weakening you did not introduce -- a trusted boundary the project already
  had -- is reported, not removed.
- Unavailable: the prover could not run. That is not a verdict on the
  specification; report it as such.

The check reads the specification as written. Probing your own contract by
mutating a condition and re-checking is a legitimate way to convince yourself a
clause carries weight, at the cost of a verification round each time.

Use the reference material below to interpret and repair failures.

## Move specification language

What follows is the working reference for this workflow, not a language tour.
For agents with internet access, the full Move Book is at
https://aptos.dev/en/build/smart-contracts/book.

### Function contracts

Attach conditions with `spec function_name { ... }`. If a function name is a
soft keyword, escape it as `spec @function_name { ... }`.

- `requires e` is a caller obligation evaluated in the pre-state.
- `aborts_if e` describes an allowed abort in the pre-state. With complete
  abort checking, the disjunction of all `aborts_if` clauses characterizes the
  function's abort behavior. No clauses means abort behavior is unspecified;
  use `aborts_if false` for a total function.
- `ensures e` is a normal-return guarantee evaluated in the post-state. Use
  `old(e)` for a pre-state value.
- `modifies global<T>(addr)` is a frame declaration for global state the
  function may change. An opaque function that can mutate global resources
  needs frames covering every such resource/address effect. A function that reads global
  state without writing any has no frame to declare, and inventing a `modifies`
  for it claims an effect the implementation does not have.

### Opaque and intrinsic functions

`pragma opaque` changes how callers are verified: callers use the function's
contract instead of its implementation. It does **not** disable verification of
the opaque function's own body. Preserve opaque pragmas while repairing their
contracts, and include complete result, abort, and global-state frame behavior.

`pragma intrinsic` identifies a function with built-in prover semantics. Do not
invent an opaque contract or body proof for an intrinsic merely because its Move
implementation is absent or unsuitable for ordinary verification.

### Specification expressions

- `result` denotes the return value in `ensures`.
- `global<T>(addr)` and `exists<T>(addr)` inspect global resources. A module's
  `spec_exists_at` wrapper should be modeled as the same existence fact; the
  prover is not subject to Move source visibility restrictions.
- Specifications use mathematical integers. Numeric bounds such as `MAX_U64`
  refer to Move values, while arithmetic in a spec expression is unbounded.
- Spec expressions operate on values, not references: use `v.field`, not `*v`
  or `&v`.

`old(e)` means the value at function entry. Do not use it in `requires` or
`aborts_if`, which are already pre-state expressions. In a loop invariant,
`old(x)` is valid only for a function parameter; save any other pre-loop value
in a local before the loop and mention that local directly.

### Loop invariants

Attach invariants to an ordinary loop:

```move
while (i < n) {
    // body
} spec {
    invariant i <= n;
    invariant acc == prefix_sum(values, i);
};
```

The prover checks invariant initialization, preservation, and the implication
from loop exit to the function contract.

For loops introduced by an inline higher-order iterator, use the prover's fold
logic and a `folds_of` invariant when its capture transformer is applicable.
Inside the iterator's loop invariant, `folds_of<f>(values, i)` summarizes a
unary callback over a prefix; `folds_of<f>(|j| (j, values[j]), i)` supplies an
explicit argument tuple. The predicate includes accumulated capture effects and
prefix no-abort behavior and is valid only as a loop invariant. If the fold
warning says it is not applicable, rewrite the iterator as an equivalent
ordinary loop and supply invariants. A simple ordinary accumulation loop may
conversely be clearer as an inline fold when the fold relation is expressible.

### Referring to callee behavior

For a non-inline named function or function value `f`, specifications can use:

- `requires_of<f>(args)`;
- `aborts_of<f>(args)`;
- `ensures_of<f>(args, result)`;
- `result_of<f>(args)`.

These predicates expose the callee's contract, including across modules. A
target specification may also call specification functions declared in its
dependencies, so retain the specification-level dependency closure as well as
the executable call closure.

### Separate specification files

A `.spec.move` file extends its corresponding module. Put helper functions,
lemmas, and module invariants in `spec module { ... }`; put conditions for a
Move function in `spec function_name { ... }`. There is no
`spec <module_name> { ... }` form.

### Inference markers

Use `[inferred]` on every inferred condition or invariant. WP may emit
`[inferred = vacuous]` when state is unconstrained and `[inferred = sathard]`
when a condition is likely to be difficult for SMT. Both mark unresolved
inference output.

### Reference

- [Move Specification Language](https://aptos.dev/en/build/smart-contracts/prover/spec-lang)

## Inspecting a Move package

- Use `move_package_status` for current compiler errors and
  warnings. Re-run it after edits; cached results make unchanged checks cheap.
- Use `move_package_manifest` to distinguish target sources
  (`source_paths`) from dependency sources (`dep_paths`).
- Use `move_package_query` instead of reading an entire
  package when a structural query answers the question:
  - `module_summary` for signatures and declarations;
  - `facts` for detailed declarations, attributes, and source locations;
  - `dep_graph` for module dependencies;
  - `call_graph` for package-wide calls;
  - `function_usage` with `function: "module::function"` for the direct and
    transitive calls and closure captures relevant to one function.

All tools take `package_path`, which must name the directory containing
`Move.toml`.

## Editing and simplifying specifications

Edit the contract rather than executable behavior. In an inference task, a
behavior-preserving loop/inline-HOF rewrite is appropriate only when it is
needed to express a sound invariant.

Revise a specification with targeted edits to the clauses that change. Rewriting
a whole module to adjust one condition risks disturbing unrelated user-written
code, and its output is dominated by text that was already correct.

### Simplification order

1. **Repair the abstraction first.** Resolve the loop or callee facts behind a
   `vacuous` or `sathard` clause before simplifying the resulting expression.
2. **Replace unbounded quantifier encodings.** Express frames with `modifies`
   and accumulations with a bounded or recursive helper when equivalent. If a
   quantifier is genuinely required, give it valid uninterpreted-function
   triggers.
3. **Normalize mechanical state expressions.** Replace nested `update_field`
   terms with direct struct construction when all fields are known. Consolidate
   unrolled cases into an equivalent general condition when justified.
4. **Simplify arithmetic and boolean structure.** Remove only clauses implied by
   retained clauses or language guarantees. Flatten repeated updates and factor
   repeated subexpressions without changing overflow or abort behavior.
5. **Check the replacement.** Keep `[inferred]` on inferred replacements and
   rerun the candidate check after each meaningful simplification. If it reports
   a verification failure, use a focused prover call to localize it.

Every simplification must preserve result, abort, precondition, and frame
semantics.

### Pragmas and trust boundaries

- Never disable or skip verification. `pragma verify = false`,
  `verify_duration_estimate`, invented partial abort coverage, axioms, and unproved
  assumptions cannot count as a repaired proof.
  Preserve partial coverage inherited from a partial callee as described in the
  inference rules.

## Proof guidance

Use proof structure when a correct contract times out or the solver cannot find
an intermediate fact:

- `assert e` exposes a useful sub-goal and must itself be proved.
- `apply lemma(args)` instantiates a proved lemma.
- `forall x: T {trigger(x)} apply lemma(x)` applies a lemma universally with
  an explicit trigger.
- `calc` records an equality or inequality chain.
- conditionals and value splits separate materially different proof cases.

Prefer small assertions and lemmas tied to the failing obligation. A lemma is a
proved module-level proposition, not an axiom:

```move
spec module {
    fun sum(values: vector<u64>, n: num): num {
        if (n == 0) { 0 } else { sum(values, n - 1) + values[n - 1] }
    }

    lemma sum_step(values: vector<u64>, n: num) {
        requires 0 < n && n <= len(values);
        ensures sum(values, n) == sum(values, n - 1) + values[n - 1];
    }
}
```

Attach `proof { ... }` after a function spec or lemma.

A lemma proof may apply the lemma itself, which is induction: the application
must decrease the lemma's measure, by default the tuple of its integer
parameters in declaration order, or as declared by `decreases e;` (one
expression, or a tuple ordered lexicographically). `apply pow_pos(b, e - 1)`
under `if (e > 0)` decreases `(b, e)`; an application at the same or a larger
instance, or one that can descend below zero, fails with "does not decrease
the measure". `forall ... apply` of a lemma from its own recursion group is
rejected.

Do not add `assume`, an axiom, or an unproved native helper: such constructs
replace a proof obligation rather than solve it and are forbidden in evaluation
mode.

Only uninterpreted-function applications are valid quantifier triggers. Prefer
quantifier-free formulations when they express the same contract.

### Instantiation weight

A recursive specification function is encoded as a defining axiom the solver
unrolls whenever one of its applications appears, and a `forall ... apply`
is a quantifier the solver instantiates at every match. Either can dominate a
timeout, which the analysis reports as a `definition of spec function` or a
`forall` entry. `[weight = N]` raises the cost the solver charges for each
instantiation, so it unrolls or instantiates only when nothing cheaper
remains; it changes no proof semantics.

```move
spec module {
    fun count(v: vector<u64>, x: num, k: num): num [weight = 20] {
        if (k <= 0) { 0 } else { count(v, x, k - 1) + (if (v[k - 1] == x) { 1 } else { 0 }) }
    }
}
spec f {
    ...
} proof {
    forall v: vector<u64>, i: num, j: num, x: num
        {count(update(update(v, i, v[j]), j, v[i]), x, len(v))} [weight = 20]
        apply count_swap(v, i, j, x);
}
```

Use it when the facts the proof needs come from lemmas applied one step at a
time and the definition should not be unrolled on its own. A weight of 20 is a
reasonable start. Without it the same contract can prove but leave every
refutation -- a wrong implementation against a correct contract -- exhausting
the budget instead of failing.

### Toolchain capabilities and limits

Establish these from the reference rather than by probing the compiler with
trial declarations.

- **Pragmas are context-specific.** An invalid `pragma` is a compile error whose
  diagnostic lists every pragma valid at that position. Read that list instead
  of guessing further names.
- **Induction is a recursive lemma.** A lemma may `apply` itself (or a
  lemma of the same group) in its proof at a smaller instance:
  `lemma pow_pos(b: num, e: num) { ensures ... } proof { if (e > 0) { apply pow_pos(b, e - 1); } }`.
  Every such application must decrease the lemma's measure, by default the
  tuple of its integer parameters in declaration order, or as declared with
  `decreases e;` / `decreases (e1, e2);` (lexicographic); the prover reports
  "does not decrease the measure" at the application otherwise. `forall ...
  apply` of a lemma from its own group is rejected. Outside lemmas there is
  still no induction: a quantified fact about `n` repetitions has to be
  arranged so the solver only ever needs one step of it.
- **Align a recursive spec helper with the loop.** When a closed form such as
  `base * 2^n` is unprovable, define a helper whose recursion performs exactly
  one iteration of the loop and state the invariant in terms of it. Each proof
  obligation then unfolds definitionally: the invariant is preserved by one
  helper step, and the loop-exit condition makes the postcondition immediate.
  Saturating the helper at the overflow bound lets the same definition express
  exact abort behavior.
- **Keep helper recursion single.** Two mutually reinforcing recursive helpers
  in one contract multiply quantifier instantiations and commonly time out
  where one recursion-aligned helper proves quickly.

## Move Prover reference

Call `move_package_verify` with `package_path` and an explicit
timeout. Its optional controls are:

- `filter: "module"`, `"module::function"`, or `"address::module::function"`
  for a focused proof (numeric or named address; bare module names must be unambiguous);
- `exclude: [...]` to omit known targets temporarily while diagnosing others;
- `split_vcs_by_assert: true` to identify which assertion in a function is hard
  or false;
- `error_limit` to bound counterexample output.

Filters and exclusions are diagnostic conveniences. A final proof must cover
the user's requested scope, and an unmatched or excluded target is not success.

### Reading a counterexample

A counterexample shows the frames of one failing execution with the values the
solver chose. Read the notation before drawing conclusions from it.

- **Named locals** appear under their source names, and `result` is the return
  value. Reason from these first.
- **`$t<N>`** is a compiler- or prover-introduced temporary with no source
  counterpart. Read it as an intermediate value at that step; do not look for
  it in the source or name it in a specification.
- **A frame marked `(spec)`** lies inside the function's spec block, so it
  evaluates a condition rather than executed code.
- **`<generic>`** is the value of a type parameter, withheld because it cannot
  affect the outcome.
- **A function value** prints as the source entity it came from. A closure
  shows the function it packs and its captured arguments by parameter name.
  `<value of function field ...>` and `<value of function parameter ...>` are
  values the solver chose for that field or parameter, and the trailing `#n`
  distinguishes distinct values of the same field, so a repeated `#n` is the
  same value. Their behavior is only what the specification states about the
  carrier, so give it exact `result_of` and `aborts_of` conditions.
  ``<some `T`>`` is a function of type `T` the solver picked with nothing
  tying it to a source entity.

### Interpreting abort codes

Before diagnosing an abort-code mismatch, read the dependency's `error.move`
(in this repository, `aptos-move/framework/move-stdlib/sources/error.move`).
The `std::error::canonical` contract is deliberately opaque: its `[abstract]`
postcondition returns only the category, while its `[concrete]` postcondition
describes the runtime encoding `(category << 16) + reason`.

For example, `error::invalid_argument(40)` encodes `0x10028` at runtime, but
under that abstract contract the prover sees category `0x1`
(`error::INVALID_ARGUMENT`). A category-only counterexample is therefore not
by itself a tool bug or evidence that the runtime reason was lost.

Trace the helper and the contract actually used by the proof before choosing
an `aborts_if ... with ...` code. Where the abstract contract applies, use its
category constant; runtime unit tests still use the concrete encoded code.
Do not apply category decoding to arbitrary module-local abort codes, change
stdlib contracts, drop abort-code checks, or enable partial abort checking
just to make a mismatch disappear.

### Classify before editing

- **Compilation/spec-language error:** fix syntax, name resolution, placement,
  or invalid `old()` use before reasoning about the proof.
- **Postcondition counterexample:** trace the normal path. Determine whether the
  implementation violates the intended contract, a callee contract is too weak,
  or a loop invariant loses the needed fact.
- **Abort counterexample:** enumerate direct and transitive aborts, including
  arithmetic, indexing, resources, and opaque callees. Complete the exact abort
  behavior, retaining inherited partial abort coverage only where the callee
  contract itself is partial.
- **Frame failure:** compare executable global writes with `modifies` clauses,
  especially across opaque callees.
- **Invariant failure:** separately check initialization, preservation, and the
  loop-exit implication. A stronger invariant is useful only if the body proves
  it.
- **Timeout/out of resources:** treat the contract as unresolved, not false and
  not verified.

Never make a desired property disappear to obtain a green prover result. A new
precondition is valid only if it reflects the intended API, not because it
excludes the counterexample.

### Reading timeout analysis

A timeout diagnostic carries evidence from a replay: the prover re-runs the
captured query under a profiling solver instead of reporting the original run.
The counts therefore describe the same obligation without being exact, and a
`+` marks a lower bound.

- **Quantifier activity** ranks what the solver instantiated, naming a source
  location for each entry. Reduce the instantiations that entry needs instead
  of raising the budget. A `definition of spec function` entry points at that
  helper: align its recursion with the loop so one obligation unfolds one
  step, and keep the recursion single. A `forall` entry points at a written
  quantifier: give it a valid trigger, or replace it with a frame or a
  bounded relation.
- **Nonlinear arithmetic activity**, reported through the `arith-nla-*`
  counters, means the search is in nonlinear arithmetic. Prefer additive
  recurrences to closed forms and keep symbolic products out of invariants.
- **Mixed activity** reports both. Address the top named quantifier first and
  then the arithmetic; the two compound.
- **Incomplete or partial evidence** still ranks the quantifiers, but the
  classification is unsettled. Do not read a missing counter as evidence that
  its cause is absent.
- **Unavailable evidence** means the replay could not run. Fall back to
  isolating the obligation with `split_vcs_by_assert` and a narrower filter.

A named source location is the place to change. A timeout leaves the contract
unresolved either way, so never answer one by weakening it.

### Timeout strategy

Where the analysis names a definition, aim the work there; otherwise work
from the smallest failing function. Preserve contract meaning:

1. Simplify WP-generated or hand-written expressions: remove proven redundancy,
   factor common terms, replace mechanical updates, and repair vacuous or
   `sathard` loop output.
2. Use `split_vcs_by_assert` and small `assert` proof hints to expose an
   intermediate fact or separate cases.
3. Replace hostile unbounded quantifiers with equivalent frames, bounded
   relations, or recursive helpers. Add valid triggers when quantification is
   unavoidable.
4. Prefer additive recurrences to nonlinear closed forms. Do not wrap built-in
   arithmetic in a helper merely to obscure it.
5. Prove reusable facts as lemmas and instantiate them explicitly with `apply`.
   Put `[weight = N]` on a recursive helper or a `forall ... apply` that the
   analysis names, so the solver stops unrolling or instantiating it on its
   own.
6. Increase the per-condition timeout when warranted. The usual retry guidance
   is 10 seconds, not a hard limit.

Data invariants and global update invariants may help when they express genuine
properties preserved by **every** constructor or mutator. They create new proof
obligations across the module, so do not add them as local solver hints without
checking that global semantic commitment.

