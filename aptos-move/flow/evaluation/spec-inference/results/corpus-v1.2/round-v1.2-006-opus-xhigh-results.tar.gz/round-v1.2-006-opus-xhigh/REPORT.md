# Corpus v1.2 round 006: Opus xhigh efficiency report

This report analyzes `round-v1.2-006-opus-xhigh`: 20 Aptos Framework
specification-inference tasks, three arms, four replicates, and 240 valid
experimental cells. The primary question is efficiency. Quality measurements
are included to ensure that lower resource use is not merely the result of
lower success.

## Conclusion

**Agent-only was the most efficient arm in this round. Hybrid-flexible was
effectively tied with it, while hybrid-guided was materially less efficient.**

- Every arm achieved the same operational success rate: **72/80 (90%)**.
- Agent-only cost **$320.42**. Flexible cost only **$0.31 more (+0.10%)**;
  guided cost **$20.25 more (+6.32%)**.
- Including the cost of failures, one operational success cost **$4.450** for
  agent-only, **$4.454** for flexible, and **$4.731** for guided.
- On the 18 tasks where every cell in every arm succeeded, flexible was
  **2.1% more expensive** and **1.2% slower** than agent-only. Guided was
  **14.8% more expensive** and **13.7% slower**.
- Flexible and guided emitted about 4.5% fewer output tokens overall than
  agent-only, but their larger repeatedly cached input offset that saving.
  Guided processed **16.5% more total input**, made **14.0% more model turns**,
  and made **44.2% more Flow tool calls** than agent-only.

There is therefore no measured success advantage that pays for guided's
overhead on this corpus. Flexible is a reasonable cost tie, but it does not
show an efficiency gain.

## Overall efficiency

Dollar amounts are Anthropic API-list-price-equivalent SDK estimates, not
observed subscription charges. “Input” is fresh input plus cache creation plus
cache reads. Thinking tokens are already included in output.

| Arm | Operational success | Total cost | Mean / median cost | Cost per success | Total input | Output | Summed wall | Median wall |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Agent-only | 72/80 | $320.4174 | $4.0052 / $2.3762 | $4.4502 | 271,010,558 | 3,149,894 | 14.71 h | 5.74 min |
| Hybrid-flexible | 72/80 | $320.7232 | $4.0090 / $2.4697 | $4.4545 | 286,374,747 | 3,008,161 | 15.11 h | 6.25 min |
| Hybrid-guided | 72/80 | $340.6627 | $4.2583 / $2.6188 | $4.7314 | 315,672,149 | 3,004,833 | 15.73 h | 7.06 min |
| **All** | **216/240** | **$981.8033** | **$4.0908 / $2.4971** | **$4.5454** | **873,057,454** | **9,162,888** | **45.55 h** | **6.47 min** |

Summed wall is the sum of controller wall time across cells. Four cells ran
concurrently. The first valid cell started at 2026-09-10 12:17 UTC and the
last ended at 2026-09-11 04:33 UTC, a **16 h 16 min calendar span** that
includes quota interruptions and manual resumptions. It should not be used as
a pure throughput measurement.

### Success-conditioned and wasted work

The same two tasks failed in every arm, so all arms spent substantial resources
without producing an accepted result.

| Arm | Accepted-cell cost | Mean accepted-cell cost / wall | Failed-cell cost | Mean failed-cell cost / wall |
| --- | ---: | ---: | ---: | ---: |
| Agent-only | $195.6930 | $2.7180 / 6.86 min | $124.7244 | $15.5906 / 48.66 min |
| Hybrid-flexible | $199.8852 | $2.7762 / 6.94 min | $120.8380 | $15.1048 / 50.87 min |
| Hybrid-guided | $224.7482 | $3.1215 / 7.79 min | $115.9145 | $14.4893 / 47.83 min |

The 24 failed cells were only 10% of cells but consumed **$361.48 (36.8%)**
of valid-cell cost and about **19.65 h (43.1%)** of summed wall time. Guided
stopped somewhat more cheaply on these failures, which reduces its aggregate
premium. On the 18 universally successful tasks, its cost premium over
agent-only is $0.4035 per cell (+14.8%), rather than the all-task $0.2531
(+6.3%).

## Why the hybrid arms were not cheaper

### Token and turn accounting

| Arm | Fresh input | Cache creation | Cache reads | Output | Thinking | Model turns |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Agent-only | 4,712 | 11,173,008 | 259,832,838 | 3,149,894 | 2,181,363 | 2,798 |
| Hybrid-flexible | 5,020 | 10,760,027 | 275,609,700 | 3,008,161 | 2,028,355 | 2,928 |
| Hybrid-guided | 5,576 | 11,334,815 | 304,331,758 | 3,004,833 | 1,928,780 | 3,191 |

Cache reads represent 95.9%, 96.2%, and 96.4% of processed input for
agent-only, flexible, and guided respectively. Relative to agent-only:

- Flexible read 15.78 million more cached-input tokens (+6.1%), but saved
  0.41 million cache-creation tokens and 0.14 million output tokens. These
  effects almost exactly canceled in dollar cost.
- Guided read 44.50 million more cached-input tokens (+17.1%) and created
  0.16 million more cached-input tokens, while saving only 0.15 million output
  tokens. Its output saving was worth about $3.63; its extra cache reads alone
  cost about $22.25.
- Guided's output was not longer than agent-only's in aggregate. The overhead
  came from repeatedly carrying a larger conversation through more turns.

The list-price decomposition makes this explicit:

| Cost component | Agent-only | Hybrid-flexible | Hybrid-guided |
| --- | ---: | ---: | ---: |
| Fresh input | $0.0236 | $0.0251 | $0.0279 |
| One-hour cache creation | $111.7301 | $107.6003 | $113.3482 |
| Cache reads | $129.9164 | $137.8049 | $152.1659 |
| Output, including thinking | $78.7474 | $75.2040 | $75.1208 |
| SDK-reported total | **$320.4174** | **$320.7232** | **$340.6627** |

One flexible cell's aggregate usage counters under-report its per-model SDK
receipt by 170,995 input tokens and 138 output tokens, or $0.0890. The table
keeps the recorded aggregate counters and the authoritative SDK dollar total;
the discrepancy is 0.028% of flexible cost and cannot affect the conclusion.

### Flow activity

| Flow operation | Agent-only | Hybrid-flexible | Hybrid-guided |
| --- | ---: | ---: | ---: |
| Package manifest | 80 | 80 | 80 |
| Package query | 102 | 107 | 96 |
| Package status | 59 | 73 | 79 |
| Verify | 171 | 187 | 218 |
| WP | 0 | 87 | 171 |
| Spec check | 151 | 142 | 168 |
| **All Flow calls** | **563** | **676** | **812** |

Flexible made 20.1% more Flow calls than agent-only; guided made 44.2% more.
In particular, guided made 47 more verification calls and 171 WP calls. These
calls add tool results and follow-up turns to the transcript, which are then
read again from the prompt cache. This is the most direct telemetry-supported
explanation for guided's extra cached input and cost.

The run used `--no-wp-simplification`: agents were not instructed to perform
the optional WP simplification step. Consequently, that optional step cannot
explain the extra turns observed here. Internal processing performed by WP is
not disabled by this flag.

## Task-level efficiency

Each cell shows mean API-equivalent cost and mean controller wall time over
four replicas. `0/4` marks the two tasks on which no arm produced an
operational success.

| Task | Result per arm | Agent-only | Hybrid-flexible | Hybrid-guided |
| --- | ---: | ---: | ---: | ---: |
| AF-account-025 | 4/4 | $1.816 / 4.5m | $1.506 / 3.4m | $2.258 / 5.4m |
| AF-account-036 | 4/4 | $2.254 / 4.8m | $1.937 / 4.4m | $2.771 / 6.2m |
| AF-aptos-coin-010 | 4/4 | $5.670 / 14.5m | $5.650 / 14.1m | $7.562 / 18.9m |
| AF-aptos-governance-034 | 4/4 | $1.719 / 4.4m | $2.478 / 5.7m | $2.479 / 5.7m |
| AF-code-017 | 0/4 | $15.742 / 57.8m | $15.102 / 57.9m | $15.849 / 60.5m |
| AF-coin-003 | 4/4 | $2.972 / 7.4m | $3.174 / 7.8m | $3.597 / 8.9m |
| AF-epoch-timeout-config-007 | 4/4 | $2.769 / 7.8m | $2.571 / 7.5m | $3.174 / 10.2m |
| AF-gas-schedule-002 | 4/4 | $2.114 / 6.2m | $2.460 / 7.3m | $2.459 / 6.9m |
| AF-multisig-account-015 | 0/4 | $15.439 / 39.5m | $15.108 / 43.9m | $13.130 / 35.2m |
| AF-multisig-account-067 | 4/4 | $2.235 / 5.9m | $2.126 / 5.7m | $2.641 / 7.3m |
| AF-stake-004 | 4/4 | $3.642 / 6.9m | $3.662 / 6.1m | $5.292 / 8.1m |
| AF-transaction-fee-010 | 4/4 | $2.016 / 4.7m | $2.250 / 5.4m | $1.845 / 5.3m |
| AF-vesting-042 | 4/4 | $1.114 / 2.4m | $1.200 / 2.7m | $1.614 / 3.8m |
| AX-bulk-order-book-009 | 4/4 | $1.493 / 2.5m | $1.698 / 3.3m | $1.935 / 3.9m |
| AX-dead-mans-switch-operations-001 | 4/4 | $7.933 / 18.5m | $8.641 / 21.7m | $8.500 / 19.1m |
| AX-native-position-types-005 | 4/4 | $0.969 / 2.8m | $1.207 / 3.7m | $0.674 / 2.0m |
| AX-order-book-006 | 4/4 | $1.452 / 2.8m | $1.662 / 3.3m | $1.767 / 3.8m |
| AX-pending-order-book-index-006 | 4/4 | $4.903 / 17.2m | $3.291 / 10.9m | $3.166 / 12.4m |
| AX-price-time-index-014 | 4/4 | $1.099 / 2.5m | $1.512 / 3.4m | $1.763 / 4.2m |
| AX-trading-native-capability-010 | 4/4 | $2.752 / 7.7m | $2.947 / 8.6m | $2.691 / 8.4m |

Guided was more expensive than agent-only on 15 of 20 task means. Its largest
successful-task premiums over four replicas came from
`AF-aptos-coin-010` (+$7.57 total), `AF-stake-004` (+$6.60), and
`AF-aptos-governance-034` (+$3.04). Its largest saving was on
`AX-pending-order-book-index-006` (-$6.95). Flexible's task-level differences
were smaller and largely canceled.

Task-clustered bootstrap intervals are exploratory because there are only 20
tasks. Across all tasks, flexible minus agent-only cost was +$0.0038 per cell
(95% interval -$0.229 to +$0.202); guided was +$0.2531 (-$0.177 to +$0.615).
On the 18 universally successful tasks, guided's +$0.4035 cost difference had
an interval of +$0.050 to +$0.730, and its +0.94-minute wall difference had an
interval of +0.08 to +1.66 minutes. Flexible's corresponding intervals still
crossed zero.

## Outcome and quality context

| Terminal outcome | Agent-only | Hybrid-flexible | Hybrid-guided | Total |
| --- | ---: | ---: | ---: | ---: |
| Operational success | 72 | 72 | 72 | 216 |
| Wall budget exhausted | 3 | 3 | 4 | 10 |
| Controller-turn budget exhausted | 2 | 1 | 1 | 4 |
| Output-token budget exhausted | 2 | 1 | 1 | 4 |
| Repeated forbidden weakening | 1 | 3 | 2 | 6 |

Held-out scoring produced 190 scored cells and no disqualifications:

- Agent-only: **64/64** scored cells were strict successes.
- Hybrid-flexible: **64/64** were strict successes.
- Hybrid-guided: **60/62** were strict successes; two
  `AF-epoch-timeout-config-007` cells killed two of three essential mutants.
- All 24 cells for `AX-dead-mans-switch-operations-001` and
  `AX-price-time-index-014` were not scorable because their scoring sets had
  fewer than the required three independently reviewed essential mutants.
- Two accepted guided `AF-aptos-governance-034` cells were not scorable. The
  direct scoring prover observed an inherited module-level
  `pragma verify = false`, although candidate acceptance had passed. This is a
  judge/scorer consistency issue, so those cells must not be interpreted as
  evidence about guided quality.

The scoring gaps prevent a complete strict-success efficiency comparison, but
the measurable results do not reveal a hybrid quality advantage that would
offset the observed overhead.

## Comparison with round 005

Relative to the prior Opus xhigh v1.2 round, round 006 had one additional
operational success and cost **$981.80 rather than $1,054.56 (-6.9%)**. Total
input fell 8.0%, output fell 7.4%, and model turns fell from 9,272 to 8,917
(-3.8%), while summed wall time was almost unchanged (45.55 h versus 45.28 h).
The flexible/agent cost gap shrank from $13.41 to $0.31 and the guided/agent
gap from $38.17 to $20.25. This is a descriptive comparison: the apparatus
commit and run conditions changed, so it is not a controlled estimate.

## Apparatus and provenance

- Model `claude-opus-5`, effort `xhigh`; Claude Code 2.1.258 and Agent SDK
  0.2.139.
- 20 tasks, three arms, four replicates, concurrency four.
- 180,000 output-token and 3,600-second wall budgets per cell; six controller
  turns and up to 60 model turns per controller turn.
- `--no-package-cache`, `--no-wp-simplification`, and no refutation feedback.
- Operational and eventual verification timeout: 40 seconds. Intermediate
  guidance: 5 then 10 seconds, overridable by the agent. MBQI was not used.
- Apparatus source commit:
  `86ab965be98a4e232664886f2544e9e1f8a99088`.
- Frozen `move-flow` SHA-256:
  `1fbb74be97fdbbc3bcf38f1253468faad0f81e748f054c1a892a6479a6f42e15`.
- Prepared state retained on `origin/snapshots/corpus1.2-006-opus-prepared`.

Seven provider session-limit attempts were quarantined and cleanly rerun.
They add **$18.3641** of identifiable API-equivalent recovery cost, bringing
round execution to **$1,000.1675** including quarantined attempts. Two tiny
provider probes add $0.0341, for **$1,000.2016 observed identifiable usage**.
Nine killed in-flight attempts produced no final receipt and therefore cannot
be priced. Foundry was only probed and was not used for experimental cells.
The direct Anthropic credential changed from the personal to enterprise
subscription during recovery; the switch occurred at an arm-balanced boundary
(44 valid cells per arm), and both credentials reported the same canonical
first-party model.

Raw transcripts, candidate trees, judge results, mutation scores, and SDK
receipts remain under the round's `runs/` directory. Quarantined provider-limit
attempts remain under `invalid-infrastructure/` and are excluded from every
arm comparison above.

## Permanent archive contents

The compact permanent archive contains:

- `cells.csv`: all 240 cell outcomes, usage, timing, scoring, Flow activity,
  model receipt, and credential-phase fields.
- `tasks.csv`: task-by-arm efficiency aggregates.
- `analysis.json`: complete arm distributions, success-conditioned metrics,
  task-clustered contrasts, scoring, provider phases, and recovery accounting.
- `summary.json` and `DEBRIEF.md`: mechanically mined turn, tool, repair, and
  verifier-failure data.
- `mutation-summary.json` and `scoring-summary.json`: raw and compact held-out
  scoring records.
- `provider-execution.json` and `infrastructure.json`: account cutover,
  Foundry probe/deployment facts, invalid attempts, and identifiable costs.
- `provenance.json`, `CORPUS.json`, `config.json`, and `preparation.json`:
  pinned apparatus, corpus, configuration, and preparation identity.
- `SHA256SUMS`: integrity digests for every other archived file.
