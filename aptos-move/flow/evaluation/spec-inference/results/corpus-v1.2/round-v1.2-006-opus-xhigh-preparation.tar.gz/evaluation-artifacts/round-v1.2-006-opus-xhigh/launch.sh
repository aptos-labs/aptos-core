#!/usr/bin/env bash
set -euo pipefail
EVAL_ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$EVAL_ROOT"
ROUND_DIR="$EVAL_ROOT/evaluation-artifacts/round-v1.2-006-opus-xhigh"
EXPECTED_FLOW_SHA256="1fbb74be97fdbbc3bcf38f1253468faad0f81e748f054c1a892a6479a6f42e15"
ACTUAL_FLOW_SHA256="$(sha256sum "$ROUND_DIR/bin/move-flow" | cut -d ' ' -f 1)"
if [[ "$ACTUAL_FLOW_SHA256" != "$EXPECTED_FLOW_SHA256" ]]; then
  echo "frozen move-flow digest mismatch" >&2
  exit 1
fi
exec "$ROUND_DIR/with-env.sh" .venv/bin/python -m harness.pilot_run \
  --config "$ROUND_DIR/config.json" \
  --schedule-dir "$ROUND_DIR/schedule" \
  --artifacts-dir "$ROUND_DIR/runs" \
  --sandbox-wrapper scripts/pilot-sandbox \
  --concurrency 4 \
  --report "$ROUND_DIR/launch-report.json"
