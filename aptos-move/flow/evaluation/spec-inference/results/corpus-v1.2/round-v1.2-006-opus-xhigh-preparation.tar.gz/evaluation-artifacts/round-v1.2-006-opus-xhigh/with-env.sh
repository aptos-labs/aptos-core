#!/bin/sh
set -eu
export PATH="/home/wrw/aptos-core/.worktrees/dev2/aptos-move/flow/evaluation/spec-inference/evaluation-artifacts/round-v1.2-006-opus-xhigh/bin:/home/wrw/.local/bin:/usr/local/bin:/usr/bin:/bin"
export BOOGIE_EXE=/home/wrw/.local/bin/boogie
export Z3_EXE=/home/wrw/.local/bin/z3
export MOVE_INFERENCE_CLAUDE_TOKEN_FILE=/home/wrw/shared/config/ant-apt.key
exec "/home/wrw/aptos-core/.worktrees/dev2/aptos-move/flow/evaluation/spec-inference/.venv/bin/python" -m harness.model_profile exec --config "/home/wrw/aptos-core/.worktrees/dev2/aptos-move/flow/evaluation/spec-inference/evaluation-artifacts/round-v1.2-006-opus-xhigh/config.json" -- "$@"
