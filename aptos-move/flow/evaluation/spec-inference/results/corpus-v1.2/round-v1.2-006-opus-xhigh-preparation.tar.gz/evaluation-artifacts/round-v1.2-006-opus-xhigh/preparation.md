# Corpus v1.2 round 006 Opus xhigh: ready, not launched

- Opus 5 (`claude-opus-5`), effort **xhigh**, with 180,000 output tokens and
  a 3,600-second wall limit per cell.
- 20 tasks × 3 arms × 4 replicates = 240 cells in 80 randomized blocks.
- Concurrency 4, fixed by `launch.sh`.
- No package cache: the controller always starts the Flow MCP server with
  `--no-package-cache`.
- No WP simplification guidance: every rendered arm records
  `no_wp_simplification: true`.
- No refutation: the launch command deliberately omits
  `--refutation-mutants-root`, so agents receive no mutant feedback.
- The 57 disqualification mutants and 60 scoring mutants remain withheld for
  post-run gating and scoring.
- Intermediate verification guidance is 5/10 seconds; agents may override it.
  Operational and eventual judging remain at 40 seconds.
- Fresh screening passed all 20 tasks with the frozen apparatus. All 10
  preflight checks pass. No model calls have been made.

The run source is `86ab965be98a4e232664886f2544e9e1f8a99088`; the frozen
`move-flow` binary has SHA-256
`1fbb74be97fdbbc3bcf38f1253468faad0f81e748f054c1a892a6479a6f42e15`.
The source commit is retained on `origin/snapshots/corpus3.2-run5-opus-source`
and `origin/wrwg/inf-sonnet-profile-results`. The preparation archive is also
committed and pushed to a dedicated origin snapshot branch.

From the evaluation directory, launch only when requested:

```sh
bash evaluation-artifacts/round-v1.2-006-opus-xhigh/launch.sh
```

The launcher refers to the user's local OAuth token file; no credential value
is stored in the preparation or archive.
