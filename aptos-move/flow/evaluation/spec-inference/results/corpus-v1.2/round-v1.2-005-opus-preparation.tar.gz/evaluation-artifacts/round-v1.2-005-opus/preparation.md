# v1.2 round 005: Opus preparation

Status: prepared; final preflight passed; no model sessions launched.

- Model: `claude-opus-5`, subscription profile, effort `max`.
- Output-token budget: 180,000 per cell.
- Replicates: 4; concurrency: 4; all 20 selected tasks and 3 arms (240 cells).
- Hybrid plugins rendered with `--no-wp-simplification`.
- Evaluation controller starts MCP with `--no-package-cache`.
- Intermediate verification guidance: 5 seconds initially, 10 seconds on retry;
  agents may override. Operational/eventual judging budgets remain 40 seconds.
- Apparatus source: `9c6a3253563faa0eb530e30f9b9afb75e667aee4`, after restacking
  prover repair `bc8396284e`. The Etna pin was not changed.
- Tool binary: repository `target/ci/move-flow`, built with profile `ci`.

Fresh treatment-blind screening passed all 20 selected samples, with no
timeouts/exclusions or apparatus failures. All authored references proved and
passed the vacuity check. Fifteen tasks remain WP-hard (agent repair work),
which is distinct from corpus admission failure. Harness tests: 384 run,
one skipped, no failures.

Fresh treatment-blind screening is recorded under
`corpus-v1.2/screening/state-label-repair-005/`. The screened manifest there is
raw evidence whose inherited relative package paths refer to the corpus root.
Scheduling uses the corpus-root manifest and the refreshed `screening/summary.json`.

Completed readiness checks:

- All 117 mutations rejected by fresh references: 60 scoring and 57 withheld
  disqualification mutations, across 40 sets. No survivors or inconclusive
  checks; existing review approvals and mutation definitions are unchanged.
- Local OAuth credential/version preflight passed using the user-provided token
  file. The launcher references its path; no credential values are archived.
- Schedule: 240 cells, 80 randomized blocks, 4 replicates. Full preflight passed
  all 10 checks, including sandbox isolation, prover execution, and schedule identity.
- The user approved running before landing and retaining
  `origin/snapshots/corpus-v1.2-005-opus`. The final preparation commit retains
  apparatus commit `9c6a3253563faa0eb530e30f9b9afb75e667aee4` as an ancestor.
  The scheduler's mainline-only durability flag remains false: a retained
  snapshot is the explicit alternative, not a claim that this work has landed.

Launch with `bash evaluation-artifacts/round-v1.2-005-opus/launch.sh` from the
evaluation directory. This preparation did not probe model availability or
subscription quota with a paid model request. The launcher repeats preflight.

No existing round artifacts were overwritten or reused.
