# Corpus v1.2 round 005: Opus xhigh execution report

This is the execution report for `round-v1.2-005-opus-xhigh`, the completed
Opus 5 round. The sibling directory `round-v1.2-005-opus` is the superseded
max-effort preparation; no model session was launched from it.

## Result at a glance

All **240 scheduled cells** produced valid terminal outcomes. There were **215
operational successes (89.6%)** and no infrastructure failures in the final
cell set. Operational acceptance is not yet strict experimental success:
held-out mutation and disqualification scoring has not run, so this report
does not claim specification adequacy.

| Arm | Operational success | API-equivalent cost | Mean / median cost | Total input | Output | Summed wall time | Median wall time |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Agent-only | 72/80 | $334.3259 | $4.1791 / $2.3801 | 286,420,615 | 3,459,728 | 15.12 h | 5.28 min |
| Hybrid-flexible | 72/80 | $347.7365 | $4.3467 / $2.4577 | 315,216,856 | 3,303,257 | 15.05 h | 5.58 min |
| Hybrid-guided | 71/80 | $372.4969 | $4.6562 / $2.5510 | 347,080,534 | 3,133,795 | 15.11 h | 6.02 min |
| **All** | **215/240** | **$1,054.5594** | **$4.3940 / $2.4413** | **948,718,005** | **9,896,780** | **45.28 h** | **5.79 min** |

Input is fresh input plus cache creation plus cache reads. Thinking tokens are
already included in output and must not be added again. Summed wall time is
cell time; four cells ran concurrently. The calendar span from the first
valid-cell start to the last end was **12 h 47 min 33 s**, including provider
interruptions and pauses.

## Terminal outcomes

| Outcome | Cells |
| --- | ---: |
| Operational success | 215 |
| Wall-budget exhausted | 11 |
| Controller-turn budget exhausted | 6 |
| Output-token budget exhausted | 6 |
| Repeated forbidden weakening | 2 |

The 25 nonsuccesses remain in every resource and arm total. They must not be
dropped when comparing workflow cost: failed cells averaged much more time
and cost than successful cells.

| Arm | Successful-cell mean cost / wall | Nonsuccess mean cost / wall |
| --- | ---: | ---: |
| Agent-only | $2.8174 / 6.43 min | $16.4339 / 55.53 min |
| Hybrid-flexible | $2.9315 / 6.67 min | $17.0832 / 52.85 min |
| Hybrid-guided | $2.9295 / 6.47 min | $18.2783 / 49.67 min |

Outcome-conditioned means are descriptive. Success is affected by the arm,
so these rows are not treatment-effect estimates.

## Token and timing accounting

The valid cells recorded **15,720 fresh-input**, **35,022,119 cache-creation**,
**913,680,166 cache-read**, and **9,896,780 output tokens**. Reported thinking
was **6,788,747 tokens**, or 68.6% of output. Cache reads were 96.3% of all
input processed.

| Arm | Fresh input | Cache creation | Cache reads | Output | Thinking | API time | Model turns |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Agent-only | 4,850 | 11,010,591 | 275,405,174 | 3,459,728 | 2,478,638 | 12.36 h | 2,980 |
| Hybrid-flexible | 5,180 | 11,318,251 | 303,893,425 | 3,303,257 | 2,252,405 | 11.78 h | 3,072 |
| Hybrid-guided | 5,690 | 12,693,277 | 334,381,567 | 3,133,795 | 2,057,704 | 11.37 h | 3,220 |

The batch made 9,298 logged tool calls, including 1,070 verifier calls, 1,100
repair iterations, and 1,391 targeted edits. Agent-only made no WP calls;
hybrid-flexible made **79 WP calls in 59 sessions**; hybrid-guided made **171
WP calls in all 80 sessions**.

| Arm | Tool calls | Verifier calls | Repair iterations | Targeted edits |
| --- | ---: | ---: | ---: | ---: |
| Agent-only | 2,989 | 306 | 313 | 395 |
| Hybrid-flexible | 3,099 | 366 | 378 | 466 |
| Hybrid-guided | 3,210 | 398 | 409 | 530 |

## Cost meaning

All dollar values are **Anthropic API-list-price-equivalent estimates**, not
observed subscription invoice charges. The calculation uses, per million
tokens, $5 fresh input, $10 one-hour cache creation, $6.25 five-minute cache
creation, $0.50 cache reads, and $25 output. Every recorded cache write was a
one-hour write. Per-cell SDK estimates reconcile with recomputation from the
token counters.

| Cost component | Agent-only | Hybrid-flexible | Hybrid-guided |
| --- | ---: | ---: | ---: |
| Fresh input | $0.0243 | $0.0259 | $0.0285 |
| One-hour cache creation | $110.1059 | $113.1825 | $126.9328 |
| Cache reads | $137.7026 | $151.9467 | $167.1908 |
| Output, including thinking | $86.4932 | $82.5814 | $78.3449 |
| **Total** | **$334.3259** | **$347.7365** | **$372.4969** |

Recovery outside the final 240 cells adds **$7.2034** of identifiable
API-equivalent usage: $6.3474 from three attempts stopped by the subscription
session limit and $0.8560 from two successful authentication probes. Three
invalid-OAuth attempts used no tokens. Thus the observed launch-wide estimate,
including recovery, is **$1,061.7627**. Invalid attempts were archived and
rerun from clean cell directories; they do not enter arm comparisons.

## Why agent-only was cheaper

Agent-only was cheaper despite producing the most output and spending the
most reported API time. Its advantage came from carrying less cached context:

- Flexible cost $13.4106 more than agent-only (+4.0% relative to agent-only).
  The difference consists of +$3.0766 cache creation, +$14.2441 cache reads,
  and -$3.9118 output, with fresh input negligible.
- Guided cost $38.1709 more than agent-only (+11.4%). The difference consists
  of +$16.8269 cache creation, +$29.4882 cache reads, and -$8.1483 output.
- Relative to agent-only, flexible processed 28.8 million more input tokens
  and guided 60.7 million more, while producing 156 thousand and 326 thousand
  fewer output tokens respectively.
- The hybrids made more model turns, verifier calls, repairs, and edits. WP
  results and the subsequent verification/repair conversation enlarge the
  transcript that is repeatedly read from cache on later turns. This is the
  most direct mechanism supported by the telemetry; cache-token totals alone
  do not identify every contributing prompt segment.

The paired, task-clustered estimates are exploratory. Flexible minus
agent-only is **+$0.1676 per cell** with bootstrap 95% interval
**[-$0.1426, +$0.4602]**. Guided minus agent-only is **+$0.4771** with interval
**[-$0.1879, +$1.3267]**. Both intervals cross zero, so this round does not
establish a corpus-wide cost difference.

The guided aggregate is also highly concentrated. `AF-aptos-coin-010`
contributes about $26.94, or 70.6%, of the guided/agent total gap, and
`AF-stake-004` contributes about $11.26. The other 18 tasks almost cancel in
aggregate. On the former task guided had one output-budget failure and a mean
cost of $11.8181 versus $5.0837 for agent-only; on the latter all cells
succeeded, but guided still averaged $5.9365 versus $3.1205.

## Apparatus and provenance

- Model `claude-opus-5`, effort `xhigh`; Claude Code 2.1.258 and Agent SDK
  0.2.139.
- 20 tasks, three arms, four replicates, 240 cells, concurrency four.
- 180,000 output-token budget, 3,600-second wall budget, six controller turns,
  and 60 model turns per controller turn.
- `--no-package-cache` was enabled: no package-result cache or filesystem
  timestamp validation was used.
- `--no-wp-simplification` was enabled: hybrid agents were not instructed to
  simplify WP output. It did not disable internal WP simplification.
- Intermediate verification guidance was 5 seconds, then 10 seconds; agents
  could override it. Operational and eventual judging used 40 seconds. MBQI
  was disabled.
- Apparatus source commit:
  `ef12d18d63c0f08278b61cb07a4f7d9d228b9def`.
- The scheduler's mainline durability check was false at launch. The source
  was retained on `origin/snapshots/corpus-v1.2-005-opus`; this is a snapshot
  retention mechanism, not evidence that the commit had landed.

## Scope and persistent data

This report covers operational execution only. Held-out mutation scoring and
withheld-disqualification scoring are pending. Until those are complete, the
215 accepted cells cannot be reported as strict successes and arm quality
cannot be compared from the success counts alone.

Companion files:

- [Per-session data](cells.csv)
- [Machine-readable analysis](analysis.json)
- [Round summary](summary.json)
- [Provenance and accounting](provenance.json)

Raw transcripts, candidates, judge results, and SDK metrics remain in the
round's `runs/` directory. Archived authentication/session-limit attempts are
retained separately and are excluded from the 240-cell analysis.
