from __future__ import annotations

import asyncio
import json
from datetime import datetime, timezone
from pathlib import Path

from harness.artifacts import load_object, sha256_file, write_json
from harness.config import ExperimentConfig
from harness.mutants import score_mutants
from harness.score_round import (
    _ScoringApparatus,
    _disqualification_manifest,
    _require_scoring_apparatus_agrees,
)

HERE = Path(__file__).resolve().parent
EVAL = HERE.parent.parent
TERRA = EVAL / "evaluation-artifacts/corpus3.2-run9-codex-terra56-high-no-retries"
SOL = Path("/home/wrw/aptos-core/.worktrees/dev3/aptos-move/flow/evaluation/spec-inference/evaluation-artifacts/corpus3.2-run8-codex-sol56-high-no-refutation-retry")
OPUS = Path("/home/wrw/aptos-core/.worktrees/dev3-opus5-foundry/aptos-move/flow/evaluation/spec-inference/evaluation-artifacts/corpus3.2-run9-opus5-foundry-high-no-refutation-retry")
SCORED_ROOT = EVAL / "corpus-v3.2/mutants-scoring"
GATE_ROOT = EVAL / "corpus-v3.2/mutants"
SCORES = HERE / "scores"
SUMMARY = HERE / "summary.json"
CONCURRENCY = 2


def bound_gate_hashes(round_dir: Path) -> dict[str, str]:
    found: dict[str, str] = {}
    for path in sorted((round_dir / "schedule" / "runs").glob("*.json")):
        record = load_object(path)
        if "task_id" not in record:
            continue
        task = record["task_id"]
        digest = record.get("disqualification_mutant_manifest_sha256")
        if not digest:
            raise ValueError(f"{path} has no bound disqualification digest")
        previous = found.setdefault(task, digest)
        if previous != digest:
            raise ValueError(f"inconsistent gate digests for {task} in {round_dir}")
    return found


def classify(run_id: str, task_id: str, arm: str, replicate: int, score: dict) -> dict:
    inconclusive = set(score.get("inconclusive") or [])
    survived = [
        item["mutant_id"]
        for item in score["results"]
        if not item["killed"] and item["mutant_id"] not in inconclusive
    ]
    if survived:
        outcome = "disqualified"
    elif inconclusive:
        outcome = "not_scorable"
    else:
        outcome = "passed"
    return {
        "run_id": run_id,
        "task_id": task_id,
        "arm": arm,
        "replicate": replicate,
        "outcome": outcome,
        "disqualified_by": survived,
        "inconclusive": sorted(inconclusive),
        "gate_manifest_sha256": score["mutant_manifest_sha256"],
        "essential_mutants": score["essential_mutants"],
        "killed": score["killed"],
        "measured": score["measured"],
        "mutation_adequacy": score["mutation_adequacy"],
    }


def build_summary(entries: list[dict], started_utc: str, complete: bool) -> dict:
    arms = {}
    for arm in ("agent_only", "hybrid_flexible", "hybrid_guided"):
        rows = [entry for entry in entries if entry["arm"] == arm]
        arms[arm] = {
            "scheduled": len(rows),
            "passed": sum(entry["outcome"] == "passed" for entry in rows),
            "disqualified": sum(entry["outcome"] == "disqualified" for entry in rows),
            "not_scorable": sum(entry["outcome"] == "not_scorable" for entry in rows),
            "not_operationally_successful": sum(entry["outcome"] == "not_operationally_successful" for entry in rows),
        }
    return {
        "schema_version": 1,
        "analysis": "post_hoc_disqualification_recovery",
        "original_round_id": TERRA.name,
        "complete": complete,
        "started_utc": started_utc,
        "updated_utc": datetime.now(timezone.utc).isoformat(),
        "concurrency": CONCURRENCY,
        "protocol_deviation": "The original Terra schedule recorded null disqualification manifests. This recovery uses the per-task ordinary-mutant digests independently bound by the Opus and Sol schedules.",
        "original_candidates_unchanged": True,
        "scoring_set": str(GATE_ROOT.relative_to(EVAL)),
        "scoring_set_bound_by": [SOL.name, OPUS.name],
        "apparatus": {
            "terra_config_sha256": next(iter(load_object(path)["config_sha256"] for path in sorted((TERRA / "runs").glob("*/run.json")))),
            "terra_controller_harness_sha256": next(iter(load_object(path)["controller_harness_sha256"] for path in sorted((TERRA / "runs").glob("*/run.json")))),
        },
        "overall": {
            "scheduled": len(entries),
            "passed": sum(entry["outcome"] == "passed" for entry in entries),
            "disqualified": sum(entry["outcome"] == "disqualified" for entry in entries),
            "not_scorable": sum(entry["outcome"] == "not_scorable" for entry in entries),
            "not_operationally_successful": sum(entry["outcome"] == "not_operationally_successful" for entry in entries),
        },
        "arms": arms,
        "runs": sorted(entries, key=lambda entry: entry["run_id"]),
    }


async def main() -> None:
    SCORES.mkdir(parents=True, exist_ok=True)
    sol_hashes = bound_gate_hashes(SOL)
    opus_hashes = bound_gate_hashes(OPUS)
    if sol_hashes != opus_hashes:
        raise ValueError("Opus and Sol bound different ordinary-mutant manifests")

    for task, expected in sol_hashes.items():
        actual = sha256_file(GATE_ROOT / task / "mutants.json")
        if actual != expected:
            raise ValueError(f"ordinary mutant digest changed for {task}: {actual} != {expected}")

    config = ExperimentConfig.load((TERRA / "config.json").resolve())
    apparatus = _ScoringApparatus(config)
    entries: list[dict] = []
    pending: list[tuple[Path, dict, Path]] = []
    started_utc = datetime.now(timezone.utc).isoformat()

    for artifact in sorted(path for path in (TERRA / "runs").iterdir() if path.is_dir()):
        record_path = artifact / "run.json"
        if not record_path.is_file():
            continue
        record = load_object(record_path)
        run_id = record["run_id"]
        task = record["task_id"]
        base = {
            "run_id": run_id,
            "task_id": task,
            "arm": record["arm"],
            "replicate": record["replicate"],
        }
        state = ((record.get("result") or {}).get("eventual_judge") or {}).get("state")
        if state != "operational_success":
            entries.append({**base, "outcome": "not_operationally_successful", "detail": state})
            continue
        _require_scoring_apparatus_agrees(apparatus, record, run_id)
        baseline = artifact / "baseline" / record["package_relpath"]
        main_manifest = SCORED_ROOT / task / "mutants.json"
        if sha256_file(main_manifest) != record["mutant_manifest_sha256"]:
            raise ValueError(f"scheduled scored-mutant digest changed for {run_id}")
        gate = _disqualification_manifest(
            GATE_ROOT,
            task,
            run_id,
            main_manifest,
            baseline,
            record.get("refutation_mutant_identities"),
            sol_hashes[task],
        )
        score_path = SCORES / f"{run_id}.json"
        if score_path.is_file():
            saved = load_object(score_path)
            entries.append(saved["summary"])
        else:
            pending.append((artifact, record, gate))

    semaphore = asyncio.Semaphore(CONCURRENCY)

    async def score_one(artifact: Path, record: dict, gate: Path) -> dict:
        async with semaphore:
            run_id = record["run_id"]
            task = record["task_id"]
            try:
                score = await score_mutants(
                    config,
                    artifact / "final",
                    artifact / "baseline" / record["package_relpath"],
                    record["target"],
                    gate,
                    record.get("prove_timeout_seconds") or 40,
                )
                summary = classify(run_id, task, record["arm"], record["replicate"], score)
                payload = {"schema_version": 1, "summary": summary, "score": score}
            except Exception as error:
                summary = {
                    "run_id": run_id,
                    "task_id": task,
                    "arm": record["arm"],
                    "replicate": record["replicate"],
                    "outcome": "not_scorable",
                    "detail": f"{type(error).__name__}: {error}",
                }
                payload = {"schema_version": 1, "summary": summary}
            write_json(SCORES / f"{run_id}.json", payload)
            return summary

    completed = len(entries)
    total = completed + len(pending)
    write_json(SUMMARY, build_summary(entries, started_utc, complete=False))
    print(f"validated manifests and apparatus; starting {len(pending)} cells ({completed} already complete/skipped)", flush=True)
    tasks = [asyncio.create_task(score_one(*item)) for item in pending]
    for future in asyncio.as_completed(tasks):
        entry = await future
        entries.append(entry)
        completed += 1
        write_json(SUMMARY, build_summary(entries, started_utc, complete=False))
        print(f"[{completed}/{total}] {entry['task_id']} r{entry['replicate']:02d} {entry['arm']}: {entry['outcome']}", flush=True)

    final = build_summary(entries, started_utc, complete=True)
    write_json(SUMMARY, final)
    print(json.dumps({"complete": True, "overall": final["overall"], "arms": final["arms"]}, sort_keys=True), flush=True)


if __name__ == "__main__":
    asyncio.run(main())
