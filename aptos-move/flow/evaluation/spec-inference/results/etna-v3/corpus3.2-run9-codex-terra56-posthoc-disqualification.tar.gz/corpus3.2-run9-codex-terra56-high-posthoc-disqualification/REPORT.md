# Terra 5.6 post-hoc disqualification recovery

The original `corpus3.2-run9-codex-terra56-high-no-retries` schedule accidentally recorded `disqualification_mode: none` and a null `disqualification_mutant_manifest_sha256` in every cell. This recovery applies the omitted `corpus-v3.2/mutants` gate to the unchanged final Terra candidates.

The gate content was not accepted without verification. For every task, the live ordinary-mutant manifest matched the same SHA-256 independently bound before generation by both the Opus 5 and Sol 5.6 schedules. The recovery also checked that each ordinary set was disjoint from the scheduled scoring set and used Terra's original configuration, controller harness, Move Flow, Boogie, and Z3 identities.

## Corrected quality result

| arm | strict success | disqualified | unmeasured |
| --- | ---: | ---: | ---: |
| `agent_only` | 76/80 (95.00%) | 3 | 1 mutation-anchor incompatibility |
| `hybrid_flexible` | 75/80 (93.75%) | 4 | 1 original infrastructure-invalid cell |
| `hybrid_guided` | 75/80 (93.75%) | 3 | 2 scoring incompatibilities/inconclusives |
| **overall** | **226/240 (94.17%)** | **10** | **4** |

All ten conclusive failures occurred on `QP-part-025`; each let `QP-part-025-lost-element` survive. The unmeasured cells are:

- `BA-base-012/r03/hybrid_flexible`: original terminal infrastructure invalidity.
- `SM-select-022/r02/hybrid_guided`: deterministic mutation-anchor incompatibility, also unmeasured in the original scoring pass.
- `SM-select-022/r04/hybrid_guided`: one ordinary mutant remained solver-inconclusive after the permitted clean, exclusive retry.
- `TR-discard-011/r01/agent_only`: deterministic mutation-anchor incompatibility caused by specification insertion near the implementation fragment.

No model was invoked, no candidate was changed, and no refutation feedback was disclosed. Model cost is therefore unchanged. `summary.json` is the compact authoritative recovery result; `scores/` preserves the raw per-cell gate records and the first inconclusive attempt; `retry-events.jsonl` records the single recovery retry.
