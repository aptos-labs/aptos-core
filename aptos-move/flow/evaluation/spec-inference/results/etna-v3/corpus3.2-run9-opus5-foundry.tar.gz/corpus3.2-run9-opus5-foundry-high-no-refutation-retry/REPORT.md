# corpus3.2-run9-opus5-foundry-high-no-refutation-retry — archived results

This archive preserves the compact results of the completed corpus-v3.2 Claude Opus 5 round. It excludes raw transcripts, full workspaces, binaries, credentials, and solver scratch files.

## Result at a glance

All **240 scheduled cells** reached operational success. Held-out scoring produced **230 strict successes**, **6 conclusive disqualifications**, and **4 infrastructure-unmeasured cells**. No canonical generation cell was infrastructure-invalid.

| arm | strict success | disqualified | unmeasured | total model cost | average / finalized cell | mean wall time |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| `agent_only` | 75 | 3 | 2 | $37.3875 | $0.46734 | 122.8 s |
| `hybrid_flexible` | 77 | 2 | 1 | $38.6501 | $0.48313 | 122.2 s |
| `hybrid_guided` | 78 | 1 | 1 | $39.6157 | $0.49520 | 126.4 s |

The descriptive strict-success counts use all 80 scheduled cells as the denominator: `agent_only` 75/80 (93.75%), `hybrid_flexible` 77/80 (96.25%), and `hybrid_guided` 78/80 (97.50%). The four unmeasured cells are infrastructure missingness and are not experimental failures.

## Failure and retry handling

The six conclusive failures all occurred on `QP-part-025`, where `QP-part-025-lost-element` survived the withheld disqualification gate. They were final immediately and were not retried: agent-only replicas 1, 2, and 4; hybrid-flexible replicas 2 and 4; hybrid-guided replica 2.

The main scoring pass had six solver-inconclusive ordinary gates on `SM-select-022`. Each received one sequential clean infrastructure retry under exclusive access to both shared prover slots. Four remained ordinary-gate inconclusive and are recorded as unmeasured: hybrid-flexible replica 1, agent-only replicas 2 and 4, and hybrid-guided replica 4. Two cleared the gate, then each had one strict solver-inconclusive score; their one strict-only retry killed all three strict mutants, so both are strict successes. Recovery attempt files and state are retained under `recovery/` and `scores/`.

## Cost and pricing

The overall list-price estimate is **$115.6532**, averaging **$0.48189 per finalized cell**. The average is this round's cumulative model cost divided by all 80 finalized canonical sessions in the arm, including disqualified and infrastructure-unmeasured scoring outcomes. Scoring and prover recovery add no model cost.

Pricing was recomputed from each raw Foundry usage receipt using:

```text
(5 × input + 0.5 × cache_read + 6.25 × cache_creation_5m + 10 × cache_creation_1h + 25 × output) / 1,000,000
```

All 240 recomputed cell totals match the SDK's list-cost estimate within $1e-9; the maximum absolute delta is $2E-16. This is a list-price estimate. Azure contract or invoice adjustments are outside the recorded telemetry.

## Wall time

All 240 cells are included. Overall controller wall time had mean **123.8 seconds**, median **93.8 seconds**, p95 **288.4 seconds**, and maximum **691.2 seconds**. Summed wall time is **8.25 resource-hours** and overlaps because cell concurrency was 3 except for the recorded interval at 2.

The three participating containers used a cooperative shared gate capped at two Boogie process groups. Its lock state was stored on the Linux btrfs volume rather than the Mac-shared filesystem. The observed shared trace reached two admitted groups and recorded zero cap violations.

## Apparatus and provenance

- Model: explicit `claude-opus-5`, Microsoft Foundry authentication, `high` effort.
- Context: 1,000,000-token model context as documented for Opus 5. The SDK telemetry's `contextWindow=200000` field is treated as stale metadata and is not the selection source.
- Design: 20 tasks × 3 arms × 4 replicas, acceptance-only feedback, no in-session refutation retry.
- Experiment source commit: `01301524c92bf240f853b7eaa2aa265e4c526e53`.
- Provenance branch head: `04a9bac5e919609124740c25af009ae9552d55f8`, equal to `origin/wrwg/inf-opus5-foundry` at archive time.
- Flow binary SHA-256: `b4deb2871092b92e806f656d3e4aa503f198cfacf54e21ae3a46f5d6446cdd44`.
- Controller harness SHA-256: `40a34fbb6163fac11871591cd2396b6700e029db636dd4b8f5b7f4b3cddee46d`.
- Experiment config SHA-256: `59f653b5910ac60ee937658ed3a80ca56d6d7c5a7f298d7ef5def5891be312d2`.

## Files

- `mutation-summary.json` is the authoritative final scoring summary; `scores/` retains canonical and recovery-attempt mutant verdicts.
- `summary.json`, `cells.csv`, `queries.csv`, and `sdk-sessions.csv` preserve compact cell outcomes, final reports, usage, timing, and scoring data.
- `analysis.json`, `cost-summary.json`, `final-status.json`, `audit.json`, and `launch-report.json` preserve aggregates and completion evidence.
- `config.json`, `run-conditions.json`, `plugins.json`, `preflight.json`, `apparatus.json`, `pricing.json`, `pilot-manifest.json`, `corpus-manifest.json`, and `schedule-runs/` preserve execution and design provenance.
- `SHA256SUMS` covers every other archived file.
