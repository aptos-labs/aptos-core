# corpus3.2-run4-sonnet — archived partial results

This archive preserves the compact results of the abandoned corpus-v3.2
Sonnet round. It deliberately excludes raw transcripts, workspaces, binaries,
copied corpus sources, and credentials. **This was not a completed round.**

## Round state

| field | value |
|---|---:|
| model / effort | `claude-sonnet-5` / `xhigh` |
| planned design | 20 tasks × 3 arms × 4 replicates = 240 cells |
| concurrency | 4 |
| recorded terminal outcomes | 147 / 240 |
| operational success | 142 |
| output-token budget exhausted | 3 |
| invalid infrastructure failure | 2 |
| batch-aborted | 93 (3 started, 90 not started) |
| held-out mutation scoring | not run |
| recorded output-token limit | 100,000 per session |
| recorded wall limit | 3,600 seconds per session |
| source commit recorded by the round | `b4fc50d4de6916d0db3e234a3a1b76250137646b` |

The source commit above is historical run metadata. Durability of that commit
was explicitly waived when these artifacts were archived; the content and
apparatus hashes remain in the manifests.

## Recorded resource totals

Input below is the sum of fresh input, cache creation, and cache reads. Dollar
figures are SDK-reported API-equivalent estimates, not subscription charges.
Wall time is summed cell wall time; concurrently executing cells overlap.
The three interrupted cells have no terminal SDK result and are excluded, so
these are lower bounds for the abandoned launch.

| arm | recorded / success | input | output | model turns | WP calls | wall minutes | estimated cost |
|---|---:|---:|---:|---:|---:|---:|---:|
| `agent_only` | 48 / 47 | 34,603,404 | 990,269 | 865 | 0 | 203.27 | $26.39 |
| `hybrid_flexible` | 49 / 47 | 44,424,651 | 1,149,679 | 933 | 74 | 243.91 | $31.27 |
| `hybrid_guided` | 50 / 48 | 53,958,968 | 1,147,804 | 1,044 | 156 | 250.53 | $33.06 |
| **total** | **147 / 142** | **132,987,023** | **3,287,752** | **2,842** | **230** | **697.72** | **$90.72** |

The recorded input consists of 4,892 fresh-input tokens, 8,120,667
cache-creation tokens, and 124,861,464 cache-read tokens. The longest terminal
cell took 1,492.5 seconds.

## Interpretation caveats

First, execution was stopped. Missing cells are outcome- and time-dependent,
not a random sample, so arm totals, means, and rankings from this partial round
are descriptive only.

Second, this round exposed a Move Prover diagnostic bug. WP reported
“WP retained a quantified loop summary despite the supplied invariant” merely
because a generated condition was both quantified and marked `sathard`. That
does not show that the supplied invariant is incomplete. The warning occurred
in 13 recorded guided and 3 recorded flexible cells, and never in agent-only
cells. It induced extra hybrid work and independently invalidates causal
cost/ranking comparisons. The defect was fixed after the run by commit
`b34903be89`.

Strict success remains unknown because held-out mutation scoring was not run.

## Files

- `summary.json` contains one record per terminal cell, including terminal
  state, output, cost, wall time, tool counts, refutation history, and final
  agent report.
- `cells.csv` contains all 240 scheduled cells; the 93 absent outcomes have
  blank metrics rather than zeros. `sdk-sessions.csv` and `queries.csv` retain
  finer resource accounting. Cumulative SDK-session fields in `queries.csv`
  must not be summed across queries.
- `launch-report.json`, `preflight.json`, `config.json`, and `plugins.json`
  preserve execution metadata and the explicit aborted state.
- `pilot-manifest.json`, `corpus-manifest.json`, and `schedule-runs/` preserve
  the complete planned design and content hashes.

