# Successful-run token and cost summary

Checked: 2026-09-09T23:09:37.549414+00:00

Successful sessions: **240/240**

| Scope | Sessions | Input | Cache creation | Cache read | Output | Mean output | Estimated cost | Mean cost |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Total | 240 | 6,624 | 9,524,164 | 123,053,404 | 3,033,458 | 12,639.4 | $232.80 | $0.970 |
| agent-only | 80 | 1,666 | 2,692,983 | 27,156,777 | 821,031 | 10,262.9 | $61.12 | $0.764 |
| hybrid-guided | 80 | 2,662 | 3,581,449 | 53,797,233 | 1,222,051 | 15,275.6 | $93.31 | $1.166 |
| hybrid-flexible | 80 | 2,296 | 3,249,732 | 42,099,394 | 990,376 | 12,379.7 | $78.36 | $0.980 |

Complete SDK telemetry: **240/240 sessions**.

Cost is the SDK-reported API-equivalent list-price estimate. It is not an amount charged to the Claude subscription.
