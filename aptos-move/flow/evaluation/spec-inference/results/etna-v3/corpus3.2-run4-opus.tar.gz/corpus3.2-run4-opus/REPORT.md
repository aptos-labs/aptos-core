# corpus3.2-run4-opus — archived results

This archive preserves the compact results of the completed corpus-v3.2 Opus
round. It deliberately excludes raw transcripts, workspaces, binaries, copied
corpus sources, and credentials.

## Round state

| field | value |
|---|---:|
| model / effort | `claude-opus-5` / `xhigh` |
| design | 20 tasks × 3 arms × 4 replicates = 240 cells |
| concurrency | 4 |
| completed | 240 / 240 |
| operational success | 240 / 240 |
| held-out mutation scoring | not run |
| recorded output-token limit | 100,000 per session |
| recorded wall limit | 3,600 seconds per session |
| source commit recorded by the round | `f5f941de27e077cb4e58dd5863a1b39676802c22` |

The source commit above is historical run metadata. Durability of that commit
was explicitly waived when these artifacts were archived; the content and
apparatus hashes remain in the manifests.

## Resource totals

Input below is the sum of fresh input, cache creation, and cache reads. Dollar
figures are SDK-reported API-equivalent estimates, not subscription charges.
Wall time is summed cell wall time; concurrently executing cells overlap.

| arm | cells / success | input | output | model turns | WP calls | wall minutes | estimated cost |
|---|---:|---:|---:|---:|---:|---:|---:|
| `agent_only` | 80 / 80 | 29,851,426 | 821,031 | 1,037 | 0 | 232.09 | $61.12 |
| `hybrid_flexible` | 80 / 80 | 45,351,422 | 990,376 | 1,333 | 118 | 272.61 | $78.36 |
| `hybrid_guided` | 80 / 80 | 57,381,344 | 1,222,051 | 1,500 | 215 | 307.94 | $93.31 |
| **total** | **240 / 240** | **132,584,192** | **3,033,458** | **3,870** | **333** | **812.64** | **$232.80** |

The total input consists of 6,624 fresh-input tokens, 9,524,164 cache-creation
tokens, and 123,053,404 cache-read tokens. The longest cell took 1,933 seconds.

## Interpretation caveat

This round exposed a Move Prover diagnostic bug. WP reported
“WP retained a quantified loop summary despite the supplied invariant” merely
because a generated condition was both quantified and marked `sathard`. That
does not show that the supplied invariant is incomplete. The warning occurred
in 35 guided and 20 flexible cells, and never in agent-only cells. It induced
extra hybrid work and invalidates causal cost/ranking comparisons between the
arms. The defect was fixed after the run by commit `b34903be89`.

The operational outcomes and resource observations remain useful historical
data, but this round must not be presented as an unbiased comparison of the
three workflows. Strict success also remains unknown because held-out mutation
scoring was not run.

## Files

- `summary.json` contains one record per completed cell, including terminal
  state, output, cost, wall time, tool counts, refutation history, and final
  agent report.
- `cells.csv`, `sdk-sessions.csv`, and `queries.csv` retain progressively finer
  resource accounting. Cumulative SDK-session fields in `queries.csv` must not
  be summed across queries.
- `launch-report.json`, `preflight.json`, `config.json`, `plugins.json`,
  `apparatus.json`, and `preparation.json` preserve execution metadata.
- `pilot-manifest.json`, `corpus-manifest.json`, and `schedule-runs/` preserve
  the complete scheduled design and content hashes.
- `status.md` and `token-cost-summary.md` are the final live-monitor snapshots.

