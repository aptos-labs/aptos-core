# Run 4 status

Checked: 2026-09-09T23:09:37.549414+00:00

Finished: **240/240**. Active: **0**.

| Arm | Done | Operational | Strict | Mean output | Mean cost |
|---|---:|---:|---:|---:|---:|
| agent-only | 80 | 80 | pending | 10,262.9 | $0.764 |
| hybrid-guided | 80 | 80 | pending | 15,275.6 | $1.166 |
| hybrid-flexible | 80 | 80 | pending | 12,379.7 | $0.980 |

Cost is the SDK API-equivalent estimate, not a subscription charge.

Execution complete; held-out mutation scoring is pending.
