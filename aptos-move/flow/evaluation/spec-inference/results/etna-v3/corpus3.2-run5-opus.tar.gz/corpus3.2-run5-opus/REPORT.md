# corpus3.2-run5-opus — archived results

This archive preserves the compact results of the completed corpus-v3.2 Opus
round. It deliberately excludes raw transcripts, workspaces, binaries, copied
Etna sources, and credentials.

## Result at a glance

All **240 scheduled cells** reached operational success and killed all three
held-out scoring mutants: **720/720 mutant executions were killed**. One cell
is nevertheless apparatus-invalid and is excluded from analysis, leaving
**239/239 valid strict successes**.

| field | value |
| --- | ---: |
| model / effort | `claude-opus-5` / `xhigh` |
| design | 20 tasks × 3 arms × 4 replicates = 240 cells |
| execution concurrency | 4 |
| operational outcomes | 240/240 successful |
| held-out strict outcomes | 240/240 before audit; 239/239 valid after audit |
| held-out mutations | 720/720 killed; no survivors or inconclusive results |
| output-token / wall limits | 180,000 / 3,600 seconds per cell |
| source commit | `86ab965be98a4e232664886f2544e9e1f8a99088` |
| elapsed execution span | 2 h 59 min 34 s |

## Resource totals

Input is fresh input plus cache creation plus cache reads. Dollar figures are
SDK-reported API-list-price-equivalent estimates, not subscription charges.
Wall time is summed cell time; four cells ran concurrently.

| arm | cells | input | output | model turns | WP calls | wall minutes | estimated cost |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| `agent_only` | 80 | 33,465,345 | 891,576 | 1,111 | 0 | 227.86 | $65.5802 |
| `hybrid_flexible` | 80 | 41,416,960 | 892,584 | 1,267 | 108 | 267.73 | $72.5124 |
| `hybrid_guided` | 80 | 43,709,958 | 848,132 | 1,273 | 150 | 215.90 | $71.7135 |
| **total** | **240** | **118,592,263** | **2,632,292** | **3,651** | **258** | **711.49** | **$209.8060** |

The input total consists of 6,168 fresh-input, 8,885,041 cache-creation, and
109,701,054 cache-read tokens. Reported thinking was 1,509,777 tokens, already
included in output. The cells made 3,399 logged tool calls and 463
verification/check calls.

One flexible cell with context-management metadata has a $0.266949 difference
between token-price recomputation and the SDK's cumulative estimate. The table
retains the SDK estimate. No account invoice data was available.

## Audit exclusion

`corpus3.2-run5-opus-QP-part-025-r01-hybrid-flexible-acceptance` is retained in
the archive but excluded from comparisons. A sequential
`move_package_verify` call never returned; the Flow MCP supervisor restarted
the session. The audit records three session starts but only two session ends
and correctly rejects the controller's later `operational_success` label as a
valid experimental observation.

That cell accounts for 59,506 output tokens, $4.0855, 50.79 wall minutes, 63
model turns, and two WP calls. Removing it leaves 239 valid observations with
2,572,786 output tokens and $205.7205 of recorded API-equivalent cost. Paired
contrasts drop the entire affected three-arm block, leaving 79 complete blocks
across all 20 tasks.

## Paired comparisons

The following are equal-task-weighted mean within-block differences over the
79 complete valid blocks. Positive means the first named arm used more. The
intervals are exploratory 95% task-cluster bootstrap intervals (10,000
resamples); every interval crosses zero.

| contrast | cost difference | output difference | wall-time difference |
| --- | ---: | ---: | ---: |
| flexible − agent-only | +$0.0298 [-$0.2455, +$0.2002] | -873 [-5,485, +2,051] | -11.0 s [-92.5, +41.1] |
| guided − flexible | +$0.0290 [-$0.0612, +$0.1233] | -6 [-1,257, +1,255] | -5.9 s [-31.0, +19.3] |
| guided − agent-only | +$0.0589 [-$0.2442, +$0.2913] | -879 [-5,937, +2,844] | -16.9 s [-119.8, +56.8] |

This round establishes no arm difference in strict success: every valid arm
output killed its held-out mutants. It also does not reproduce the large
aggregate hybrid output advantage seen with GLM 5.3 on corpus 3.1.

## Refutation and WP behavior

Refutation feedback was enabled using `corpus-v3.2/mutants`; scoring used the
separate held-out `mutants-scoring` set. Refutation found initially weak
contracts in all four agent-only replicas and one flexible replica of
`QP-part-025`; all five were repaired. Guided had no refutation downgrade.

The quantified-loop false diagnostic fixed by `b34903be89` occurred zero times.
Flexible made 108 WP calls and guided made 150. `--no-wp-simplification` was
enabled, so the workflow omitted the routine model simplification step. WP
still emitted intended diagnostics for missing loop invariants and partial or
transparent callees.

## Cache-cost interpretation

Cache reads were 30.67M for agent-only, 38.34M for flexible, and 40.69M for
guided. Per model turn that is about 27.6k, 30.3k, and 32.0k respectively.
Hybrid therefore paid both for roughly two extra turns per cell and for a
10–16% larger cached prefix. Context was effectively not pruned: four messages
in one flexible cell carried context-management metadata, all with
`applied_edits: []`.

The rendered hybrid instructions are only 51 bytes larger than agent-only.
The supported mechanism is repeated interaction: hybrid made 539/552 Flow MCP
calls versus 337 for agent-only, and later turns repeatedly reread WP,
verification, status, and query results. Deterministic compaction of superseded
tool results is a plausible future apparatus optimization, but was not part of
this round.

## Task-complexity interpretation

Hybrid savings do not monotonically track source complexity. Across all ten
loop tasks, aggregate output was 1.002× agent-only for guided and 0.986× for
flexible. Across the 17 tasks labelled hard it was 0.975× and 0.985×. Guided's
largest group-level saving was instead on the three guessable controls
(0.602×), while flexible cost more there (1.232×).

The strongest individual hybrid win was the hardest task, `QP-part-025`
(guided 0.37×, flexible 0.59× before audit exclusion), whose contract needs an
in-place permutation model, a three-region loop invariant, and swap/counting
lemmas. But guided also won strongly on straight-line hidden-overflow task
`TS-trial-019` and on simple controls. WP value is therefore better described
by whether its symbolic summary is immediately useful than by program size.

## Provenance and configuration

- Apparatus source commit `86ab965be98a4e232664886f2544e9e1f8a99088`, retained on
  `origin/snapshots/corpus3.2-run5-opus-source` and
  `origin/wrwg/inf-sonnet-profile-results`.
- Flow binary SHA-256
  `1fbb74be97fdbbc3bcf38f1253468faad0f81e748f054c1a892a6479a6f42e15`.
- Opus xhigh, four replicates, concurrency four, 180,000 output tokens, and
  3,600 seconds per cell.
- MCP package caching and filesystem timestamp reuse were disabled with
  `--no-package-cache`.
- Routine WP simplification guidance was disabled with
  `--no-wp-simplification`.
- Intermediate verification guidance was 5 seconds, increasing to 10 seconds;
  agents could override it. Final judging and held-out scoring used 40 seconds.
- MBQI was disabled.

## Files

- `summary.json`: every completed cell, final report, refutation history, and
  held-out mutation outcomes.
- `cells.csv`, `sdk-sessions.csv`, and `queries.csv`: cell-, SDK-session-, and
  query-level resource accounting. Cumulative SDK fields in `queries.csv` must
  not be summed across queries.
- `analysis.json`: exact totals and task-cluster intervals before the explicit
  audit exclusion; this report gives the corrected 79-block estimates.
- `audit.json`: the authoritative apparatus-invalid cell and reasons.
- `mined.json` / `mined.md` and `taxonomy.json` / `taxonomy.md`: tool/turn and
  diagnostic summaries.
- `launch-report.json`, `preflight.json`, `config.json`, `plugins.json`,
  `apparatus.json`, and `preparation.json`: execution metadata.
- `pilot-manifest.json`, `corpus-manifest.json`, and `schedule-runs/`: the
  scheduled design and content hashes.

