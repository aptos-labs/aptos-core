# Source-free evaluation archive

This public archive contains aggregate evaluation reports and tables only.
Per-run diffs, diagnostics, transcripts, event streams, source trees, and other
source-bearing evidence are intentionally retained outside the public archive.
See the adjacent repository documentation for analysis and provenance.
