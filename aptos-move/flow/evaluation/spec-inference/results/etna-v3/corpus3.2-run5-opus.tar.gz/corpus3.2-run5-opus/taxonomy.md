# Failure taxonomy over 240 runs

## Terminal statuses

| status | runs |
|---|---:|
| operational_success | 240 |

## Observed failure kinds

| kind | count |
|---|---:|
| unclassified | 19 |
| postcondition | 14 |
| type_error | 10 |
| loop_invariant_induction | 6 |
| solver_timeout | 6 |
| abort_not_covered | 4 |
| tool_infrastructure | 1 |
| loop_invariant_base | 1 |
| spec_context_error | 1 |
| abort_never_happens | 1 |

## Categories proposed by the feedback design

A category that never fired is evidence about the design only when the
corpus could have produced it.

| proposed category | status | observations | evidence |
|---|---|---:|---|
| invariant initialization | observed | 1 | loop_invariant_base |
| invariant preservation | observed | 6 | loop_invariant_induction |
| invariant insufficient at loop exit | unreachable in this corpus | 0 | — |
| missing or overly broad abort behavior | observed | 5 | abort_never_happens, abort_not_covered |
| incorrect normal-return behavior | observed | 14 | postcondition |
| missing global frame | unreachable in this corpus | 0 | — |
| insufficient callee contract | reachability unknown | 0 | no machine label; needs hand labelling |
| forbidden weakening or edit-policy violation | reachable but never triggered | 0 | no machine label; needs hand labelling |
| solver timeout | observed | 6 | solver_timeout |

## Kinds the design did not propose

The data argues for these as much as it argues against the unobserved
proposals.

- `spec_context_error`
- `tool_infrastructure`
- `type_error`
- `unclassified`

## Adopted schema

- incorrect normal-return behavior
- invariant initialization
- invariant preservation
- missing or overly broad abort behavior
- solver timeout
- spec_context_error
- tool_infrastructure
- type_error
- unclassified
