# Failure taxonomy over 204 runs

## Terminal statuses

| status | runs |
|---|---:|
| operational_success | 204 |

## Observed failure kinds

| kind | count |
|---|---:|
| name_resolution | 85 |
| unclassified | 55 |
| postcondition | 51 |
| abort_not_covered | 30 |
| abort_never_happens | 13 |
| tool_usage_error | 8 |
| loop_invariant_induction | 6 |
| solver_timeout | 6 |
| unsupported_construct | 3 |
| type_error | 3 |
| spec_context_error | 2 |
| loop_invariant | 2 |
| tool_infrastructure | 2 |
| loop_invariant_base | 1 |
| syntax_error | 1 |
| declaration_error | 1 |

## Categories proposed by the feedback design

A category that never fired is evidence about the design only when the
corpus could have produced it.

| proposed category | status | observations | evidence |
|---|---|---:|---|
| invariant initialization | observed | 1 | loop_invariant_base |
| invariant preservation | observed | 6 | loop_invariant_induction |
| invariant insufficient at loop exit | observed | 2 | loop_invariant |
| missing or overly broad abort behavior | observed | 43 | abort_never_happens, abort_not_covered |
| incorrect normal-return behavior | observed | 51 | postcondition |
| missing global frame | unreachable in this corpus | 0 | — |
| insufficient callee contract | reachability unknown | 0 | no machine label; needs hand labelling |
| forbidden weakening or edit-policy violation | reachable but never triggered | 0 | no machine label; needs hand labelling |
| solver timeout | observed | 6 | solver_timeout |

## Kinds the design did not propose

The data argues for these as much as it argues against the unobserved
proposals.

- `declaration_error`
- `name_resolution`
- `spec_context_error`
- `syntax_error`
- `tool_infrastructure`
- `tool_usage_error`
- `type_error`
- `unclassified`
- `unsupported_construct`

## Adopted schema

- declaration_error
- incorrect normal-return behavior
- invariant initialization
- invariant insufficient at loop exit
- invariant preservation
- missing or overly broad abort behavior
- name_resolution
- solver timeout
- spec_context_error
- syntax_error
- tool_infrastructure
- tool_usage_error
- type_error
- unclassified
- unsupported_construct
