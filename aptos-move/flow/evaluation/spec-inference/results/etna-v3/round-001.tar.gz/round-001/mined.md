| run | arm | status | turns | API s | out tok | cache-read | verify fail | probes | reverts | rewrites |
|---|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| round-001-BA-base-012-r01-agent-only-acceptance | agent_only | operational_success | 24 | 617 | 35281 | 681600 | 2 | 1 | 1 | 0 |
| round-001-BA-base-012-r01-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 22 | 260 | 13092 | 488256 | 1 | 0 | 1 | 0 |
| round-001-BA-base-012-r01-hybrid-guided-acceptance | hybrid_guided | operational_success | 13 | 300 | 13004 | 204608 | 0 | 1 | 0 | 0 |
| round-001-BA-base-012-r02-agent-only-acceptance | agent_only | operational_success | 19 | 414 | 24132 | 555584 | 2 | 0 | 1 | 0 |
| round-001-BA-base-012-r02-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 21 | 643 | 38790 | 693888 | 0 | 3 | 0 | 0 |
| round-001-BA-base-012-r02-hybrid-guided-acceptance | hybrid_guided | operational_success | 26 | 560 | 24966 | 649344 | 1 | 7 | 0 | 0 |
| round-001-BA-base-012-r03-agent-only-acceptance | agent_only | operational_success | 27 | 448 | 27063 | 749568 | 2 | 4 | 0 | 0 |
| round-001-BA-base-012-r03-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 23 | 542 | 23444 | 413120 | 0 | 0 | 0 | 0 |
| round-001-BA-base-012-r03-hybrid-guided-acceptance | hybrid_guided | operational_success | 20 | 768 | 33690 | 589376 | 2 | 0 | 0 | 0 |
| round-001-BA-base-012-r04-agent-only-acceptance | agent_only | operational_success | 25 | 675 | 38565 | 649600 | 1 | 9 | 0 | 4 |
| round-001-BA-base-012-r04-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 15 | 614 | 35062 | 338688 | 0 | 4 | 0 | 0 |
| round-001-BA-base-012-r04-hybrid-guided-acceptance | hybrid_guided | operational_success | 18 | 166 | 5807 | 314176 | 1 | 5 | 1 | 0 |
| round-001-LP-price-021-r01-agent-only-acceptance | agent_only | operational_success | 12 | 137 | 6351 | 159616 | 0 | 0 | 0 | 0 |
| round-001-LP-price-021-r01-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 22 | 260 | 9043 | 423424 | 0 | 7 | 0 | 0 |
| round-001-LP-price-021-r01-hybrid-guided-acceptance | hybrid_guided | operational_success | 16 | 167 | 8456 | 308864 | 0 | 0 | 0 | 0 |
| round-001-LP-price-021-r02-agent-only-acceptance | agent_only | operational_success | 30 | 235 | 7072 | 601728 | 1 | 4 | 1 | 0 |
| round-001-LP-price-021-r02-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 19 | 200 | 10703 | 327616 | 0 | 4 | 0 | 1 |
| round-001-LP-price-021-r02-hybrid-guided-acceptance | hybrid_guided | operational_success | 19 | 205 | 7689 | 308864 | 0 | 0 | 0 | 0 |
| round-001-LP-price-021-r03-agent-only-acceptance | agent_only | operational_success | 28 | 245 | 14485 | 701760 | 1 | 0 | 1 | 0 |
| round-001-LP-price-021-r03-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 30 | 215 | 11530 | 753728 | 1 | 8 | 1 | 0 |
| round-001-LP-price-021-r03-hybrid-guided-acceptance | hybrid_guided | operational_success | 29 | 479 | 24248 | 812992 | 3 | 13 | 0 | 0 |
| round-001-LP-price-021-r04-agent-only-acceptance | agent_only | operational_success | 17 | 219 | 8084 | 315840 | 1 | 0 | 1 | 0 |
| round-001-LP-price-021-r04-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 13 | 400 | 13665 | 223808 | 0 | 5 | 0 | 0 |
| round-001-LP-price-021-r04-hybrid-guided-acceptance | hybrid_guided | operational_success | 26 | 335 | 10438 | 489600 | 1 | 13 | 0 | 0 |
| round-001-MM-min-013-r01-agent-only-acceptance | agent_only | operational_success | 28 | 204 | 10758 | 574848 | 2 | 5 | 1 | 0 |
| round-001-MM-min-013-r01-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 16 | 169 | 5984 | 282368 | 0 | 0 | 0 | 0 |
| round-001-MM-min-013-r01-hybrid-guided-acceptance | hybrid_guided | operational_success | 14 | 101 | 4241 | 221952 | 0 | 0 | 0 | 0 |
| round-001-MM-min-013-r02-agent-only-acceptance | agent_only | operational_success | 14 | 259 | 7690 | 196736 | 2 | 0 | 0 | 0 |
| round-001-MM-min-013-r02-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 16 | 190 | 6929 | 270976 | 0 | 1 | 0 | 0 |
| round-001-MM-min-013-r02-hybrid-guided-acceptance | hybrid_guided | operational_success | 25 | 257 | 7939 | 456960 | 1 | 3 | 1 | 0 |
| round-001-MM-min-013-r03-agent-only-acceptance | agent_only | operational_success | 12 | 77 | 3734 | 137024 | 0 | 0 | 0 | 0 |
| round-001-MM-min-013-r03-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 19 | 172 | 7590 | 328704 | 0 | 6 | 0 | 0 |
| round-001-MM-min-013-r03-hybrid-guided-acceptance | hybrid_guided | operational_success | 22 | 202 | 7339 | 380608 | 0 | 0 | 0 | 0 |
| round-001-MM-min-013-r04-agent-only-acceptance | agent_only | operational_success | 11 | 89 | 3186 | 141760 | 0 | 1 | 0 | 0 |
| round-001-MM-min-013-r04-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 14 | 178 | 7423 | 205568 | 0 | 0 | 0 | 0 |
| round-001-MM-min-013-r04-hybrid-guided-acceptance | hybrid_guided | operational_success | 13 | 121 | 5149 | 190976 | 0 | 0 | 0 | 0 |
| round-001-OV-order-006-r01-agent-only-acceptance | agent_only | operational_success | 14 | 223 | 8436 | 211904 | 1 | 0 | 1 | 0 |
| round-001-OV-order-006-r01-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 10 | 87 | 4350 | 132160 | 0 | 2 | 0 | 0 |
| round-001-OV-order-006-r01-hybrid-guided-acceptance | hybrid_guided | operational_success | 13 | 101 | 3859 | 190144 | 0 | 2 | 0 | 0 |
| round-001-OV-order-006-r02-agent-only-acceptance | agent_only | operational_success | 15 | 115 | 4055 | 203648 | 0 | 0 | 0 | 0 |
| round-001-OV-order-006-r02-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 16 | 132 | 5031 | 283648 | 0 | 8 | 0 | 0 |
| round-001-OV-order-006-r02-hybrid-guided-acceptance | hybrid_guided | operational_success | 10 | 87 | 3247 | 132096 | 0 | 0 | 0 | 0 |
| round-001-OV-order-006-r03-agent-only-acceptance | agent_only | operational_success | 15 | 79 | 3356 | 189504 | 0 | 1 | 0 | 0 |
| round-001-OV-order-006-r03-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 11 | 48 | 2123 | 128384 | 0 | 0 | 0 | 0 |
| round-001-OV-order-006-r03-hybrid-guided-acceptance | hybrid_guided | operational_success | 9 | 67 | 3186 | 127040 | 0 | 3 | 0 | 0 |
| round-001-OV-order-006-r04-agent-only-acceptance | agent_only | operational_success | 12 | 83 | 4073 | 164480 | 1 | 0 | 1 | 0 |
| round-001-OV-order-006-r04-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 8 | 35 | 1752 | 111872 | 0 | 0 | 0 | 0 |
| round-001-OV-order-006-r04-hybrid-guided-acceptance | hybrid_guided | operational_success | 11 | 64 | 2802 | 145920 | 0 | 1 | 0 | 0 |
| round-001-QP-part-025-r01-agent-only-acceptance | agent_only | operational_success | 45 | 1144 | 62162 | 2364480 | 5 | 0 | 1 | 2 |
| round-001-QP-part-025-r01-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 30 | 398 | 19774 | 732096 | 1 | 0 | 1 | 1 |
| round-001-QP-part-025-r01-hybrid-guided-acceptance | hybrid_guided | operational_success | 23 | 760 | 28072 | 816768 | 0 | 0 | 0 | 0 |
| round-001-QP-part-025-r02-agent-only-acceptance | agent_only | operational_success | 41 | 1077 | 50265 | 1555840 | 1 | 0 | 1 | 0 |
| round-001-QP-part-025-r02-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 20 | 408 | 18727 | 415744 | 0 | 0 | 0 | 1 |
| round-001-QP-part-025-r02-hybrid-guided-acceptance | hybrid_guided | operational_success | 29 | 689 | 40429 | 1012224 | 1 | 0 | 0 | 1 |
| round-001-QP-part-025-r03-agent-only-acceptance | agent_only | operational_success | 33 | 727 | 30163 | 960256 | 0 | 2 | 0 | 2 |
| round-001-QP-part-025-r03-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 24 | 1185 | 53871 | 995520 | 2 | 1 | 0 | 4 |
| round-001-QP-part-025-r03-hybrid-guided-acceptance | hybrid_guided | operational_success | 17 | 543 | 33013 | 609984 | 0 | 0 | 0 | 1 |
| round-001-QP-part-025-r04-agent-only-acceptance | agent_only | operational_success | 33 | 954 | 41448 | 1206400 | 2 | 0 | 0 | 1 |
| round-001-QP-part-025-r04-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 38 | 1216 | 48532 | 1137536 | 0 | 0 | 0 | 0 |
| round-001-QP-part-025-r04-hybrid-guided-acceptance | hybrid_guided | operational_success | 34 | 742 | 40936 | 1340672 | 0 | 18 | 0 | 0 |
| round-001-SM-select-022-r01-agent-only-acceptance | agent_only | operational_success | 35 | 443 | 17677 | 1028736 | 4 | 9 | 2 | 0 |
| round-001-SM-select-022-r01-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 20 | 408 | 19660 | 434240 | 1 | 7 | 0 | 0 |
| round-001-SM-select-022-r01-hybrid-guided-acceptance | hybrid_guided | operational_success | 38 | 1326 | 51531 | 1556736 | 4 | 11 | 0 | 0 |
| round-001-SM-select-022-r02-agent-only-acceptance | agent_only | operational_success | 25 | 528 | 27456 | 652736 | 2 | 0 | 1 | 0 |
| round-001-SM-select-022-r02-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 23 | 357 | 19125 | 604032 | 1 | 0 | 1 | 0 |
| round-001-SM-select-022-r02-hybrid-guided-acceptance | hybrid_guided | operational_success | 20 | 337 | 18944 | 391552 | 0 | 7 | 0 | 0 |
| round-001-SM-select-022-r03-agent-only-acceptance | agent_only | operational_success | 22 | 307 | 18034 | 546304 | 2 | 2 | 2 | 0 |
| round-001-SM-select-022-r03-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 11 | 258 | 15780 | 200512 | 0 | 0 | 0 | 0 |
| round-001-SM-select-022-r03-hybrid-guided-acceptance | hybrid_guided | operational_success | 21 | 649 | 42773 | 640640 | 2 | 0 | 0 | 2 |
| round-001-SM-select-022-r04-agent-only-acceptance | agent_only | operational_success | 43 | 1036 | 48350 | 1096512 | 2 | 5 | 1 | 1 |
| round-001-SM-select-022-r04-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 24 | 532 | 25527 | 788672 | 2 | 0 | 1 | 0 |
| round-001-SM-select-022-r04-hybrid-guided-acceptance | hybrid_guided | operational_success | 17 | 379 | 25416 | 515904 | 1 | 0 | 1 | 1 |
| round-001-TL-lev-020-r01-agent-only-acceptance | agent_only | operational_success | 34 | 241 | 10494 | 772736 | 3 | 11 | 0 | 0 |
| round-001-TL-lev-020-r01-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 18 | 168 | 8017 | 280704 | 0 | 0 | 0 | 0 |
| round-001-TL-lev-020-r01-hybrid-guided-acceptance | hybrid_guided | operational_success | 30 | 446 | 20518 | 779392 | 2 | 6 | 1 | 0 |
| round-001-TL-lev-020-r02-agent-only-acceptance | agent_only | operational_success | 25 | 195 | 9689 | 462464 | 1 | 0 | 1 | 0 |
| round-001-TL-lev-020-r02-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 14 | 225 | 11920 | 273600 | 1 | 2 | 0 | 0 |
| round-001-TL-lev-020-r02-hybrid-guided-acceptance | hybrid_guided | operational_success | 15 | 207 | 11043 | 260288 | 0 | 5 | 0 | 0 |
| round-001-TL-lev-020-r03-agent-only-acceptance | agent_only | operational_success | 21 | 258 | 10556 | 369152 | 1 | 6 | 0 | 0 |
| round-001-TL-lev-020-r03-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 18 | 293 | 15754 | 405760 | 1 | 0 | 0 | 0 |
| round-001-TL-lev-020-r03-hybrid-guided-acceptance | hybrid_guided | operational_success | 25 | 748 | 27483 | 690240 | 2 | 3 | 1 | 0 |
| round-001-TL-lev-020-r04-agent-only-acceptance | agent_only | operational_success | 14 | 206 | 10515 | 244672 | 2 | 0 | 0 | 0 |
| round-001-TL-lev-020-r04-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 22 | 522 | 18188 | 558464 | 4 | 0 | 1 | 1 |
| round-001-TL-lev-020-r04-hybrid-guided-acceptance | hybrid_guided | operational_success | 22 | 603 | 31196 | 602816 | 1 | 4 | 0 | 0 |
| round-001-TR-cancel-026-r01-agent-only-acceptance | agent_only | operational_success | 33 | 603 | 34129 | 1049152 | 4 | 0 | 0 | 0 |
| round-001-TR-cancel-026-r01-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 22 | 576 | 23253 | 523264 | 0 | 3 | 0 | 0 |
| round-001-TR-cancel-026-r01-hybrid-guided-acceptance | hybrid_guided | operational_success | 26 | 478 | 27942 | 656576 | 0 | 0 | 0 | 1 |
| round-001-TR-cancel-026-r02-agent-only-acceptance | agent_only | operational_success | 14 | 285 | 15841 | 266176 | 0 | 0 | 0 | 0 |
| round-001-TR-cancel-026-r02-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 29 | 317 | 16156 | 792576 | 2 | 1 | 1 | 0 |
| round-001-TR-cancel-026-r02-hybrid-guided-acceptance | hybrid_guided | operational_success | 29 | 455 | 16167 | 796544 | 2 | 10 | 2 | 0 |
| round-001-TR-cancel-026-r03-agent-only-acceptance | agent_only | operational_success | 45 | 983 | 42068 | 1850880 | 3 | 2 | 0 | 0 |
| round-001-TR-cancel-026-r03-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 31 | 499 | 20366 | 813952 | 0 | 17 | 0 | 0 |
| round-001-TR-cancel-026-r03-hybrid-guided-acceptance | hybrid_guided | operational_success | 28 | 678 | 32722 | 749504 | 0 | 1 | 0 | 0 |
| round-001-TR-cancel-026-r04-agent-only-acceptance | agent_only | operational_success | 28 | 470 | 16031 | 661504 | 2 | 0 | 0 | 0 |
| round-001-TR-cancel-026-r04-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 40 | 786 | 24493 | 1024896 | 0 | 1 | 0 | 0 |
| round-001-TR-cancel-026-r04-hybrid-guided-acceptance | hybrid_guided | operational_success | 25 | 313 | 9676 | 504704 | 0 | 0 | 0 | 0 |
| round-001-TR-discard-011-r01-agent-only-acceptance | agent_only | operational_success | 25 | 263 | 12522 | 430848 | 0 | 0 | 0 | 0 |
| round-001-TR-discard-011-r01-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 17 | 240 | 14034 | 368768 | 0 | 0 | 0 | 0 |
| round-001-TR-discard-011-r01-hybrid-guided-acceptance | hybrid_guided | operational_success | 19 | 278 | 15761 | 381120 | 0 | 1 | 0 | 0 |
| round-001-TR-discard-011-r02-agent-only-acceptance | agent_only | operational_success | 26 | 272 | 12272 | 539200 | 0 | 0 | 0 | 0 |
| round-001-TR-discard-011-r02-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 29 | 320 | 15693 | 586368 | 0 | 5 | 0 | 0 |
| round-001-TR-discard-011-r02-hybrid-guided-acceptance | hybrid_guided | operational_success | 26 | 217 | 7634 | 580800 | 0 | 14 | 0 | 0 |
| round-001-TR-discard-011-r03-agent-only-acceptance | agent_only | operational_success | 27 | 381 | 12935 | 662848 | 1 | 5 | 1 | 0 |
| round-001-TR-discard-011-r03-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 23 | 301 | 15970 | 579520 | 2 | 3 | 1 | 0 |
| round-001-TR-discard-011-r03-hybrid-guided-acceptance | hybrid_guided | operational_success | 23 | 270 | 14934 | 595968 | 0 | 0 | 0 | 0 |
| round-001-TR-discard-011-r04-agent-only-acceptance | agent_only | operational_success | 21 | 319 | 11699 | 479936 | 1 | 0 | 1 | 0 |
| round-001-TR-discard-011-r04-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 35 | 498 | 21075 | 979712 | 0 | 20 | 0 | 0 |
| round-001-TR-discard-011-r04-hybrid-guided-acceptance | hybrid_guided | operational_success | 17 | 162 | 10139 | 280256 | 0 | 0 | 0 | 0 |
| round-001-TR-order-010-r01-agent-only-acceptance | agent_only | operational_success | 30 | 327 | 18452 | 684480 | 3 | 2 | 0 | 0 |
| round-001-TR-order-010-r01-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 22 | 424 | 16687 | 480384 | 1 | 0 | 0 | 0 |
| round-001-TR-order-010-r01-hybrid-guided-acceptance | hybrid_guided | operational_success | 18 | 355 | 20887 | 454016 | 0 | 2 | 0 | 0 |
| round-001-TR-order-010-r02-agent-only-acceptance | agent_only | operational_success | 26 | 291 | 16462 | 594624 | 1 | 2 | 1 | 0 |
| round-001-TR-order-010-r02-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 16 | 169 | 7216 | 251264 | 0 | 0 | 0 | 0 |
| round-001-TR-order-010-r02-hybrid-guided-acceptance | hybrid_guided | operational_success | 24 | 238 | 9798 | 506240 | 2 | 0 | 0 | 0 |
| round-001-TR-order-010-r03-agent-only-acceptance | agent_only | operational_success | 26 | 396 | 23223 | 668800 | 1 | 0 | 0 | 0 |
| round-001-TR-order-010-r03-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 28 | 296 | 15698 | 751680 | 1 | 13 | 0 | 0 |
| round-001-TR-order-010-r03-hybrid-guided-acceptance | hybrid_guided | operational_success | 19 | 178 | 7457 | 330752 | 2 | 5 | 0 | 0 |
| round-001-TR-order-010-r04-agent-only-acceptance | agent_only | operational_success | 25 | 212 | 10849 | 506176 | 1 | 0 | 0 | 0 |
| round-001-TR-order-010-r04-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 21 | 406 | 21621 | 448192 | 1 | 5 | 0 | 0 |
| round-001-TR-order-010-r04-hybrid-guided-acceptance | hybrid_guided | operational_success | 17 | 217 | 8070 | 298560 | 1 | 3 | 0 | 0 |
| round-001-TS-trial-019-r01-agent-only-acceptance | agent_only | operational_success | 36 | 783 | 51873 | 1446144 | 4 | 0 | 2 | 0 |
| round-001-TS-trial-019-r01-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 20 | 384 | 20285 | 482688 | 2 | 1 | 0 | 0 |
| round-001-TS-trial-019-r01-hybrid-guided-acceptance | hybrid_guided | operational_success | 52 | 873 | 51862 | 1299520 | 3 | 18 | 0 | 0 |
| round-001-TS-trial-019-r02-agent-only-acceptance | agent_only | operational_success | 17 | 305 | 11530 | 291200 | 0 | 0 | 0 | 0 |
| round-001-TS-trial-019-r02-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 18 | 283 | 10819 | 266560 | 0 | 0 | 0 | 0 |
| round-001-TS-trial-019-r02-hybrid-guided-acceptance | hybrid_guided | operational_success | 14 | 254 | 11045 | 237632 | 0 | 0 | 0 | 0 |
| round-001-TS-trial-019-r03-agent-only-acceptance | agent_only | operational_success | 26 | 831 | 27294 | 571072 | 1 | 3 | 0 | 0 |
| round-001-TS-trial-019-r03-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 35 | 1013 | 38362 | 1180928 | 4 | 0 | 5 | 1 |
| round-001-TS-trial-019-r03-hybrid-guided-acceptance | hybrid_guided | operational_success | 22 | 666 | 19211 | 568064 | 2 | 3 | 1 | 0 |
| round-001-TS-trial-019-r04-agent-only-acceptance | agent_only | operational_success | 25 | 716 | 33589 | 775424 | 3 | 0 | 0 | 0 |
| round-001-TS-trial-019-r04-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 21 | 608 | 21675 | 459392 | 1 | 7 | 0 | 0 |
| round-001-TS-trial-019-r04-hybrid-guided-acceptance | hybrid_guided | operational_success | 21 | 504 | 22079 | 481216 | 1 | 11 | 0 | 0 |
| round-001-UC-credits-008-r01-agent-only-acceptance | agent_only | operational_success | 19 | 104 | 6209 | 288960 | 0 | 2 | 0 | 0 |
| round-001-UC-credits-008-r01-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 68 | 846 | 39737 | 2609216 | 3 | 28 | 2 | 0 |
| round-001-UC-credits-008-r01-hybrid-guided-acceptance | hybrid_guided | operational_success | 24 | 186 | 7170 | 428352 | 1 | 5 | 0 | 0 |
| round-001-UC-credits-008-r02-agent-only-acceptance | agent_only | operational_success | 27 | 369 | 15312 | 612416 | 1 | 2 | 1 | 0 |
| round-001-UC-credits-008-r02-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 29 | 252 | 10138 | 616320 | 0 | 9 | 1 | 0 |
| round-001-UC-credits-008-r02-hybrid-guided-acceptance | hybrid_guided | operational_success | 22 | 184 | 11356 | 458688 | 0 | 2 | 0 | 0 |
| round-001-UC-credits-008-r03-agent-only-acceptance | agent_only | operational_success | 107 | 2282 | 92555 | 7549312 | 6 | 6 | 5 | 3 |
| round-001-UC-credits-008-r03-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 16 | 226 | 8097 | 308544 | 0 | 0 | 0 | 0 |
| round-001-UC-credits-008-r03-hybrid-guided-acceptance | hybrid_guided | operational_success | 26 | 503 | 16074 | 620352 | 0 | 10 | 0 | 0 |
| round-001-UC-credits-008-r04-agent-only-acceptance | agent_only | operational_success | 34 | 286 | 9917 | 604352 | 1 | 4 | 1 | 0 |
| round-001-UC-credits-008-r04-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 21 | 273 | 9679 | 438016 | 1 | 0 | 1 | 0 |
| round-001-UC-credits-008-r04-hybrid-guided-acceptance | hybrid_guided | operational_success | 21 | 234 | 11716 | 346944 | 0 | 8 | 0 | 0 |
| round-001-VS-contrib-003-r01-agent-only-acceptance | agent_only | operational_success | 38 | 642 | 19266 | 1179520 | 0 | 4 | 0 | 0 |
| round-001-VS-contrib-003-r01-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 17 | 269 | 10473 | 357504 | 1 | 1 | 1 | 0 |
| round-001-VS-contrib-003-r01-hybrid-guided-acceptance | hybrid_guided | operational_success | 14 | 193 | 5506 | 233728 | 0 | 0 | 0 | 0 |
| round-001-VS-contrib-003-r02-agent-only-acceptance | agent_only | operational_success | 37 | 479 | 19778 | 893760 | 0 | 6 | 0 | 0 |
| round-001-VS-contrib-003-r02-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 11 | 148 | 5599 | 186624 | 0 | 0 | 0 | 0 |
| round-001-VS-contrib-003-r02-hybrid-guided-acceptance | hybrid_guided | operational_success | 26 | 625 | 22230 | 785344 | 1 | 1 | 0 | 0 |
| round-001-VS-contrib-003-r03-agent-only-acceptance | agent_only | operational_success | 61 | 831 | 46525 | 2804032 | 3 | 5 | 2 | 4 |
| round-001-VS-contrib-003-r03-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 17 | 162 | 9404 | 228544 | 0 | 3 | 0 | 0 |
| round-001-VS-contrib-003-r03-hybrid-guided-acceptance | hybrid_guided | operational_success | 14 | 104 | 5369 | 233600 | 0 | 0 | 0 | 0 |
| round-001-VS-contrib-003-r04-agent-only-acceptance | agent_only | operational_success | 76 | 1757 | 98213 | 5978368 | 3 | 7 | 0 | 12 |
| round-001-VS-contrib-003-r04-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 19 | 224 | 11667 | 383424 | 0 | 6 | 0 | 0 |
| round-001-VS-contrib-003-r04-hybrid-guided-acceptance | hybrid_guided | operational_success | 13 | 166 | 6626 | 228224 | 0 | 1 | 0 | 0 |
| round-001-VS-fees-001-r01-agent-only-acceptance | agent_only | operational_success | 15 | 214 | 10086 | 271680 | 0 | 0 | 0 | 0 |
| round-001-VS-fees-001-r01-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 21 | 265 | 11251 | 447680 | 0 | 12 | 0 | 0 |
| round-001-VS-fees-001-r01-hybrid-guided-acceptance | hybrid_guided | operational_success | 17 | 332 | 14910 | 352832 | 0 | 5 | 0 | 0 |
| round-001-VS-fees-001-r02-agent-only-acceptance | agent_only | operational_success | 16 | 392 | 15242 | 333952 | 0 | 2 | 0 | 0 |
| round-001-VS-fees-001-r02-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 15 | 248 | 13891 | 301376 | 0 | 1 | 0 | 0 |
| round-001-VS-fees-001-r02-hybrid-guided-acceptance | hybrid_guided | operational_success | 22 | 295 | 15674 | 478656 | 0 | 0 | 0 | 0 |
| round-001-VS-fees-001-r03-agent-only-acceptance | agent_only | operational_success | 27 | 298 | 17704 | 792512 | 2 | 1 | 1 | 0 |
| round-001-VS-fees-001-r03-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 19 | 288 | 12306 | 462144 | 0 | 0 | 0 | 0 |
| round-001-VS-fees-001-r03-hybrid-guided-acceptance | hybrid_guided | operational_success | 24 | 188 | 11174 | 541760 | 0 | 6 | 0 | 0 |
| round-001-VS-fees-001-r04-agent-only-acceptance | agent_only | operational_success | 20 | 407 | 16463 | 365760 | 1 | 4 | 0 | 2 |
| round-001-VS-fees-001-r04-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 17 | 173 | 10309 | 317248 | 0 | 2 | 0 | 0 |
| round-001-VS-fees-001-r04-hybrid-guided-acceptance | hybrid_guided | operational_success | 13 | 167 | 10399 | 209344 | 0 | 0 | 0 | 0 |
| round-001-VS-redeem-004-r01-agent-only-acceptance | agent_only | operational_success | 41 | 882 | 50218 | 1874688 | 2 | 3 | 0 | 2 |
| round-001-VS-redeem-004-r01-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 29 | 437 | 29964 | 1071744 | 1 | 1 | 0 | 1 |
| round-001-VS-redeem-004-r01-hybrid-guided-acceptance | hybrid_guided | operational_success | 40 | 481 | 32151 | 1536000 | 0 | 0 | 0 | 0 |
| round-001-VS-redeem-004-r02-agent-only-acceptance | agent_only | operational_success | 38 | 544 | 28197 | 1297152 | 1 | 8 | 2 | 0 |
| round-001-VS-redeem-004-r02-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 56 | 1406 | 70433 | 2422336 | 5 | 13 | 0 | 1 |
| round-001-VS-redeem-004-r02-hybrid-guided-acceptance | hybrid_guided | operational_success | 28 | 474 | 32892 | 1005952 | 3 | 1 | 0 | 0 |
| round-001-VS-redeem-004-r03-agent-only-acceptance | agent_only | operational_success | 30 | 502 | 28719 | 948160 | 1 | 3 | 1 | 6 |
| round-001-VS-redeem-004-r03-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 29 | 539 | 29546 | 1059328 | 1 | 0 | 0 | 0 |
| round-001-VS-redeem-004-r03-hybrid-guided-acceptance | hybrid_guided | operational_success | 38 | 601 | 33881 | 1027904 | 0 | 5 | 0 | 0 |
| round-001-VS-redeem-004-r04-agent-only-acceptance | agent_only | operational_success | 26 | 431 | 26808 | 786944 | 1 | 13 | 1 | 0 |
| round-001-VS-redeem-004-r04-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 20 | 385 | 22719 | 501120 | 1 | 0 | 1 | 1 |
| round-001-VS-redeem-004-r04-hybrid-guided-acceptance | hybrid_guided | operational_success | 29 | 481 | 29371 | 846464 | 1 | 2 | 1 | 0 |
| round-001-VS-shares-002-r01-agent-only-acceptance | agent_only | operational_success | 18 | 213 | 9622 | 321792 | 1 | 0 | 1 | 0 |
| round-001-VS-shares-002-r01-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 19 | 352 | 17413 | 491392 | 2 | 3 | 0 | 0 |
| round-001-VS-shares-002-r01-hybrid-guided-acceptance | hybrid_guided | operational_success | 27 | 312 | 15824 | 753664 | 2 | 2 | 0 | 0 |
| round-001-VS-shares-002-r02-agent-only-acceptance | agent_only | operational_success | 20 | 190 | 6996 | 302848 | 1 | 3 | 0 | 2 |
| round-001-VS-shares-002-r02-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 20 | 142 | 7258 | 315392 | 0 | 6 | 0 | 0 |
| round-001-VS-shares-002-r02-hybrid-guided-acceptance | hybrid_guided | operational_success | 35 | 528 | 29171 | 864512 | 1 | 11 | 0 | 1 |
| round-001-VS-shares-002-r03-agent-only-acceptance | agent_only | operational_success | 23 | 219 | 11969 | 393280 | 1 | 4 | 0 | 0 |
| round-001-VS-shares-002-r03-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 21 | 269 | 12664 | 434752 | 2 | 2 | 0 | 0 |
| round-001-VS-shares-002-r03-hybrid-guided-acceptance | hybrid_guided | operational_success | 18 | 435 | 18694 | 367104 | 1 | 0 | 0 | 0 |
| round-001-VS-shares-002-r04-agent-only-acceptance | agent_only | operational_success | 15 | 113 | 5783 | 233472 | 0 | 0 | 0 | 0 |
| round-001-VS-shares-002-r04-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 31 | 195 | 10437 | 1126656 | 0 | 9 | 0 | 0 |
| round-001-VS-shares-002-r04-hybrid-guided-acceptance | hybrid_guided | operational_success | 13 | 93 | 4794 | 224576 | 0 | 0 | 0 | 0 |
| round-001-WU-consume-023-r01-agent-only-acceptance | agent_only | operational_success | 18 | 211 | 11250 | 320640 | 0 | 0 | 1 | 0 |
| round-001-WU-consume-023-r01-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 10 | 168 | 8599 | 145664 | 0 | 1 | 0 | 0 |
| round-001-WU-consume-023-r01-hybrid-guided-acceptance | hybrid_guided | operational_success | 14 | 136 | 5616 | 230720 | 0 | 4 | 0 | 0 |
| round-001-WU-consume-023-r02-agent-only-acceptance | agent_only | operational_success | 16 | 317 | 7508 | 214336 | 1 | 4 | 0 | 0 |
| round-001-WU-consume-023-r02-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 10 | 117 | 4944 | 162176 | 0 | 2 | 0 | 0 |
| round-001-WU-consume-023-r02-hybrid-guided-acceptance | hybrid_guided | operational_success | 13 | 96 | 5334 | 203392 | 0 | 3 | 0 | 0 |
| round-001-WU-consume-023-r03-agent-only-acceptance | agent_only | operational_success | 14 | 106 | 6141 | 197376 | 0 | 3 | 0 | 0 |
| round-001-WU-consume-023-r03-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 14 | 108 | 6022 | 226880 | 0 | 6 | 0 | 0 |
| round-001-WU-consume-023-r03-hybrid-guided-acceptance | hybrid_guided | operational_success | 11 | 109 | 6377 | 168640 | 0 | 3 | 0 | 0 |
| round-001-WU-consume-023-r04-agent-only-acceptance | agent_only | operational_success | 11 | 108 | 5594 | 140672 | 0 | 0 | 0 | 0 |
| round-001-WU-consume-023-r04-hybrid-flexible-acceptance | hybrid_flexible | operational_success | 11 | 169 | 7095 | 168064 | 0 | 3 | 0 | 0 |
| round-001-WU-consume-023-r04-hybrid-guided-acceptance | hybrid_guided | operational_success | 14 | 159 | 9585 | 254912 | 0 | 5 | 0 | 0 |

| arm | runs | success | turns (total) | API s | out tok | cache-read | cost USD |
|---|---:|---:|---:|---:|---:|---:|---:|
| agent_only | 68 | 68 | 1851 | 30571 | 1459974 | 57679936 | 80.05 |
| hybrid_flexible | 68 | 68 | 1484 | 24895 | 1154434 | 37005376 | 60.46 |
| hybrid_guided | 68 | 68 | 1471 | 24627 | 1184692 | 35863872 | 60.82 |

| failure kind | count |
|---|---:|
| name_resolution | 85 |
| unclassified | 55 |
| postcondition | 51 |
| abort_not_covered | 30 |
| abort_never_happens | 13 |
| tool_usage_error | 8 |
| loop_invariant_induction | 6 |
| solver_timeout | 6 |
| unsupported_construct | 3 |
| type_error | 3 |
| spec_context_error | 2 |
| loop_invariant | 2 |
| tool_infrastructure | 2 |
| loop_invariant_base | 1 |
| syntax_error | 1 |
| declaration_error | 1 |
