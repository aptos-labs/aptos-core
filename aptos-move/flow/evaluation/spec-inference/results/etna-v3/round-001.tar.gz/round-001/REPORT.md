# round-001 — results

Specification-inference evaluation, three arms, held-out mutation scoring.

| | |
|---|---|
| round | `round-001` |
| corpus | `etna-v3` — aptos-core `5dac5769`, etna `dd23678f` |
| design | 17 tasks × 3 arms × 4 replicates = **204 cells**, balanced, no gaps |
| source commit | `89cc15227e75f9214cc29732bdd20c2e3b7a6d6a` (reachable from `upstream/main`) |
| move-flow | `48ca9af214e14774` · 7 stage identities pinned per run |
| screening | 24/24 ready, 16 `wp_hard` |
| concurrency | 3 |
| total | 8,216,565 input + 3,799,100 output tokens · $201.33 · 1,492 cell-minutes |

Arms differ in one thing: whether `move_package_wp` is reachable.

- `agent_only` — WP unavailable.
- `hybrid_guided` — prescribed invariants → WP → repair → verify.
- `hybrid_flexible` — WP available, workflow chosen by the agent.

---

## 1. Token cost

### 1.1 Totals — the whole workload

| arm | output tokens | vs agent_only | input tokens | cost | vs agent_only |
|---|---:|---:|---:|---:|---:|
| `agent_only` | 1,459,974 | 1.00× | 2,942,453 | $80.05 | 1.00× |
| `hybrid_guided` | 1,184,692 | **0.81×** | 2,654,582 | $60.82 | **0.76×** |
| `hybrid_flexible` | 1,154,434 | **0.79×** | 2,619,530 | $60.46 | **0.76×** |

Both hybrid arms used ~20% fewer output tokens and cost ~24% less across the round.

### 1.2 Per cell — central tendency

| arm | mean | vs agent | median | vs agent | CV |
|---|---:|---:|---:|---:|---:|
| `agent_only` | 21,470 | 1.00× | 15,277 | 1.00× | 89% |
| `hybrid_guided` | 17,422 | 0.81× | 13,957 | 0.91× | 71% |
| `hybrid_flexible` | 16,977 | 0.79× | 13,778 | 0.90× | 73% |

The mean ratio (0.79–0.81×) matches the totals. The median ratio (0.90–0.91×) is smaller,
because the arms differ most in their expensive cells.

### 1.3 Distribution

| arm | min | p25 | median | p75 | p90 | max | cells >40k |
|---|---:|---:|---:|---:|---:|---:|---:|
| `agent_only` | 3,186 | 9,689 | 15,277 | 28,197 | 48,350 | 98,213 | **10** |
| `hybrid_guided` | 2,802 | 7,634 | 13,957 | 27,483 | 33,690 | 51,862 | **5** |
| `hybrid_flexible` | 1,752 | 9,043 | 13,778 | 21,075 | 35,062 | 70,433 | **3** |

`agent_only` cells above 40k output tokens total 583,677 tokens; `hybrid_guided` 227,531; `hybrid_flexible` 172,836.

Six most expensive cells in the round:

| output tokens | arm | task | rep |
|---:|---|---|---:|
| 98,213 | `agent_only` | `VS-contrib-003` | 4 |
| 92,555 | `agent_only` | `UC-credits-008` | 3 |
| 70,433 | `hybrid_flexible` | `VS-redeem-004` | 2 |
| 62,162 | `agent_only` | `QP-part-025` | 1 |
| 53,871 | `hybrid_flexible` | `QP-part-025` | 3 |
| 51,873 | `agent_only` | `TS-trial-019` | 1 |

### 1.4 Paired within task and replicate

Each hybrid cell against the `agent_only` cell on the same task and replicate, 68 blocks.

| arm | median ratio | mean ratio | cheaper in | min | max |
|---|---:|---:|---:|---:|---:|
| `hybrid_guided` | 0.99× | 1.07× | 35 / 68 | 0.07× | 4.17× |
| `hybrid_flexible` | 0.91× | 1.08× | 38 / 68 | 0.09× | 6.40× |

The mean of ratios exceeds 1 while the ratio of totals is 0.79–0.81×: ratios are asymmetric
(a 4.17× and a 0.24× do not cancel), so the mean of ratios is not a cost estimate. The ratio of
totals in §1.1 is.

**The three framings, side by side:**

| question | statistic | answer |
|---|---|---|
| what did the round cost? | ratio of totals | hybrids 0.79–0.81× |
| what does a cell cost on average? | ratio of means | hybrids 0.79–0.81× |
| what does a typical cell cost? | ratio of medians | hybrids 0.90–0.91× |
| does the hybrid win a given block? | paired median / win rate | 0.91–0.99×, 35–38 of 68 |

### 1.5 Per-task totals (4 replicates summed, output tokens)

| task | agent_only | hybrid_guided | hybrid_flexible | g/a | f/a |
|---|---:|---:|---:|---:|---:|
| `BA-base-012` | 125,041 | 77,467 | 110,388 | 0.62 | 0.88 |
| `LP-price-021` | 35,992 | 50,831 | 44,941 | 1.41 | 1.25 |
| `MM-min-013` | 25,368 | 24,668 | 27,926 | 0.97 | 1.10 |
| `OV-order-006` | 19,920 | 13,094 | 13,256 | 0.66 | 0.67 |
| `QP-part-025` | 184,038 | 142,450 | 140,904 | 0.77 | 0.77 |
| `SM-select-022` | 111,517 | 138,664 | 80,092 | 1.24 | 0.72 |
| `TL-lev-020` | 41,254 | 90,240 | 53,879 | 2.19 | 1.31 |
| `TR-cancel-026` | 108,069 | 86,507 | 84,268 | 0.80 | 0.78 |
| `TR-discard-011` | 49,428 | 48,468 | 66,772 | 0.98 | 1.35 |
| `TR-order-010` | 68,986 | 46,212 | 61,222 | 0.67 | 0.89 |
| `TS-trial-019` | 124,286 | 104,197 | 91,141 | 0.84 | 0.73 |
| `UC-credits-008` | 123,993 | 46,316 | 67,651 | 0.37 | 0.55 |
| `VS-contrib-003` | 183,782 | 39,731 | 37,143 | 0.22 | 0.20 |
| `VS-fees-001` | 59,495 | 52,157 | 47,757 | 0.88 | 0.80 |
| `VS-redeem-004` | 133,942 | 128,295 | 152,662 | 0.96 | 1.14 |
| `VS-shares-002` | 34,370 | 68,483 | 47,772 | 1.99 | 1.39 |
| `WU-consume-023` | 30,493 | 26,912 | 26,660 | 0.88 | 0.87 |
| **all 17** | **1,459,974** | **1,184,692** | **1,154,434** | **0.81** | **0.79** |

Hybrid cheaper on 12 of 17 tasks (`hybrid_guided`) and 13 of 17 (`hybrid_flexible`).
Largest saving `VS-contrib-003` (0.20–0.22×); largest excess `TL-lev-020` (2.19× guided).

### 1.6 Per-task medians (output tokens)

| task | agent_only | hybrid_guided | hybrid_flexible | g/a | f/a |
|---|---:|---:|---:|---:|---:|
| `BA-base-012` | 31,172 | 18,985 | 29,253 | 0.61 | 0.94 |
| `LP-price-021` | 7,578 | 9,447 | 11,116 | 1.25 | 1.47 |
| `MM-min-013` | 5,712 | 6,244 | 7,176 | 1.09 | 1.26 |
| `OV-order-006` | 4,064 | 3,216 | 3,236 | 0.79 | 0.80 |
| `QP-part-025` | 45,856 | 36,721 | 34,153 | 0.80 | 0.74 |
| `SM-select-022` | 22,745 | 34,094 | 19,392 | 1.50 | 0.85 |
| `TL-lev-020` | 10,504 | 24,000 | 13,837 | 2.28 | 1.32 |
| `TR-cancel-026` | 25,080 | 22,054 | 21,809 | 0.88 | 0.87 |
| `TR-discard-011` | 12,397 | 12,536 | 15,831 | 1.01 | 1.28 |
| `TR-order-010` | 17,457 | 8,934 | 16,192 | 0.51 | 0.93 |
| `TS-trial-019` | 30,441 | 20,645 | 20,980 | 0.68 | 0.69 |
| `UC-credits-008` | 12,614 | 11,536 | 9,908 | 0.91 | 0.79 |
| `VS-contrib-003` | 33,151 | 6,066 | 9,938 | 0.18 | 0.30 |
| `VS-fees-001` | 15,852 | 13,042 | 11,778 | 0.82 | 0.74 |
| `VS-redeem-004` | 28,458 | 32,521 | 29,755 | 1.14 | 1.05 |
| `VS-shares-002` | 8,309 | 17,259 | 11,550 | 2.08 | 1.39 |
| `WU-consume-023` | 6,824 | 5,996 | 6,558 | 0.88 | 0.96 |

### 1.7 Wall clock

| arm | total min | mean | median | max |
|---|---:|---:|---:|---:|
| `agent_only` | 545 | 8.0 | 5.6 | 39.0 |
| `hybrid_guided` | 473 | 7.0 | 5.3 | 45.0 |
| `hybrid_flexible` | 474 | 7.0 | 4.9 | 54.2 |

---

## 2. Tool usage

### 2.1 Manipulation check

| arm | WP calls | cells using WP |
|---|---:|---:|
| `agent_only` | 0 | 0 / 68 |
| `hybrid_guided` | 99 | 68 / 68 |
| `hybrid_flexible` | 98 | 67 / 68 |

### 2.2 Mean calls per cell

| tool | agent_only | hybrid_guided | hybrid_flexible |
|---|---:|---:|---:|
| `Grep` | 5.1 | 4.1 | 4.1 |
| `Read` | 4.6 | 4.3 | 4.2 |
| `Edit` | 5.4 | 3.1 | 3.2 |
| `move_package_status` | 2.6 | 1.8 | 2.0 |
| `move_spec_check` | 2.0 | 1.3 | 1.7 |
| `Glob` | 2.1 | 1.6 | 1.2 |
| `move_package_verify` | 1.9 | 1.3 | 0.6 |
| `move_package_manifest` | 1.0 | 1.0 | 1.0 |
| `move_package_wp` | 0.0 | 1.5 | 1.4 |

`agent_only` performs ~70% more edits and ~3× the verify calls of `hybrid_flexible`.

---

## 3. Outcome — with refutation

Refutation was **on**: on operational success the controller re-ran the refutation mutant set,
and if a mutant survived returned the cell to the agent naming the obligation categories left
unconstrained (never a mutant).

| measure | agent_only | hybrid_guided | hybrid_flexible | total |
|---|---:|---:|---:|---:|
| operational success | 68/68 | 68/68 | 68/68 | **204/204** |
| strict success (held-out) | 68/68 | 68/68 | 68/68 | **204/204** |
| inconclusive | 0 | 0 | 0 | **0** |
| mutation adequacy | 1.00 | 1.00 | 1.00 | 1.00 |

Every task carries exactly 3 essential mutants (the harness minimum). Every cell killed 3/3.

Judge turns per cell: 197 cells × 1, 6 cells × 2, 1 cell × 3.

**`strict_success` has zero variance and cannot distinguish the arms.**

---

## 4. Outcome — without refutation (reconstructed)

A cell that converged on turn 1 never had its contract altered, so the tree scored **is** its
first-pass contract. Only 7 cells took a further turn; each records its turn-1 verdict.

### 4.1 The 7 cells

| task | arm | rep | turn-1 state | diagnostic |
|---|---|---:|---|---|
| `QP-part-025` | `agent_only` | 1 | `weak_contract` | 1 of 4 refutations survive · normal-result |
| `QP-part-025` | `agent_only` | 2 | `weak_contract` | 1 of 4 refutations survive · normal-result |
| `VS-contrib-003` | `agent_only` | 4 | `weak_contract` | 1 of 3 refutations survive |
| `UC-credits-008` | `agent_only` | 3 | `forbidden_weakening` | implementation changed: `extracted_tier_lookup` |
| `QP-part-025` | `hybrid_flexible` | 4 | `weak_contract` | 1 of 4 refutations survive · normal-result |
| `VS-redeem-004` | `hybrid_flexible` | 2 | `infrastructure_failure` | Flow MCP supervisor restarted session |
| `TS-trial-019` | `hybrid_guided` | 1 | `infrastructure_failure` | Flow MCP supervisor restarted session |

### 4.2 Counts by cause

| cause | agent_only | hybrid_guided | hybrid_flexible |
|---|---:|---:|---:|
| `weak_contract` | 3 | 0 | 1 |
| `forbidden_weakening` | 1 | 0 | 0 |
| `infrastructure_failure` | 0 | 1 | 1 |

### 4.3 First-pass completeness

| arm | complete | incomplete | rate |
|---|---:|---:|---:|
| `agent_only` | 64 | 4 | 94.1% |
| `hybrid_guided` | 67 | 0 | 100% |
| `hybrid_flexible` | 66 | 1 | 98.5% |

(Infrastructure cells excluded from the denominator.)

### 4.4 Significance — all three readings

One-sided Fisher exact, `agent_only` vs both hybrid arms pooled.

| reading | ratio | p |
|---|---|---:|
| infrastructure excluded, both quality modes counted | 4/68 vs 1/134 | **0.045** |
| `weak_contract` only | 3/68 vs 1/134 | 0.112 |
| infrastructure counted against its arm | 4/68 vs 3/136 | 0.169 |

Both infrastructure cells are hybrid cells, so excluding them favours the hybrids. The analysis
was selected after seeing the data.

### 4.5 Limits of the reconstruction

- The turn-1 tree is not preserved (only `tree_sha256`), so those 4 contracts cannot be scored
  against the held-out set. The measure is "defeated by a refutation mutant", not `strict_success`.
- 5 events across 204 cells.

---

## 5. What the agents said they did

Every cell ends by answering three questions posed by the `move-inf` skill — *Result*,
*Strategy*, *Decision points*. All 204 answers are in [`DEBRIEF.md`](DEBRIEF.md), verbatim.
Coding them by recurring theme (regex over the answer text, share of that arm's 68 cells):

| theme | agent_only | hybrid_guided | hybrid_flexible |
|---|---:|---:|---:|
| abort-set exhaustiveness discussed | 97% | 95% | 95% |
| `pragma opaque` used | 92% | 92% | 92% |
| recursive spec function authored | 69% | 54% | 70% |
| loop invariant authored | 64% | 60% | 58% |
| solver timeout / quantifier trouble | 38% | 32% | 33% |
| **counterexample used to find the fix** | **52%** | 29% | 29% |
| **self-designed mutation probe** | **42%** | 7% | 17% |
| **WP named the uninvariant loop** | **0%** | **33%** | **27%** |
| dropping a pragma as positive evidence | 0% | 7% | 5% |
| `move_package_wp` named in the answer | 0 | 40 | 36 |

### 5.1 The arms agree on the product and differ on the search

The top rows are flat. All three arms author opaque contracts, discuss abort exhaustiveness, write
recursive spec helpers and loop invariants at nearly identical rates, and hit solver trouble
equally often. What they produce is the same kind of artifact.

The bottom rows are not flat, and they describe how the work was found. `agent_only` reaches its
contract through **counterexamples (52% vs 29%)** and **probes it designed itself (42% vs 7–17%)**.
The hybrids are told where the problem is: **a third of their answers report WP naming an
uninvariant loop**, a sentence that appears in zero `agent_only` answers.

### 5.2 Without WP: probe and counterexample

`agent_only` · `BA-base-012` · r1 — testing its own abort bound by deliberately weakening it:

> *Mutation probe on the abort bound* (relaxing `MAX_U64` → `MAX_U128`): verification failed with a
> counterexample aborting at exactly `MAX_U64 + 1`, evidencing that the bound is tight and the
> clause characterizes aborts rather than over-approximating them. Restored; the re-check passed.

`agent_only` · `BA-base-012` · r2 — the same instinct, used against vacuity:

> Derived the contract by weakest-precondition over the loop, then let the first check's
> counterexample drive the fix. A negative probe (mutating `ensures` by `+1`) was refuted with a
> 4-element counterexample, confirming the clauses carry weight rather than verifying vacuously.

`agent_only` · `BA-base-012` · r4 — a probe used to justify a modelling choice:

> A probe (`assert forall e in ask_sizes: e >= 0 && e <= MAX_U64`) established that element range
> facts are available without an invariant, which justified clamping `tail_sum` below at `0`: the
> clamp is inert for real `u64` data but makes the helper's range manifest from one unfolding.

This is a competent search, and an expensive one — it is the behaviour behind `agent_only`'s ten
cells above 40k output tokens (§1.3).

### 5.3 With WP: the loop is named, then the output is rewritten

`hybrid_flexible` · `BA-base-012` · r1 — WP as a diagnosis to act on, not a loop to iterate:

> Ran the WP pass first, which flagged the `for` loop as uninvarianted and the aborts as
> uncharacterizable. Rather than iterate WP against a loop it had already told me it could not
> constrain, I built the invariant directly from its bounded loop-head facts and the exit fact
> needed at the assert, then let `move_spec_check` decide — one accepted round.

`hybrid_guided` · `BA-base-012` · r4 — WP rerun as confirmation that the abstraction is adequate:

> `move_package_wp` returned two linked warnings (uninvariant loop leaving the result `vacuous`,
> and `aborts_if_is_partial` for the same reason). The bounded loop-head facts generalized directly
> into the prefix-sum invariant, and rerunning WP on that filter alone produced no warnings,
> confirming the abstraction was adequate before simplification.

`hybrid_guided` · `TR-cancel-026` · r1 — WP's output as a draft to be rewritten, not adopted:

> WP's derived clauses quantified over the loop-havoced post-state, which is vacuous on the removal
> path — I replaced it with first-occurrence quantification.

### 5.4 A move only the hybrids made

Five `hybrid_guided` and four `hybrid_flexible` answers describe *removing* a weakening pragma to
prove something, a technique absent from all 68 `agent_only` answers:

> Dropped `aborts_if_is_partial` and re-derived aborts exhaustively rather than keeping WP's lower
> bound — evidence: WP's warning named an uncharacterized abort while the four abort sources (two
> overflows, zero denominator, non-overflowing `+1`) are fully enumerable, and the check confirmed
> completeness.
>
> — `hybrid_flexible` · `LP-price-021` · r2

> Probing was done by *dropping* the partial-abort pragma rather than adding clauses — verification
> succeeding at that point is positive evidence the abort set is exhaustive.
>
> — `hybrid_guided` · `VS-contrib-003` · r1 · 0.18× the tokens of its `agent_only` pair

### 5.5 After refutation

The one `agent_only` cell that had to be told its contract was too weak, describing the repair:

> The surviving refutation class was "right partition point, wrong contents", so the fix had to
> determine the permutation exactly. A forward-recursion mirror timed out at 5s with ~150k
> quantifier instantiations; rewriting it as the single-application backward `swept` invariant
> verified in the same budget — the double application was the blowup, not the strength.
>
> — `agent_only` · `QP-part-025` · r1 · second turn

The message that prompted it named the obligation category and never the mutant:

> The specification verifies, but it is too weak: an implementation that violates the intended
> behaviour still satisfies it, so a caller verified against this contract could not rule that
> behaviour out. Obligation categories left unconstrained: `normal-result`.

### 5.6 Caveat

These are self-reports written by the agent being measured, and the coding is regex over free
text: a theme is counted when the answer *mentions* it. The flat rows are the more reliable half —
an arm under-reporting a technique it used would show up as a spurious difference, and the
techniques that differ are the ones tied to tool availability, which is the manipulated variable.

---

## 6. Artifacts

Under `evaluation-artifacts/round-001/`:

| file | contents |
|---|---|
| `schedule/pilot-manifest.json` | 204 run specs, provenance, apparatus identities |
| `runs/<run-id>/run.json` | per-cell manifest, result, judge state |
| `runs/<run-id>/controller-events.jsonl` | prompts, agent results, refutation events |
| `runs/<run-id>/claude-events.jsonl` | full model transcript |
| `runs/<run-id>/judge-attempt-N-turn-M.json` | per-turn verdict incl. turn-1 state |
| `runs/<run-id>/mutation-score.json` | held-out scoring |
| `runs/<run-id>/final/` | the judged tree |
| `summary.json`, `mutation-summary.json` | round aggregates |
| `launch-report.json`, `preflight.json` | launch and preflight records |

Apparatus verified before launch: corpus rebuilds to the screened bytes (39 files), 16 references
assemble, refutation and scoring mutant sets disjoint by fingerprint across all 17 tasks, every run
pins 7 stage identities, all plugins pinned to `89cc1522`.
