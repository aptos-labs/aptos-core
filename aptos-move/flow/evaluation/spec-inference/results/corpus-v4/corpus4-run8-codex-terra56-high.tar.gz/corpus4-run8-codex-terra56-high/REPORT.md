# corpus4-run8-codex-terra56-high

Model `gpt-5.6-terra`; 312 of 312 scheduled cells recorded. Cost is API-equivalent, priced per request from the recorded token counts ($2.0/M input, $0.2/M cached, $12.0/M output, reasoning included in output; a request above 272,000 input tokens is long-context).

| arm | strict | unmeasured | disqualified | operational | cost | mean / cell | cost / strict success | mean wall | long-context requests |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| agent_only | 97/102 | 2 | 5 | 104/104 | $21.0536 | $0.2024 | $0.2170 | 152.9 s | 0 |
| hybrid_flexible | 98/104 | 0 | 6 | 104/104 | $18.7919 | $0.1807 | $0.1918 | 143.1 s | 0 |
| hybrid_guided | 97/103 | 1 | 6 | 104/104 | $16.7138 | $0.1607 | $0.1723 | 148.0 s | 0 |

Contrasts are equal-weight means over tasks of within-task block differences, with 95% task-bootstrap intervals; p-values are blocked randomization tests, Holm-adjusted across C1 and C2.

| contrast | strict success | Holm p | cost / cell | wall / cell | restricted time to success |
| --- | ---: | ---: | ---: | ---: | ---: |
| C1: hybrid_flexible minus agent_only | -1.3 pp [-5.1, +1.9] | 1.0000 | -0.022 [-0.054, +0.010] | -9.9 s [-40.0, +23.7] | +38.9 s [-89.3, +179.9] |
| C2: hybrid_guided minus hybrid_flexible | +0.0 pp [-3.8, +4.8] | 1.0000 | -0.020 [-0.041, +0.007] | +5.0 s [-41.1, +67.2] | -11.1 s [-151.8, +118.0] |
| C3: hybrid_guided minus agent_only | -0.3 pp [-6.7, +5.8] | – | -0.042 [-0.083, +0.003] | -4.9 s [-56.4, +62.3] | -3.4 s [-196.3, +209.4] |

| task | agent_only strict | agent_only mean cost | hybrid_flexible strict | hybrid_flexible mean cost | hybrid_guided strict | hybrid_guided mean cost |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| DM-keepalive-035 | 4/4 | $0.2732 | 4/4 | $0.1017 | 4/4 | $0.0598 |
| DM-valid-036 | 4/4 | $0.2690 | 4/4 | $0.1102 | 4/4 | $0.0622 |
| EA-scheme-041 | 4/4 | $0.1420 | 4/4 | $0.2017 | 4/4 | $0.1735 |
| JW-upsert-049 | 3/4 | $0.3098 | 3/4 | $0.3349 | 2/4 | $0.2198 |
| MS-capacity-048 | 4/4 | $0.1132 | 4/4 | $0.0851 | 4/4 | $0.0588 |
| MS-pending-046 | 4/4 | $0.3060 | 4/4 | $0.3922 | 4/4 | $0.3248 |
| MS-timelock-047 | 3/4 | $0.2388 | 4/4 | $0.0976 | 4/4 | $0.0594 |
| PT-taker-034 | 4/4 | $0.1361 | 4/4 | $0.0876 | 4/4 | $0.0610 |
| QP-part-025 | 0/4 | $0.1978 | 0/4 | $0.2555 | 2/4 | $0.4757 |
| RL-refill-037 | 4/4 | $0.1684 | 4/4 | $0.0958 | 4/4 | $0.0596 |
| RL-request-043 | 4/4 | $0.0995 | 4/4 | $0.1217 | 4/4 | $0.0592 |
| SM-select-022 | 3/4 | $0.3376 | 4/4 | $0.4350 | 3/4 | $0.5577 |
| SU-split-045 | 4/4 | $0.1847 | 4/4 | $0.1934 | 4/4 | $0.1721 |
| TL-build-039 | 4/4 | $0.2324 | 4/4 | $0.3197 | 4/4 | $0.2381 |
| TL-enough-044 | 4/4 | $0.2171 | 4/4 | $0.1212 | 4/4 | $0.1407 |
| TL-find-040 | 4/4 | $0.1746 | 4/4 | $0.1183 | 4/4 | $0.0827 |
| TL-tiers-038 | 4/4 | $0.1950 | 4/4 | $0.3202 | 4/4 | $0.2596 |
| TL-update-050 | 4/4 | $0.1590 | 4/4 | $0.1054 | 4/4 | $0.0655 |
| TR-cancel-026 | 4/4 | $0.1922 | 3/4 | $0.1880 | 2/4 | $0.1937 |
| TR-discard-011 | 4/4 | $0.1940 | 4/4 | $0.1837 | 4/4 | $0.1438 |
| TR-match-029 | 4/4 | $0.2569 | 4/4 | $0.0864 | 4/4 | $0.0649 |
| TR-nonzero-031 | 4/4 | $0.1254 | 4/4 | $0.1402 | 4/4 | $0.1439 |
| TR-order-010 | 4/4 | $0.1590 | 4/4 | $0.1638 | 4/4 | $0.1439 |
| TR-reinsert-030 | 4/4 | $0.1921 | 4/4 | $0.0795 | 4/4 | $0.0572 |
| TR-sanitize-028 | 4/4 | $0.1732 | 4/4 | $0.0949 | 4/4 | $0.0590 |
| VR-range-042 | 4/4 | $0.2163 | 4/4 | $0.2642 | 4/4 | $0.2419 |

Audit findings: 3; see `analysis.json`.
