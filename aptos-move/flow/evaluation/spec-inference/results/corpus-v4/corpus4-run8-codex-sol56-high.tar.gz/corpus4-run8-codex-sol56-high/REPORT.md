# corpus4-run8-codex-sol56-high

Model `gpt-5.6-sol`; 312 of 312 scheduled cells recorded. Cost is API-equivalent, priced per request from the recorded token counts ($4.0/M input, $0.4/M cached, $20.0/M output, reasoning included in output; a request above 272,000 input tokens is long-context).

| arm | strict | unmeasured | disqualified | operational | cost | mean / cell | cost / strict success | mean wall | long-context requests |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| agent_only | 103/104 | 0 | 1 | 104/104 | $36.7243 | $0.3531 | $0.3565 | 120.7 s | 0 |
| hybrid_flexible | 98/100 | 4 | 2 | 104/104 | $31.8144 | $0.3059 | $0.3246 | 114.9 s | 0 |
| hybrid_guided | 98/103 | 1 | 5 | 104/104 | $31.6669 | $0.3045 | $0.3231 | 125.8 s | 0 |

Contrasts are equal-weight means over tasks of within-task block differences, with 95% task-bootstrap intervals; p-values are blocked randomization tests, Holm-adjusted across C1 and C2.

| contrast | strict success | Holm p | cost / cell | wall / cell | restricted time to success |
| --- | ---: | ---: | ---: | ---: | ---: |
| C1: hybrid_flexible minus agent_only | -1.0 pp [-2.9, +0.0] | 1.0000 | -0.047 [-0.094, -0.004] | -5.7 s [-23.7, +12.9] | +26.6 s [-21.0, +103.4] |
| C2: hybrid_guided minus hybrid_flexible | -1.9 pp [-5.8, +0.0] | 1.0000 | -0.001 [-0.040, +0.046] | +10.9 s [-12.1, +43.5] | +72.0 s [-3.1, +209.8] |
| C3: hybrid_guided minus agent_only | -3.8 pp [-10.6, +0.0] | – | -0.049 [-0.124, +0.031] | +5.2 s [-30.8, +50.8] | +142.0 s [-7.1, +376.7] |

| task | agent_only strict | agent_only mean cost | hybrid_flexible strict | hybrid_flexible mean cost | hybrid_guided strict | hybrid_guided mean cost |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| DM-keepalive-035 | 4/4 | $0.5166 | 4/4 | $0.2057 | 4/4 | $0.1479 |
| DM-valid-036 | 4/4 | $0.4931 | 4/4 | $0.2089 | 4/4 | $0.1398 |
| EA-scheme-041 | 4/4 | $0.3488 | 4/4 | $0.3662 | 4/4 | $0.4839 |
| JW-upsert-049 | 4/4 | $0.5653 | 2/4 | $0.4684 | 1/4 | $0.3144 |
| MS-capacity-048 | 4/4 | $0.2392 | 4/4 | $0.1534 | 4/4 | $0.1309 |
| MS-pending-046 | 4/4 | $0.7049 | 4/4 | $0.7249 | 4/4 | $0.7386 |
| MS-timelock-047 | 4/4 | $0.4646 | 4/4 | $0.1630 | 4/4 | $0.1117 |
| PT-taker-034 | 4/4 | $0.2183 | 4/4 | $0.1332 | 4/4 | $0.1179 |
| QP-part-025 | 3/4 | $0.5040 | 2/4 | $0.5895 | 3/4 | $1.0324 |
| RL-refill-037 | 4/4 | $0.2597 | 4/4 | $0.1780 | 4/4 | $0.1214 |
| RL-request-043 | 4/4 | $0.1735 | 4/4 | $0.2102 | 4/4 | $0.1527 |
| SM-select-022 | 4/4 | $0.3743 | 3/4 | $0.4747 | 3/4 | $0.4718 |
| SU-split-045 | 4/4 | $0.2818 | 4/4 | $0.3776 | 4/4 | $0.4217 |
| TL-build-039 | 4/4 | $0.3419 | 4/4 | $0.4144 | 4/4 | $0.4381 |
| TL-enough-044 | 4/4 | $0.2909 | 4/4 | $0.2552 | 4/4 | $0.2279 |
| TL-find-040 | 4/4 | $0.2956 | 4/4 | $0.2078 | 4/4 | $0.1210 |
| TL-tiers-038 | 4/4 | $0.3886 | 4/4 | $0.4078 | 4/4 | $0.4164 |
| TL-update-050 | 4/4 | $0.2802 | 4/4 | $0.1720 | 4/4 | $0.1190 |
| TR-cancel-026 | 4/4 | $0.3424 | 3/4 | $0.3499 | 3/4 | $0.3029 |
| TR-discard-011 | 4/4 | $0.2725 | 4/4 | $0.2786 | 4/4 | $0.2618 |
| TR-match-029 | 4/4 | $0.3579 | 4/4 | $0.1908 | 4/4 | $0.1228 |
| TR-nonzero-031 | 4/4 | $0.2395 | 4/4 | $0.2455 | 4/4 | $0.2238 |
| TR-order-010 | 4/4 | $0.2636 | 4/4 | $0.3085 | 4/4 | $0.2687 |
| TR-reinsert-030 | 4/4 | $0.3275 | 4/4 | $0.1767 | 4/4 | $0.1252 |
| TR-sanitize-028 | 4/4 | $0.2805 | 4/4 | $0.2551 | 4/4 | $0.2072 |
| VR-range-042 | 4/4 | $0.3558 | 4/4 | $0.4376 | 4/4 | $0.6967 |

Audit findings: 1; see `analysis.json`.
