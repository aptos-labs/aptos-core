# AF-resource-account-006

This sample is a recipe over the corpus's single editable
[`framework`](framework/) package. The runner copies that package, applies
[`preparation.patch`](preparation.patch), and verifies the resulting hash before
giving the independent workspace to an agent.

## Target

- Target: `0x1::resource_account`
- Granularity: `module`
- Original source: `aptos-move/framework/aptos-framework/sources/resource_account.move`
- Source inside the shared package: `sources/AptosFramework/resource_account.move`
- Source root: `aptos-move/framework/aptos-framework`
- Aptos Core commit: `6d836beedc56fc70c54f3b3046d1d248d850c64b`
- Shared package SHA-256: `134a645e79dc3df34cde010514f1d15e612c196ac5b82f45a10cda73d9be35d4`
- Prepared tree SHA-256: `affdf933a9b6e4a353b04e238b85ebf71a196b78e82802b93c9659ccf7a925f3`
- Required contract categories: `normal-result`, `abort`, `state-transition`, `frame`

Target functions:

- `create_resource_account`
- `create_resource_account_and_fund`
- `create_resource_account_and_publish_package`
- `retrieve_resource_account_cap`

## Compilation context

The shared package contains the union of the target modules and their complete
source-level transitive module dependencies. Its module/file map and resolved
named addresses are recorded in
[`framework/corpus-modules.json`](framework/corpus-modules.json). Modules other
than this sample's target are compilation context, not additional inference
targets.

Opaque/bodyless boundaries whose contracts are visible while proving this
target. This closure traverses transparent executable callees and behavioral
predicates referenced from reached contracts:

- `0x1::account::create_account_unchecked`
- `0x1::account::create_resource_address`
- `0x1::account::ensure_resource_exists`
- `0x1::account::exists_at`
- `0x1::account::get_authentication_key`
- `0x1::aggregator_v2::create_aggregator`
- `0x1::aggregator_v2::create_unbounded_aggregator`
- `0x1::code::check_coexistence`
- `0x1::code::check_dependencies`
- `0x1::code::check_upgradability`
- `0x1::code::get_module_names`
- `0x1::code::publish_package`
- `0x1::code::publish_package_txn`
- `0x1::code::request_publish`
- `0x1::code::request_publish_with_allowed_deps`
- `0x1::coin::decimals`
- `0x1::coin::ensure_paired_metadata`
- `0x1::coin::is_account_registered`
- `0x1::coin::name`
- `0x1::coin::register`
- `0x1::coin::symbol`
- `0x1::create_signer::create_signer`
- `0x1::dispatchable_fungible_asset::deposit`
- `0x1::dispatchable_fungible_asset::withdraw`
- `0x1::error::already_exists`
- `0x1::error::canonical`
- `0x1::error::invalid_argument`
- `0x1::error::invalid_state`
- `0x1::error::not_found`
- `0x1::error::permission_denied`
- `0x1::event::emit`
- `0x1::features::code_dependency_check_enabled`
- `0x1::features::is_default_account_resource_enabled`
- `0x1::features::is_enabled`
- `0x1::features::is_lazy_module_initialization_enabled`
- `0x1::from_bcs::from_bytes`
- `0x1::from_bcs::to_u128`
- `0x1::fungible_asset::add_fungibility`
- `0x1::fungible_asset::deposit_dispatch_function`
- `0x1::fungible_asset::deposit_sanity_check`
- `0x1::fungible_asset::generate_burn_ref`
- `0x1::fungible_asset::generate_mint_ref`
- `0x1::fungible_asset::generate_transfer_ref`
- `0x1::fungible_asset::has_deposit_dispatch_function`
- `0x1::fungible_asset::has_withdraw_dispatch_function`
- `0x1::fungible_asset::store_exists`
- `0x1::fungible_asset::withdraw_dispatch_function`
- `0x1::fungible_asset::withdraw_sanity_check`
- `0x1::hash::sha3_256`
- `0x1::init::module_id_from_name`
- `0x1::init::record_deploy_owner`
- `0x1::init::reset_initialized`
- `0x1::object::address_to_object`
- `0x1::object::create_named_object`
- `0x1::object::create_sticky_object_at_address`
- `0x1::object::create_user_derived_object`
- `0x1::object::generate_signer`
- `0x1::object::is_burnt`
- `0x1::object::is_object`
- `0x1::object::object_address`
- `0x1::object::object_from_constructor_ref`
- `0x1::object::owns`
- `0x1::object::root_owner`
- `0x1::object::unburn`
- `0x1::option::is_none`
- `0x1::option::none`
- `0x1::option::some`
- `0x1::ordered_map::borrow_mut`
- `0x1::ordered_map::contains`
- `0x1::primary_fungible_store::create_primary_store`
- `0x1::primary_fungible_store::create_primary_store_enabled_fungible_asset`
- `0x1::primary_fungible_store::deposit`
- `0x1::primary_fungible_store::ensure_primary_store_exists`
- `0x1::primary_fungible_store::may_be_unburn`
- `0x1::primary_fungible_store::withdraw`
- `0x1::signer::address_of`
- `0x1::simple_map::add`
- `0x1::simple_map::contains_key`
- `0x1::simple_map::create`
- `0x1::simple_map::destroy_empty`
- `0x1::simple_map::length`
- `0x1::simple_map::remove`
- `0x1::string::bytes`
- `0x1::string::utf8`
- `0x1::table::add`
- `0x1::table::borrow`
- `0x1::table::contains`
- `0x1::type_info::type_name`
- `0x1::type_info::type_of`
- `0x1::util::from_bytes`
- `0x1::vector::is_empty`
- `0x1::vector::length`

Transitive specification functions referenced by those boundary contracts:

- `0x1::account::spec_create_resource_address`
- `0x1::account::spec_exists_at`
- `0x1::account::spec_get_authentication_key`
- `0x1::aggregator::spec_aggregator_get_val`
- `0x1::bcs::$to_bytes`
- `0x1::code::$can_change_upgrade_policy_to`
- `0x1::code::$is_policy_exempted_address`
- `0x1::code::$upgrade_policy_arbitrary`
- `0x1::code::$upgrade_policy_immutable`
- `0x1::code::spec_allowed_deps_for_dependency`
- `0x1::code::spec_allowed_deps_for_modules`
- `0x1::code::spec_allowed_deps_prefix`
- `0x1::code::spec_dependencies_abort`
- `0x1::code::spec_dependency_aborts`
- `0x1::code::spec_first_package_index`
- `0x1::coin::spec_fun_supply_tracked`
- `0x1::coin::spec_paired_metadata`
- `0x1::coin::spec_paired_metadata_address`
- `0x1::create_signer::spec_create_signer`
- `0x1::error::$canonical`
- `0x1::features::$concurrent_fungible_assets_enabled`
- `0x1::features::$contains`
- `0x1::features::$is_enabled`
- `0x1::features::spec_is_enabled`
- `0x1::from_bcs::deserializable`
- `0x1::from_bcs::deserialize`
- `0x1::fungible_asset::$asset_metadata`
- `0x1::hash::$sha3_256`
- `0x1::object::$address_to_object`
- `0x1::object::$generate_derive_ref`
- `0x1::object::$is_burnt`
- `0x1::object::$object_address`
- `0x1::object::ownership_chain_exists`
- `0x1::object::ownership_reaches`
- `0x1::object::spec_create_object_address`
- `0x1::object::spec_create_user_derived_object_address`
- `0x1::object::spec_exists_at`
- `0x1::object::spec_owner_at`
- `0x1::option::$borrow`
- `0x1::option::$destroy_some`
- `0x1::option::$is_none`
- `0x1::option::$is_some`
- `0x1::option::$none`
- `0x1::option::$some`
- `0x1::option::spec_borrow`
- `0x1::option::spec_is_none`
- `0x1::option::spec_none`
- `0x1::option::spec_some`
- `0x1::optional_aggregator::$is_parallelizable`
- `0x1::optional_aggregator::optional_aggregator_value`
- `0x1::ordered_map::spec_contains_key`
- `0x1::ordered_map::spec_get`
- `0x1::ordered_map::spec_set`
- `0x1::signer::$address_of`
- `0x1::signer::$borrow_address`
- `0x1::string::$bytes`
- `0x1::string::$length`
- `0x1::string::spec_internal_check_utf8`
- `0x1::string::spec_utf8`
- `0x1::table::spec_contains`
- `0x1::table::spec_get`
- `0x1::type_info::$type_name`
- `0x1::type_info::$type_of`
- `0x1::type_info::spec_is_struct`
- `0x1::util::spec_from_bytes`
- `0x1::vector::$borrow`
- `0x1::vector::$length`

Transitive source modules required to compile the sample:

- `0x1::account`
- `0x1::account_abstraction`
- `0x1::aggregator`
- `0x1::aggregator_factory`
- `0x1::aggregator_v2`
- `0x1::any`
- `0x1::aptos_account`
- `0x1::aptos_coin`
- `0x1::aptos_governance`
- `0x1::aptos_hash`
- `0x1::auth_data`
- `0x1::bcs`
- `0x1::bcs_stream`
- `0x1::big_ordered_map`
- `0x1::block`
- `0x1::bls12381`
- `0x1::bn254_algebra`
- `0x1::chain_id`
- `0x1::chain_status`
- `0x1::chunky_dkg`
- `0x1::chunky_dkg_config`
- `0x1::chunky_dkg_config_seqnum`
- `0x1::cmp`
- `0x1::code`
- `0x1::coin`
- `0x1::comparator`
- `0x1::confidential_amount`
- `0x1::confidential_asset`
- `0x1::confidential_balance`
- `0x1::confidential_range_proofs`
- `0x1::config_buffer`
- `0x1::consensus_config`
- `0x1::copyable_any`
- `0x1::create_signer`
- `0x1::crypto_algebra`
- `0x1::decryption`
- `0x1::delegation_pool`
- `0x1::dispatchable_fungible_asset`
- `0x1::dkg`
- `0x1::ed25519`
- `0x1::epoch_timeout_config`
- `0x1::error`
- `0x1::event`
- `0x1::execution_config`
- `0x1::features`
- `0x1::federated_keyless`
- `0x1::fixed_point32`
- `0x1::fixed_point64`
- `0x1::from_bcs`
- `0x1::function_info`
- `0x1::fungible_asset`
- `0x1::gas_schedule`
- `0x1::genesis`
- `0x1::governance_proposal`
- `0x1::guid`
- `0x1::hash`
- `0x1::init`
- `0x1::jwk_consensus_config`
- `0x1::jwks`
- `0x1::keyless`
- `0x1::keyless_account`
- `0x1::math128`
- `0x1::math64`
- `0x1::math_fixed64`
- `0x1::mem`
- `0x1::multi_ed25519`
- `0x1::multi_key`
- `0x1::multisig_account`
- `0x1::nonce_validation`
- `0x1::object`
- `0x1::option`
- `0x1::optional_aggregator`
- `0x1::ordered_map`
- `0x1::pool_u64`
- `0x1::pool_u64_unbound`
- `0x1::primary_fungible_store`
- `0x1::randomness`
- `0x1::randomness_api_v0_config`
- `0x1::randomness_config`
- `0x1::randomness_config_seqnum`
- `0x1::reconfiguration`
- `0x1::reconfiguration_state`
- `0x1::reconfiguration_with_dkg`
- `0x1::reflect`
- `0x1::result`
- `0x1::ristretto255`
- `0x1::ristretto255_bulletproofs`
- `0x1::ristretto255_pedersen`
- `0x1::secp256k1`
- `0x1::secp256r1`
- `0x1::sigma_protocol`
- `0x1::sigma_protocol_fiat_shamir`
- `0x1::sigma_protocol_homomorphism`
- `0x1::sigma_protocol_key_rotation`
- `0x1::sigma_protocol_proof`
- `0x1::sigma_protocol_registration`
- `0x1::sigma_protocol_representation`
- `0x1::sigma_protocol_representation_vec`
- `0x1::sigma_protocol_statement`
- `0x1::sigma_protocol_statement_builder`
- `0x1::sigma_protocol_transfer`
- `0x1::sigma_protocol_utils`
- `0x1::sigma_protocol_withdraw`
- `0x1::sigma_protocol_witness`
- `0x1::signer`
- `0x1::simple_map`
- `0x1::single_key`
- `0x1::smart_table`
- `0x1::stake`
- `0x1::staking_config`
- `0x1::staking_contract`
- `0x1::state_storage`
- `0x1::storage_gas`
- `0x1::storage_slots_allocator`
- `0x1::string`
- `0x1::string_utils`
- `0x1::system_addresses`
- `0x1::table`
- `0x1::table_with_length`
- `0x1::timestamp`
- `0x1::transaction_context`
- `0x1::transaction_fee`
- `0x1::transaction_limits`
- `0x1::transaction_validation`
- `0x1::type_info`
- `0x1::util`
- `0x1::validator_consensus_info`
- `0x1::vector`
- `0x1::version`
- `0x1::vesting`
- `0x1::voting`

## Preparation

The executable Move implementation is unchanged. Existing target reference
blocks removed from the agent-visible source are:

- `sources/AptosFramework/resource_account.spec.move`: `create_resource_account` (1 block(s))
- `sources/AptosFramework/account/account.spec.move`: `create_resource_account` (1 block(s))
- `sources/AptosFramework/resource_account.spec.move`: `create_resource_account_and_fund` (1 block(s))
- `sources/AptosFramework/resource_account.spec.move`: `create_resource_account_and_publish_package` (1 block(s))
- `sources/AptosFramework/resource_account.spec.move`: `retrieve_resource_account_cap` (1 block(s))

The reproducible transformation is [`preparation.patch`](preparation.patch).
The agent may edit only:

- `sources/AptosFramework/account/account.spec.move`
- `sources/AptosFramework/aptos_account.spec.move`
- `sources/AptosFramework/resource_account.move`
- `sources/AptosFramework/resource_account.spec.move`
