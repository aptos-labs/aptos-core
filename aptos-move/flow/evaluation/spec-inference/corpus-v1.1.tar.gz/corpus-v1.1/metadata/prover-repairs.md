# Shared-framework prover repairs

The corpus keeps one editable union framework package. This ledger records the
behavior-preserving source changes made solely to make its dependency contracts
checkable, together with the corresponding target-body proof evidence. It does
not replace the source history or the contract audit.

| Module/function | Repair | Evidence |
| --- | --- | --- |
| `0x1::code::check_coexistence` | Replaced the module-name traversal with an indexed loop and a processed-prefix invariant. | `dependency-contract-verification.address-1-code-check_coexistence.json` |
| `0x1::code::get_module_names` | Replaced `for_each_ref` with an indexed loop. The invariant preserves both the output length and every copied module name. | `dependency-contract-verification.address-1-code-get_module_names.json` |
| `0x1::code::check_upgradability` | Traverses package modules directly instead of a copied-name vector; the invariant records that every processed module is present in the new package. The complete contract includes the missing-module abort. | `dependency-contract-verification.address-1-code-check_upgradability.json` |
| `0x1::code::check_dependencies` | Replaced its effectful package-search HOF with an explicit first-match loop. The initial rewrite omitted the non-match index advancement, changing the original `vector::any` traversal into a nonterminating search; restored `package_index += 1`. The rewrite now accumulates each dependency separately and records exact module-prefix, first-match, and flattened-output invariants. Its complete contract models registry/package lookup, policy checks, ordered wildcard/module output, and the aggregate capacity abort. Target-body proof times out through 180 seconds, so this is a documented expert boundary rather than a partial generated summary. | `dependency-contract-verification.address-1-code-check_dependencies.json`; `dependency-contract-verification.address-1-code-check_dependencies.timeout-60.json`; `dependency-contract-verification.address-1-code-check_dependencies.timeout-120.json`; `dependency-contract-verification.address-1-code-check_dependencies.timeout-180.json`; `trusted-verification-boundaries.json`; `dependency-contract-audit.json` |
| `0x1::reflect::resolve` | Replaced an uninterpreted SAT-hard summary with the exact feature-gate/native-forwarding contract. The proof initially exposed an undeclared Boogie procedure for `result_of<native_resolve>`; a no-abort native boundary now declares that resolver as an opaque VM result value, allowing the public wrapper to forward it exactly. | `dependency-contract-verification.address-1-reflect-resolve.json` |
| `0x1::function_info::load_function_value` | Replaced the verification-disabled summary with its exact `reflect::resolve` propagation: it aborts when reflection aborts or returns `Err`, and otherwise returns the resolved function value. Replaced the equivalent generic `Result::unwrap` with an explicit `Ok`/`Err` match, avoiding a malformed nested function type when the resolved value is invoked through a behavioral predicate. | `dependency-contract-verification.address-1-function_info-load_function_value.json` |
| `0x1::dispatchable_fungible_asset::{dispatch_withdraw_hook, dispatch_deposit_hook}` | Added exact direct function-value forwarding contracts and selectively overrode the module-wide verification skip. Each propagates the loader abort, callback abort, and callback result/effect. The proof exposed duplicate closure-constructor emission for ability-equivalent generic instantiations; monomorphization now canonicalizes nested function abilities before registering a closure variant. | `dependency-contract-verification.address-1-dispatchable_fungible_asset-dispatch_withdraw_hook.json`; `dependency-contract-verification.address-1-dispatchable_fungible_asset-dispatch_deposit_hook.json` |
| `0x1::object::root_owner` | Made the ownership walk’s dereference fact explicit and added a chain invariant plus exact root-owner helper definitions. | `dependency-contract-verification.address-1-object-root_owner.json` |
| `0x1::object::owns` | Added a bounded ownership-chain model and loop invariants. The look-ahead nesting assertion has the same abort code and no preceding observable mutation as the next iteration’s original limit check. | `dependency-contract-verification.address-1-object-owns.json` |
| `0x1::account::create_account` | Added the exact `Account[new_address]` opaque frame. | `dependency-contract-verification.address-1-account-create_account.json` |
| `0x1::object::unburn` | Added exact `ObjectCore` and `TombStone` frames to the complete unburn contract. | `dependency-contract-verification.address-1-object-unburn.json` |
| `0x1::object::generate_signer` | Made the generated signer’s address equal to its `ConstructorRef` address explicit; this is needed to connect a `move_to` frame to the object address. | `dependency-contract-verification.address-1-object-generate_signer.json` |
| `0x1::object::set_untransferable` | Its exact frame can change `ObjectCore`, but the function mutates rather than removes it. Added the missing `ensures exists<ObjectCore>(self.self)` preservation fact. | `dependency-contract-verification.address-1-object-set_untransferable.json` |
| `0x1::fungible_asset::create_store`, `0x1::primary_fungible_store::create_primary_store`, and `0x1::primary_fungible_store::ensure_primary_store_exists` | Added the four exact derived-store targets (`ObjectCore`, `FungibleStore`, `ConcurrentFungibleBalance`, and `Untransferable`) at the object address. `create_store` now has exact conversion, transfer-guard, and concurrent-balance abort cases. `object::spec_exists_at<T>` is translated by the prover as the exact global `exists<T>` predicate, while the Move function remains opaque. | `dependency-contract-verification.address-1-fungible_asset-create_store.json`; `dependency-contract-verification.address-1-primary_fungible_store-create_primary_store.json`; `dependency-contract-verification.address-1-primary_fungible_store-ensure_primary_store_exists.json` |
| `0x1::staking_contract::request_commission_internal` | Added its exact `StakePool[staking_contract.pool_address]` frame. A legacy isolated attempt unnecessarily removed `opaque` while re-enabling `verify`; it exceeded the 50-second corpus limit (hard timeout at 56 seconds with a 60-second diagnostic budget). The canonical rerun must change only `verify = false` to `verify = true` and retain `opaque`; the boundary remains blocked pending that proof or further contract/prover work. | `dependency-contract-verification.address-1-staking_contract-request_commission_internal.timeout.json` |
| `0x1::pool_u64::{add_shares, deduct_shares, transfer_shares}` | Completed the local share-transfer foundation. `add_shares` now uses the executable subtraction-form overflow condition; `deduct_shares` has exact intrinsic-map set/remove effects; and `transfer_shares` has complete normal/abort behavior plus an exact pure map transformer for callers' loop invariants. | `dependency-contract-verification.address-1-pool_u64-add_shares.json`; `dependency-contract-verification.address-1-pool_u64-deduct_shares.json`; `dependency-contract-verification.address-1-pool_u64-transfer_shares.json` |
| `0x1::pool_u64::shareholders` | Replaced a conditional generated result clause with the exact unconditional field-copy contract needed to anchor caller snapshots. | `dependency-contract-verification.address-1-pool_u64-shareholders.json` |
| `0x1::staking_contract::update_distribution_pool` | Replaced the inline HOF with an indexed loop, exact shares-map fold, one-step/identity lemmas, and staged proof assertions. The contract now gives scalar/map/vector effects plus an explicit per-iteration abort predicate over the map fold. The exact remove-or-push-to-stable-filter vector bridge remains solver-intractable, so this complete boundary is recorded as a documented expert assumption rather than a successful target-body proof. | `dependency-contract-verification.address-1-staking_contract-update_distribution_pool.json`; `trusted-verification-boundaries.json`; `dependency-contract-audit.json` |
| `0x1::simple_map::find` | Replaced a partial generated summary with the complete intrinsic-map abstraction: the returned option is present exactly when the queried key is present. The prover intentionally forbids selecting the intrinsic map's backing `data` vector during body verification, so the bounded linear-search implementation cannot be proved against this abstraction; this complete contract is recorded as a documented expert assumption. | `dependency-contract-verification.address-1-simple_map-find.json`; `trusted-verification-boundaries.json`; `dependency-contract-audit.json` |
| `0x1::ordered_map::binary_search` | Added interval and control-flow-model invariants to the ordinary vector loop, then replaced the generated quantified summary with exact recursive result and abort predicates. Its target-body proof exceeds the 60-second corpus limit without a counterexample, so this otherwise complete private boundary is recorded as a documented expert assumption. | `dependency-contract-verification.address-1-ordered_map-binary_search.json`; `dependency-contract-verification.address-1-ordered_map-binary_search.timeout-60.json`; `trusted-verification-boundaries.json`; `dependency-contract-audit.json` |
| `0x1::ordered_map::{internal_new_begin_iter, internal_new_end_iter, iter_is_begin, iter_is_end}` | Removed stale verification skips from the complete iterator-constructor/predicate contracts. Each body proof succeeds at the 40-second corpus limit. | `dependency-contract-verification.address-1-ordered_map-internal_new_begin_iter.json`; `dependency-contract-verification.address-1-ordered_map-internal_new_end_iter.json`; `dependency-contract-verification.address-1-ordered_map-iter_is_begin.json`; `dependency-contract-verification.address-1-ordered_map-iter_is_end.json` |
| `0x1::ordered_map::{iter_borrow, iter_borrow_key}` | Retained the exact intrinsic-map enumeration contracts. Diagnostic copies that re-enable verification while preserving `opaque` fail during condition generation because the prover deliberately forbids selection of `OrderedMap.entries`; both complete boundaries are recorded as documented expert assumptions. | `dependency-contract-verification.address-1-ordered_map-iter_borrow.intrinsic-map.json`; `dependency-contract-verification.address-1-ordered_map-iter_borrow_key.intrinsic-map.json`; `trusted-verification-boundaries.json`; `dependency-contract-audit.json` |
| `0x1::ordered_map::internal_lower_bound` | Completed the lower-bound iterator contract with the present-key rank fact: a present query returns exactly `spec_rank`. A diagnostic copy that re-enables verification while preserving `opaque` still fails during condition generation because the prover deliberately forbids selection of `OrderedMap.entries`; the complete intrinsic-map boundary is recorded as a documented expert assumption. | `dependency-contract-verification.address-1-ordered_map-internal_lower_bound.intrinsic-map.json`; `trusted-verification-boundaries.json`; `dependency-contract-audit.json` |
| `0x1::ordered_map::internal_find` | Removed the stale verification skip after strengthening `internal_lower_bound` with the rank guarantee. The exact end-or-rank contract proves against the classified lower-bound and key-borrow boundaries. | `dependency-contract-verification.address-1-ordered_map-internal_find.json` |
| `0x1::ordered_map::append_impl` | Removed the generated partial structural summary. This private representation helper is called only by the public intrinsic `append` and `append_disjoint` operations, so it is itself intrinsic: clients use the complete intrinsic-map bindings rather than an inaccessible `entries` representation. | `contract-report.json`; `dependency-contract-audit.json` |
| `0x1::ordered_map::iter_prev` | Retained the exact predecessor iterator contract. A diagnostic copy that re-enables verification while preserving `opaque` fails during condition generation because the prover deliberately forbids selection of `OrderedMap.entries`; the complete intrinsic-map boundary is recorded as a documented expert assumption. | `dependency-contract-verification.address-1-ordered_map-iter_prev.intrinsic-map.json`; `trusted-verification-boundaries.json`; `dependency-contract-audit.json` |
| `0x1::big_ordered_map::get_max_degree` | Retained the exact selected-degree contract. A diagnostic copy that re-enables verification while preserving `opaque` fails during condition generation because the prover deliberately forbids selection of `BigOrderedMap` configuration fields; the complete intrinsic-map boundary is recorded as a documented expert assumption. | `dependency-contract-verification.address-1-big_ordered_map-get_max_degree.intrinsic-map.json`; `trusted-verification-boundaries.json`; `dependency-contract-audit.json` |
| `0x1::big_ordered_map::{find_leaf, find_leaf_path, update_key, add_or_upsert_impl}` | Reclassified four private B+tree-layout helpers as intrinsic. Their node indices, paths, and structural updates are deliberately hidden by the complete `BigOrderedMap` intrinsic-map model; public map operations remain the only observable semantic boundary. | `contract-report.json`; `dependency-contract-audit.json` |
| `0x5::bulk_order_types::get_total_remaining_size` | Added prefix-sum loop invariants and exact overflow/result conditions using `sum_sizes`. | Source contract and loop annotations; this function is outside the current selected proof closure. |
| `0x7::bulk_order_utils::{validate_not_zero_sizes, validate_price_ordering}` | Added vector-prefix loop invariants supporting the checked predicates. | Source contract and loop annotations; callers remain in the incomplete closure. |
| `0x7::bulk_order_utils::discard_price_crossing_levels` | Added prefix loop invariants and replaced the invalid SAT-hard summary with an exact first-non-crossing-index contract: a bounded crossing prefix and a non-crossing boundary (or vector end). | `dependency-contract-verification.address-7-bulk_order_utils-discard_price_crossing_levels.json` |
| `0x7::market_types::validate_bulk_order_placement` | Completed the direct callback-forwarding contract with the exact `result_of` and `aborts_of` predicates. The proof exposed a prover encoding defect: function-valued struct fields were modeled only when they had the `store` ability, leaving non-storable callbacks with an empty apply procedure. The prover now registers every function-valued field and dispatches it through the corresponding behavioral predicates. | `dependency-contract-verification.address-7-market_types-validate_bulk_order_placement.json`; `move-prover` `result_of_old_label` regression test. |
| `0x7::order_book_utils::new_default_big_ordered_map` | Replaced a stale `result_of` equality with the exact intrinsic-map abstraction: an empty map has length zero and contains no key. An intrinsic map constructor allocates a fresh hidden iterator-validity token, so two separately constructed maps must not be compared for value equality. | `dependency-contract-verification.address-7-order_book_utils-new_default_big_ordered_map.json` |
| `0x1::storage_slots_allocator::{next_slot_index, remove_link}` | Replaced generated temporal summaries with exact allocator/table contracts. `next_slot_index` returns the previous index, advances only that allocator counter, and lazily creates an empty intrinsic table. `remove_link` has the exact initialized-and-present abort domain, returns the removed entry, and removes precisely that table key. | `dependency-contract-verification.address-1-storage_slots_allocator-next_slot_index.json`; `dependency-contract-verification.address-1-storage_slots_allocator-remove_link.json` |
| `0x7::price_time_index::{best_ask_price, best_bid_price}` | Replaced untrusted `borrow_front`/`borrow_back` summaries with the intrinsic ordered-map abstraction: `none` for an empty map and the price at rank zero / final rank otherwise. | `dependency-contract-verification.address-7-price_time_index-best_ask_price.json`; `dependency-contract-verification.address-7-price_time_index-best_bid_price.json` |
| `0x7::price_time_index::increase_order_size` | Replaced the self-referential generated clauses with an exact `spec_set` update at the selected price-time key, preserving the opposite side and covering conversion, absent-key, and overflow aborts. | `dependency-contract-verification.address-7-price_time_index-increase_order_size.json` |
| `0x7::bulk_order_book::cancel_active_order_for_side` | Replaced a temporal generated summary with the trusted `cancel_active_order` relation from the old index to the post-state, including its return witness and propagated abort domain. | `dependency-contract-verification.address-7-bulk_order_book-cancel_active_order_for_side.json` |
| `0x7::dead_mans_switch_tracker::disable_keep_alive` | Replaced generated `remove_or_none` conditions with the exact intrinsic-map removal and an event whose `was_registered` field is the pre-state key-membership predicate. | `dependency-contract-verification.address-7-dead_mans_switch_tracker-disable_keep_alive.json` |
| `0x7::single_order_book::place_ready_maker_order_with_unique_idx` | Replaced the generated temporal upsert summary with the complete order-map/client-index updates, a `place_maker_order` post-relation, and the ordered duplicate/index/destructor/delegate abort paths. | `dependency-contract-verification.address-7-single_order_book-place_ready_maker_order_with_unique_idx.json` |
| `0x1::init::reset_initialized` | Replaced its tautological SAT-hard clause with the exact no-state/no-module/no-reset cases and the conditional `only_once := none` ordered-map update. The impure module-ID helper is connected to the map lookup through a paired behavioral-state label. | `dependency-contract-verification.address-1-init-reset_initialized.json` |
| `0x1::fungible_asset::withdraw_sanity_check` | Replaced generated temporal abort clauses with the five executable cases: ownership-call abort, non-owner, missing store, disallowed dispatch hook, and frozen store. | `dependency-contract-verification.address-1-fungible_asset-withdraw_sanity_check.json` |
| `0x1::primary_fungible_store::{may_be_unburn, deposit, withdraw}` | Added exact resource frames and normal/abort forwarding. `ensure_primary_store_exists` now explicitly returns its deterministic derived store address, connecting factory frames to the subsequent deposit/withdraw call. | `dependency-contract-verification.address-1-primary_fungible_store-may_be_unburn.json`; `dependency-contract-verification.address-1-primary_fungible_store-deposit.json`; `dependency-contract-verification.address-1-primary_fungible_store-withdraw.json` |
| `0x1::code::publish_package` | Added source invariants for each direct loop: the lazy deploy-owner prefix, package-scan/last-match index, and upgrade-reset prefix. A focused WP run exposed a diagnostic-only prover panic, which is repaired below. The remaining contract needs complete forwarding for package validation, initialization, events, and native publication; it is intentionally still audit-blocking. | `publish-package-loop-invariant-trial.json`; `dependency-contract-audit.json` |
| Prover global-invariant diagnostic dump | Skipped functions with no verified bytecode when printing global-invariant analysis. The analysis processor intentionally omits their annotations, so attempting to dump one previously panicked with `Analysis not performed`. | Focused `publish_package` WP inference succeeds after the repair. |
| Boogie duplicate behavioral spec declarations | A behavioral target's `$bp_requires_of` / `$bp_aborts_of` / `$bp_ensures_of_result` declarations are named after the target function alone, but were emitted once per function type. A function reached both as a partially applied closure (`\|u64\|u64`) and as a whole function value named in a specification (`\|u64, u64\|u64`) was therefore declared twice, and Boogie rejected the file with `more than one declaration of function name`. The declaration set is now shared across the whole file. Found by mining the pilot-007 transcripts, where it accounted for six verifier failures in the `calculator` runs. | `move-prover` regression `closures/behavioral_target_two_masks.move`; replaying the archived `calculator` agent-only edits now verifies instead of producing eight Boogie name-resolution errors. |

Contract-only repairs (for example `coin`, `init`, `signer`, and `object::unburn`)
do not change executable code. Their individual target-body proof artifacts are
stored alongside this file. The authoritative current coverage and blockers are
in [`dependency-contract-audit.json`](dependency-contract-audit.json).

The audit treats an opaque contract's frame as part of its completeness. It
derives the global resource types that the executable closure can mutate and
requires the `modifies` targets to cover each type. It intentionally does not
require a frame for local `&mut` arguments or read-only global operations.
It rejects opaque functions whose verification is disabled unless they are a
complete, framed boundary recorded in
[`trusted-verification-boundaries.json`](trusted-verification-boundaries.json)
with either a larger-timeout proof artifact or an explicit expert rationale.

## `big_ordered_map::internal_find` is verified, not a boundary (2026-09-05)

`internal_find` carried `pragma verify = false` with an `intrinsic_model` basis,
which made every `result_of<internal_find>` carrier in a caller untrusted
(`sathard`); `bulk_order_book::get_sizes` emitted seven such clauses. Its body
only composes the opaque contracts of `internal_lower_bound`, `iter_is_end` and
`internal_new_end_iter`, so it is proved instead:

- `ensures spec_iter_current(result, self)` was unprovable on the not-found
  branch (the end iterator satisfies `spec_iter_valid`, not `spec_iter_current`);
  the clause is now `spec_iter_valid(result, self)`, which is what callers
  (`iter_borrow`, `iter_borrow_mut`) require.
- `internal_lower_bound` gains the explicit consequence
  `spec_contains_key(self, key) ==> !iter_is_end(result, self) && result.key == key`.
  It follows from its existing two clauses under the total order of
  `cmp::compare` (a present key is `>=` itself and `<=` every present key `>=`
  it), and is stated so callers need no ordering reasoning. A `spec lemma`
  proving it was attempted first, but lemma parameters of generic struct type
  (`BigOrderedMap<K, V>`, `IteratorPtr<K>`) do not resolve in a spec module
  file even when fully qualified -- a compiler gap to fix separately.

Evidence: `move-flow experiment prove --target 0x1::big_ordered_map::internal_find --timeout 60`
on a copy with `verify = true`: 0 diagnostics, 126s wall (artifact
`/tmp/claude-1001/findB.json` during the session).

## WP trusts reviewed `verify = false` boundaries (2026-09-05)

Apparatus change, decided by the user. WP marked every caller of a
`verify = false` callee `solver_hard` (`wp_function_call`) and every
`result_of` carrier over one untrusted (`has_untrusted_transparent_result_of`),
so any target touching the intrinsic map -- whose helpers are all
`intrinsic_model` boundaries -- was `sathard` by construction; proving
`internal_find` did not move `get_sizes` because `iter_borrow` and
`iter_is_end` read the hidden representation and cannot be proved.

Now a `verify = false` opaque callee is consumed like any opaque contract; only
an incomplete contract (`aborts_if_is_partial`) taints the caller, and
`result_of` carriers are untrusted only for transparent callees. This is the
semantics CLAUDE.md already states for documented boundaries. Agent laundering
is caught by the screen's enriched-vs-baseline diff, not by this rule.

Round-001 on etna-v3 was measured under the old rule; later rounds are new
recorded rounds. Regression: `move-prover/tests/inference/trusted_boundary_callee.move`.

## Targets that WP cannot infer by design (2026-09-05)

- `big_ordered_map::iter_modify` (AF-big-ordered-map-051): its body mutates
  through `storage_slots_allocator::borrow_mut`, an opaque `&mut`-returning
  helper of the intrinsic map's hidden representation. The write-back has no
  value, so WP's post-state carries an unconstrained quantifier (`vacuous`).
  This is representation code beneath the `pragma intrinsic` abstraction, not a
  missing invariant; the prover's "bug" diagnostic for this case was misleading
  and now names the cause. Candidate for the reserve hierarchy.
- `market_bulk_order::cancel_bulk_order_internal` (AX-market-bulk-order-004):
  two loops whose only effect is a sequence of callback calls
  (`cleanup_bulk_order_at_price`, exact `ensures_of`/`aborts_of` contract).
  The loop's effect is a chain of two-state predicates with no functional
  model; a bound invariant alone leaves the post-state vacuous. Needs a fold
  model over memory states, which the inline-HOF mechanism does not provide for
  effectful callbacks. Candidate for the reserve hierarchy.

## Prover defects fixed while repairing corpus-v1.1 (2026-09-05)

- **Behavioral predicate inside a spec function** (blocked `AF-vesting-032`
  through `staking_contract::spec_aptos_deposit_aborts`): `aborts_of<f>` in
  a spec fun body emitted `old(..)` and referenced `f`'s memory as globals
  inside a Boogie function. Three layers: the spec-fun memory summary never
  folded the predicate target's memory (`ExpData::behavior_target_memory`,
  now shared with the function-spec pass and kind-aware -- only two-state
  predicates make the spec fun two-state); the spec rewriter closed spec-fun
  summaries before function summaries existed (now a joint fixpoint, and
  `compute_direct_old_usage` delegates to `directly_old_memory`); and both
  evaluator argument emitters named memory as a global instead of the spec
  fun's parameter (`spec_fun_body_memory_arg`). Regression:
  `closures/behavioral_in_spec_fun.move`. The fix also made
  `closures/lambda_spec_global_memory.move` honest: it had verified only
  because the old wiring collapsed `debit`'s ensures to `p0 == 0`; it now
  declares `modifies_of<f>(v: &mut u64) Counter[@0x42]` on `apply`, which is
  what saves the pre-state and havocs the memory across the opaque boundary.
- **`cmp::Ordering` undeclared** (observed only in the bare `move-prover` test
  harness, not in any corpus run): the base backend emits `$1_cmp_$compare'T'`
  for every root type parameter whenever stdlib `cmp` is present, but the
  `Ordering` datatype and the whole `cmp` theory are declared by the *aptos*
  prelude extension (`aptos-move/framework/src/aptos-natives.bpl`), which
  move-flow loads and the plain harness does not. Not a corpus defect. Follow-up:
  `cmp` is move-stdlib, so its theory belongs in the base prelude; that move
  touches every aptos prover run and is left out of this change.
- **Selective loop unrolling panic** (`AX-market-bulk-order-004`): unrolling
  marks held code offsets computed before `transform` rewrote the summarized
  loops; they are recomputed against the body actually unrolled.
- **Misleading "bug" diagnostic** for a `vacuous` condition without loops: the
  message now names the real cause -- an opaque callee returning `&mut` into
  memory its contract does not model.

## `compare-implementation` panicked on lemma functions (2026-09-05)

Validating the corpus-v1.1 mutant sets compares the reference package's
implementation with the prepared one. A `spec lemma` is a model-only function
with a synthetic definition index past the compiled module's table (so debug
tracking can resolve it), and the comparer indexed `function_defs` with it:
`0x1::code::spec_allowed_deps_for_modules_step`, index 16 of 16. The
reference-vs-itself comparison passed only because whole-module equivalence
short-circuits the per-function walk. The comparer now skips lemma-kind
functions and fails with the identity rather than panicking when a definition
index does not address the compiled table. Any package with a lemma in scope was
affected -- four corpus-v1.1 modules carry them.

## AF-multisig-account-015: an unwinnable task, repaired

Two things made the task impossible rather than hard, and both were apparatus,
not specification.

`can_execute` compares through `cmp::is_ge` in its timelock branch. That
predicate carried `pragma intrinsic; pragma opaque; pragma verify = false;` and
no contract, so its aborts were a free choice of the model and no exact abort
condition existed for the caller to state -- which is why the upstream
specification carries `pragma aborts_if_is_partial`. The `cmp` predicates are
pure tests on `Ordering` that cannot abort, so each now has an exact contract,
proved against its body. With those in place the remaining uncovered aborts are
ones the caller can name.

The task also required the `frame` category. Only a `modifies` clause states a
frame, and `can_execute` reads global state without writing any, so it had
nothing to put in one. `required_contract_categories` derived `frame` from the
`global-state` stratum, which is a read-or-write signal; it now derives it from
`global-write`, and this record drops the category it could never cover.

The reference contract still does not itself satisfy the task's criteria: it is
partial on aborts and covers neither the loop invariant nor a state-transition
condition. It stands as evidence that the target is provable, not that the
acceptance bar is reached; the bar is now reachable, which it was not before.
