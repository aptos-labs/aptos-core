#!/usr/bin/env python3
"""Regenerate corpus-v1.1 preparation patches against the current shared package.

A preparation patch does one thing: blank the reference specification blocks for
a task's target, so the agent is asked to infer what upstream already states.
It blanks rather than deletes -- each removed line becomes spaces of the same
length -- so line numbers and byte offsets in the file are unchanged, which is
what keeps every other recorded offset into that file valid.

The patches were authored against a shared package that has since been
reformatted: `ensures result == (...)` on one line became the same expression
reflowed across five. The text no longer matches, so 19 of 30 patches stop
applying, while the corpus itself is unchanged and still correct.

Regenerating is the repair, because a patch is derived from two things that are
both still known: the package, and which specification blocks to blank
(`removed_reference_blocks` in the manifest). Rebuilding the corpus with
`prepare.py` would instead regenerate it from *today's* aptos-framework, which
is a different corpus rather than a repaired one.

    python3 corpus-v1.1/regenerate_preparation.py --check   # verify, write nothing
    python3 corpus-v1.1/regenerate_preparation.py           # rewrite the patches
"""

from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
FRAMEWORK = ROOT / "framework"
SAMPLES = ROOT / "samples"
MANIFEST = ROOT / "manifest.json"


def _blank(line: str) -> str:
    """A line replaced by whitespace of its own width.

    Not an empty line: the patch preserves byte offsets as well as line
    numbers, so anything recorded as an offset into this file still points
    where it did.
    """
    return " " * len(line)


def _spec_block_span(lines: list[str], function: str) -> tuple[int, int] | None:
    """The half-open line range of `spec <function>`'s block.

    Located by name rather than by text, because the text is exactly what
    reformatting changed. Brace matching runs from the opening `{` so a block
    containing nested braces -- a `let` with a struct literal, an `if` -- ends
    where it actually ends.
    """
    opener = re.compile(rf"^\s*spec\s+{re.escape(function)}\s*(\(|\{{|<)")
    for index, line in enumerate(lines):
        if not opener.match(line):
            continue
        depth = 0
        seen_brace = False
        for offset in range(index, len(lines)):
            for char in lines[offset]:
                if char == "{":
                    depth += 1
                    seen_brace = True
                elif char == "}":
                    depth -= 1
            if seen_brace and depth == 0:
                return index, offset + 1
        raise SystemExit(f"unterminated spec block for {function}")
    return None


def _task_json_hunk(patch: Path) -> str:
    """The `.move-inference-task.json` half of an existing patch.

    That file is added by preparation and is not affected by reformatting, so
    it is carried across verbatim rather than recomputed.
    """
    text = patch.read_text(encoding="utf-8")
    parts = re.split(r"(?m)^(?=diff --git )", text)
    for part in parts:
        if ".move-inference-task.json" in part.split("\n", 1)[0]:
            return part
    raise SystemExit(f"{patch}: no .move-inference-task.json hunk")


def regenerate(task: str, record: dict, check: bool) -> str:
    blocks = record.get("removed_reference_blocks") or []
    patch_path = SAMPLES / task / "preparation.patch"
    with tempfile.TemporaryDirectory(prefix="v1-prep-") as temporary:
        work = Path(temporary) / "pkg"
        shutil.copytree(FRAMEWORK, work)
        subprocess.run(["git", "init", "-q"], cwd=work, check=True)
        subprocess.run(["git", "add", "-A"], cwd=work, check=True,
                       stdout=subprocess.DEVNULL)
        subprocess.run(["git", "-c", "user.email=x@y", "-c", "user.name=x",
                        "commit", "-qm", "base"], cwd=work, check=True,
                       stdout=subprocess.DEVNULL)
        # The task descriptor, verbatim from the patch being replaced.
        subprocess.run(["git", "apply", "-"], cwd=work, check=True,
                       input=_task_json_hunk(patch_path), text=True)
        for block in blocks:
            target = work / block["path"]
            lines = target.read_text(encoding="utf-8").split("\n")
            span = _spec_block_span(lines, block["function"])
            if span is None:
                raise SystemExit(
                    f"{task}: no `spec {block['function']}` in {block['path']}"
                )
            start, stop = span
            lines[start:stop] = [_blank(line) for line in lines[start:stop]]
            target.write_text("\n".join(lines), encoding="utf-8")
        subprocess.run(["git", "add", "-A"], cwd=work, check=True,
                       stdout=subprocess.DEVNULL)
        produced = subprocess.run(["git", "diff", "--cached"], cwd=work,
                                  check=True, capture_output=True, text=True).stdout
    if not check:
        patch_path.write_text(produced, encoding="utf-8")
    return produced


def _applies(task: str) -> bool:
    with tempfile.TemporaryDirectory(prefix="v1-apply-") as temporary:
        work = Path(temporary) / "pkg"
        shutil.copytree(FRAMEWORK, work)
        subprocess.run(["git", "init", "-q"], cwd=work, check=True)
        probe = subprocess.run(
            ["git", "apply", "--check", str(SAMPLES / task / "preparation.patch")],
            cwd=work, capture_output=True,
        )
    return probe.returncode == 0


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true",
                        help="report without rewriting any patch")
    args = parser.parse_args()
    records = {r["task_id"]: r for r in json.loads(
        MANIFEST.read_text(encoding="utf-8"))["records"]}
    before = {t: _applies(t) for t in sorted(records)}
    print(f"before: {sum(before.values())}/{len(before)} preparation patches apply")
    for task in sorted(records):
        regenerate(task, records[task], args.check)
    if args.check:
        print("--check: nothing written")
        return
    after = {t: _applies(t) for t in sorted(records)}
    print(f"after : {sum(after.values())}/{len(after)} preparation patches apply")
    broken = [t for t, ok in after.items() if not ok]
    if broken:
        print("still failing:", ", ".join(broken))
        sys.exit(1)


if __name__ == "__main__":
    main()
